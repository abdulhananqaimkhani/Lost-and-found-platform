#!/bin/sh
# Runs once, when the database volume is first created.
# Creates the separate test database used by the automated test suite, with the same extensions.
set -e
psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<-EOSQL
	CREATE DATABASE lostfound_test OWNER "$POSTGRES_USER";
EOSQL
for db in "$POSTGRES_DB" lostfound_test; do
	psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$db" <<-EOSQL
		CREATE EXTENSION IF NOT EXISTS postgis;
		CREATE EXTENSION IF NOT EXISTS pg_trgm;
	EOSQL
done
