"""Initial schema: reports, sources, jobs, collection runs, suggestions, audit log, matches, gazetteer.

Revision ID: 0001
Revises:
Create Date: 2026-11-22
"""

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql as pg

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

REPORT_TYPES = ("LOST", "FOUND")
STATUSES = ("ACTIVE", "POTENTIAL_MATCH", "UNVERIFIED", "DISPUTED", "STALE", "RESOLVED")
CATEGORIES = (
    "WALLET",
    "PHONE",
    "DOCUMENT_ID",
    "BAG",
    "KEYS",
    "JEWELLERY",
    "ELECTRONICS",
    "PET",
    "VEHICLE",
    "CLOTHING",
    "OTHER",
)
PRECISIONS = ("POI", "STREET", "NEIGHBOURHOOD", "CITY", "UNKNOWN")
DATE_PRECISIONS = ("EXACT", "APPROXIMATE", "UNKNOWN")
LANGUAGES = ("ENGLISH", "ROMAN_URDU", "URDU", "MIXED", "OTHER")
PLATFORMS = ("DEMO", "RSS", "X", "REDDIT", "BLUESKY", "MASTODON", "WEB", "COMMUNITY")
SOURCE_STATES = ("NEW", "PREFILTER_REJECTED", "IRRELEVANT", "EXTRACTED", "ATTACHED_DUPLICATE", "FAILED")
JOB_TYPES = ("EXTRACT", "GEOCODE", "MATCH")
JOB_STATUSES = ("PENDING", "RUNNING", "DONE", "FAILED")
RUN_STATUSES = ("RUNNING", "SUCCESS", "FAILED", "SKIPPED")

GEOG_EXPR = (
    "GENERATED ALWAYS AS (CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL "
    "THEN (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326))::geography END) STORED"
)


def check_in(column: str, allowed: tuple[str, ...], name: str) -> sa.CheckConstraint:
    values = ", ".join(f"'{v}'" for v in allowed)
    return sa.CheckConstraint(f"{column} IN ({values})", name=name)


def ts(name: str, nullable: bool = False, default: bool = False) -> sa.Column:
    return sa.Column(
        name, sa.DateTime(timezone=True), nullable=nullable, server_default=sa.func.now() if default else None
    )


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS postgis")
    op.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm")

    op.create_table(
        "places",
        sa.Column("key", sa.String(80), primary_key=True),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("label", sa.String(200), nullable=False),
        sa.Column("aliases", pg.ARRAY(sa.Text), nullable=False, server_default="{}"),
        sa.Column("city", sa.String(80), nullable=False, server_default="Karachi"),
        sa.Column("display_name", sa.Text),
        sa.Column("osm_type", sa.String(16)),
        sa.Column("osm_id", sa.BigInteger),
        sa.Column("osm_category", sa.String(40)),
        sa.Column("osm_type_detail", sa.String(40)),
        sa.Column("precision", sa.String(16), nullable=False),
        sa.Column("latitude", sa.Float, nullable=False),
        sa.Column("longitude", sa.Float, nullable=False),
        sa.Column("radius_m", sa.Integer),
        sa.Column("is_area_filter", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("provenance", sa.String(40), nullable=False, server_default="OSM_NOMINATIM"),
        ts("created_at", default=True),
        check_in("precision", PRECISIONS, "ck_places_precision"),
        sa.CheckConstraint("latitude BETWEEN -90 AND 90 AND longitude BETWEEN -180 AND 180", name="ck_places_coords"),
    )
    op.execute(f"ALTER TABLE places ADD COLUMN geog geography(Point,4326) {GEOG_EXPR}")
    op.create_index("ix_places_geog", "places", ["geog"], postgresql_using="gist")

    op.create_table(
        "reports",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("report_type", sa.String(8), nullable=False),
        sa.Column("item_name", sa.String(200), nullable=False),
        sa.Column("item_category", sa.String(16), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("attributes", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("location_text", sa.String(300)),
        sa.Column("city", sa.String(80)),
        sa.Column("city_source", sa.String(32)),
        sa.Column("latitude", sa.Float),
        sa.Column("longitude", sa.Float),
        sa.Column("location_precision", sa.String(16), nullable=False, server_default="UNKNOWN"),
        sa.Column("location_radius_m", sa.Integer),
        sa.Column("place_key", sa.String(80), sa.ForeignKey("places.key", ondelete="SET NULL")),
        sa.Column("geocode_provider", sa.String(32)),
        sa.Column("incident_date", sa.Date),
        sa.Column("date_expression", sa.String(120)),
        sa.Column("date_precision", sa.String(16), nullable=False, server_default="UNKNOWN"),
        ts("reported_at"),
        ts("collected_at"),
        sa.Column("status", sa.String(16), nullable=False, server_default="ACTIVE"),
        sa.Column("confidence_score", sa.Float, nullable=False, server_default="0"),
        sa.Column("needs_review", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("review_reasons", pg.JSONB, nullable=False, server_default="[]"),
        sa.Column("language", sa.String(16), nullable=False, server_default="OTHER"),
        sa.Column("extraction_model", sa.String(80)),
        sa.Column("primary_platform", sa.String(16), nullable=False),
        sa.Column("source_count", sa.Integer, nullable=False, server_default="1"),
        sa.Column("is_demo", sa.Boolean, nullable=False, server_default=sa.false()),
        sa.Column("search_text", sa.Text, nullable=False, server_default=""),
        ts("last_activity_at"),
        ts("created_at", default=True),
        ts("updated_at", default=True),
        check_in("report_type", REPORT_TYPES, "ck_reports_type"),
        check_in("item_category", CATEGORIES, "ck_reports_category"),
        check_in("status", STATUSES, "ck_reports_status"),
        check_in("location_precision", PRECISIONS, "ck_reports_precision"),
        check_in("date_precision", DATE_PRECISIONS, "ck_reports_date_precision"),
        check_in("language", LANGUAGES, "ck_reports_language"),
        check_in("primary_platform", PLATFORMS, "ck_reports_platform"),
        sa.CheckConstraint("confidence_score BETWEEN 0 AND 1", name="ck_reports_confidence"),
        # Coordinates exist only for locations precise enough to map (never for CITY/UNKNOWN),
        # and always both or neither.
        sa.CheckConstraint(
            "(latitude IS NULL AND longitude IS NULL) OR "
            "(latitude BETWEEN -90 AND 90 AND longitude BETWEEN -180 AND 180 "
            "AND location_precision IN ('POI', 'STREET', 'NEIGHBOURHOOD'))",
            name="ck_reports_coords",
        ),
    )
    op.execute(f"ALTER TABLE reports ADD COLUMN geog geography(Point,4326) {GEOG_EXPR}")
    op.execute(
        "ALTER TABLE reports ADD COLUMN search_tsv tsvector "
        "GENERATED ALWAYS AS (to_tsvector('simple', coalesce(search_text, ''))) STORED"
    )
    op.create_index("ix_reports_geog", "reports", ["geog"], postgresql_using="gist")
    op.create_index("ix_reports_search_tsv", "reports", ["search_tsv"], postgresql_using="gin")
    op.create_index("ix_reports_reported_at", "reports", ["reported_at"])
    op.create_index("ix_reports_type_category", "reports", ["report_type", "item_category"])
    op.create_index("ix_reports_status", "reports", ["status"])

    op.create_table(
        "collection_runs",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("source_key", sa.String(80), nullable=False, index=True),
        sa.Column("platform", sa.String(16), nullable=False),
        ts("started_at", default=True),
        ts("completed_at", nullable=True),
        sa.Column("status", sa.String(16), nullable=False, server_default="RUNNING"),
        sa.Column("records_fetched", sa.Integer, nullable=False, server_default="0"),
        sa.Column("records_new", sa.Integer, nullable=False, server_default="0"),
        sa.Column("records_duplicate", sa.Integer, nullable=False, server_default="0"),
        sa.Column("errors", pg.JSONB, nullable=False, server_default="[]"),
        sa.Column("cost_units", sa.Float, nullable=False, server_default="0"),
        sa.Column("cursor_before", pg.JSONB),
        sa.Column("cursor_after", pg.JSONB),
        sa.Column("message", sa.Text),
        check_in("status", RUN_STATUSES, "ck_runs_status"),
    )

    op.create_table(
        "source_states",
        sa.Column("source_key", sa.String(80), primary_key=True),
        sa.Column("cursor", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("consecutive_failures", sa.Integer, nullable=False, server_default="0"),
        ts("paused_until", nullable=True),
        ts("last_success_at", nullable=True),
        ts("updated_at", default=True),
    )

    op.create_table(
        "sources",
        sa.Column("id", sa.String(40), primary_key=True),
        sa.Column("platform", sa.String(16), nullable=False),
        sa.Column("source_key", sa.String(80)),
        sa.Column("external_post_id", sa.String(200), nullable=False),
        sa.Column("original_url", sa.Text, nullable=False),
        sa.Column("canonical_url", sa.Text, unique=True),
        sa.Column("original_text", sa.Text, nullable=False),
        sa.Column("text_hash", sa.String(64), nullable=False, index=True),
        ts("published_at"),
        ts("collected_at"),
        sa.Column("raw_meta", pg.JSONB, nullable=False, server_default="{}"),
        sa.Column("prefilter_score", sa.Float),
        sa.Column("processing_state", sa.String(24), nullable=False, server_default="NEW"),
        sa.Column("report_id", sa.String(40), sa.ForeignKey("reports.id", ondelete="SET NULL"), index=True),
        sa.Column("collection_run_id", sa.BigInteger, sa.ForeignKey("collection_runs.id", ondelete="SET NULL")),
        sa.Column("is_demo", sa.Boolean, nullable=False, server_default=sa.false()),
        ts("text_purged_at", nullable=True),
        ts("created_at", default=True),
        sa.UniqueConstraint("platform", "external_post_id", name="uq_sources_platform_post"),
        check_in("platform", PLATFORMS, "ck_sources_platform"),
        check_in("processing_state", SOURCE_STATES, "ck_sources_state"),
    )

    op.create_table(
        "processing_jobs",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("job_type", sa.String(16), nullable=False),
        sa.Column("status", sa.String(16), nullable=False, server_default="PENDING"),
        sa.Column("source_id", sa.String(40), sa.ForeignKey("sources.id", ondelete="CASCADE")),
        sa.Column("report_id", sa.String(40), sa.ForeignKey("reports.id", ondelete="CASCADE")),
        sa.Column("attempts", sa.Integer, nullable=False, server_default="0"),
        ts("available_at", default=True),
        ts("locked_at", nullable=True),
        sa.Column("locked_by", sa.String(80)),
        sa.Column("last_error", sa.Text),
        sa.Column("result", pg.JSONB),
        ts("created_at", default=True),
        ts("finished_at", nullable=True),
        check_in("job_type", JOB_TYPES, "ck_jobs_type"),
        check_in("status", JOB_STATUSES, "ck_jobs_status"),
        sa.CheckConstraint("source_id IS NOT NULL OR report_id IS NOT NULL", name="ck_jobs_target"),
    )
    op.create_index(
        "ix_jobs_pending",
        "processing_jobs",
        ["job_type", "available_at"],
        postgresql_where=sa.text("status = 'PENDING'"),
    )
    # At most one open job of each type per target, so re-enqueueing is idempotent.
    op.execute(
        "CREATE UNIQUE INDEX uq_jobs_open ON processing_jobs (job_type, source_id, report_id) "
        "NULLS NOT DISTINCT WHERE status IN ('PENDING', 'RUNNING')"
    )

    op.create_table(
        "status_suggestions",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("report_id", sa.String(40), sa.ForeignKey("reports.id", ondelete="CASCADE"), nullable=False),
        sa.Column("suggested_status", sa.String(16), nullable=False),
        sa.Column("reason", sa.String(500), nullable=False, server_default=""),
        sa.Column("fingerprint_hash", sa.String(64), nullable=False),
        sa.Column("review_status", sa.String(16), nullable=False, server_default="PENDING"),
        ts("reviewed_at", nullable=True),
        ts("created_at", default=True),
        sa.UniqueConstraint("report_id", "fingerprint_hash", "suggested_status", name="uq_suggestion_once"),
        check_in("suggested_status", ("RESOLVED", "INACCURATE"), "ck_suggestion_type"),
        check_in("review_status", ("PENDING", "ACCEPTED", "REJECTED"), "ck_suggestion_review"),
    )
    op.create_index("ix_status_suggestions_report_id", "status_suggestions", ["report_id"])
    op.create_index("ix_status_suggestions_fp_time", "status_suggestions", ["fingerprint_hash", "created_at"])

    op.create_table(
        "status_changes",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("report_id", sa.String(40), sa.ForeignKey("reports.id", ondelete="CASCADE"), nullable=False),
        sa.Column("from_status", sa.String(16)),
        sa.Column("to_status", sa.String(16), nullable=False),
        sa.Column("reason", sa.Text, nullable=False),
        sa.Column("actor", sa.String(24), nullable=False),
        ts("created_at", default=True),
        check_in("actor", ("SYSTEM", "OPERATOR_CLI", "SOURCE_EVIDENCE"), "ck_status_changes_actor"),
    )
    op.create_index("ix_status_changes_report_id", "status_changes", ["report_id"])

    op.create_table(
        "report_matches",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("lost_report_id", sa.String(40), sa.ForeignKey("reports.id", ondelete="CASCADE"), nullable=False),
        sa.Column("found_report_id", sa.String(40), sa.ForeignKey("reports.id", ondelete="CASCADE"), nullable=False),
        sa.Column("score", sa.Float, nullable=False),
        sa.Column("breakdown", pg.JSONB, nullable=False),
        sa.Column("distance_km", sa.Float),
        sa.Column("days_apart", sa.Integer),
        ts("created_at", default=True),
        ts("updated_at", default=True),
        sa.UniqueConstraint("lost_report_id", "found_report_id", name="uq_match_pair"),
        sa.CheckConstraint("lost_report_id <> found_report_id", name="ck_match_distinct"),
    )
    op.create_index("ix_report_matches_lost", "report_matches", ["lost_report_id"])
    op.create_index("ix_report_matches_found", "report_matches", ["found_report_id"])

    op.create_table(
        "geocode_cache",
        sa.Column("query_norm", sa.String(300), primary_key=True),
        sa.Column("provider", sa.String(32), nullable=False),
        sa.Column("result", pg.JSONB),
        ts("created_at", default=True),
    )

    op.create_table(
        "worker_heartbeats",
        sa.Column("worker_id", sa.String(80), primary_key=True),
        ts("last_seen"),
        sa.Column("info", pg.JSONB, nullable=False, server_default="{}"),
    )


def downgrade() -> None:
    for table in (
        "worker_heartbeats",
        "geocode_cache",
        "report_matches",
        "status_changes",
        "status_suggestions",
        "processing_jobs",
        "sources",
        "source_states",
        "collection_runs",
        "reports",
        "places",
    ):
        op.drop_table(table)
