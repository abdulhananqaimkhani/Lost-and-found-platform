"""Wiring: builds the pipeline, runner and scheduler from settings."""

from __future__ import annotations

import logging
from datetime import UTC, datetime

from apscheduler.schedulers.blocking import BlockingScheduler
from lf_core.db import session_factory
from lf_core.settings import Settings
from sqlalchemy.orm import Session, sessionmaker

from .ai.extraction import Extractor
from .ai.ollama_client import CircuitBreaker, ConfigurationRefused, OllamaClient
from .ai.openrouter_client import OpenRouterClient
from .collector import load_sources, run_source
from .geocoding.geocoder import ChainGeocoder, GazetteerGeocoder, NominatimGeocoder
from .pipeline import Pipeline
from .runner import Runner, maintenance

log = logging.getLogger("lf_worker")


def build_client(
    settings: Settings, model: str | None = None, *, timeout_s: float | None = None
) -> OllamaClient | OpenRouterClient:
    timeout = settings.ollama_timeout_seconds if timeout_s is None else timeout_s
    if settings.ai_provider == "openrouter":
        return OpenRouterClient(
            model or settings.openrouter_model,
            api_key=settings.openrouter_api_key.get_secret_value() if settings.openrouter_api_key else None,
            timeout_s=timeout,
        )
    return OllamaClient(
        settings.ollama_base_url,
        model or settings.ollama_model,
        api_key=settings.ollama_api_key.get_secret_value() if settings.ollama_api_key else None,
        timeout_s=timeout,
        num_ctx=settings.ollama_num_ctx,
        think=settings.ollama_think,
    )


def build_pipeline(settings: Settings) -> Pipeline:
    try:
        extractor = Extractor(build_client(settings))
    except ConfigurationRefused as exc:
        log.error("%s Extraction jobs will wait until this is fixed.", exc)
        extractor = None
    nominatim = (
        NominatimGeocoder(settings.nominatim_url, settings.nominatim_user_agent) if settings.geocoder_enabled else None
    )
    return Pipeline(settings, extractor, ChainGeocoder(GazetteerGeocoder(), nominatim), CircuitBreaker(60))


def build_runner(settings: Settings, sessions: sessionmaker[Session] | None = None) -> Runner:
    interval = 60 / settings.ai_max_jobs_per_minute if settings.ai_max_jobs_per_minute > 0 else 0
    return Runner(sessions or session_factory(), build_pipeline(settings), ai_min_interval_s=interval)


def check_ai(runner: Runner) -> bool:
    """Update the worker heartbeat and pause requests when the provider is unavailable."""
    extractor = runner.pipeline.extractor
    if extractor is None:
        runner.heartbeat(False, "AI not configured")
        return False
    client = extractor.client
    breaker = runner.pipeline.breaker
    if breaker.is_open:
        runner.heartbeat(False, breaker.last_error or f"{client.provider_name} unavailable")
        return False
    health = client.health()
    if not health.ok:
        breaker.trip(health.message)
        log.warning("%s. Extraction jobs stay queued.", health.message)
    if health.ok and client.is_cloud and not client.inference_verified:
        runner.heartbeat(False, breaker.last_error or f"{client.provider_name} inference is unverified.")
    else:
        runner.heartbeat(health.ok, health.message)
    return health.ok


def run_forever(settings: Settings) -> None:
    sessions = session_factory()
    runner = build_runner(settings, sessions)
    specs = load_sources(settings)
    scheduler = BlockingScheduler(timezone="UTC")
    defaults = {"max_instances": 1, "coalesce": True, "misfire_grace_time": 300}

    for spec in specs:
        ok, why = spec.connector.is_configured()
        if not ok:
            log.info("Not scheduling %s: %s", spec.connector.key, why)
            continue
        scheduler.add_job(
            run_source,
            "interval",
            minutes=spec.interval_minutes,
            args=[sessions, spec],
            id=f"collect:{spec.connector.key}",
            next_run_time=datetime.now(UTC),
            **defaults,
        )
        log.info("Scheduled %s every %d min", spec.connector.key, spec.interval_minutes)

    scheduler.add_job(lambda: check_ai(runner), "interval", seconds=60, id="ai-health", **defaults)
    scheduler.add_job(
        lambda: runner.run_batch(max_jobs=20, max_seconds=50), "interval", seconds=60, id="process-queue", **defaults
    )

    def daily() -> None:
        with sessions() as session:
            result = maintenance(
                session,
                stale_after_days=settings.stale_after_days,
                retention_days=settings.irrelevant_text_retention_days,
            )
            session.commit()
        log.info("Maintenance: %s", result)

    scheduler.add_job(daily, "interval", hours=24, id="maintenance", **defaults)
    check_ai(runner)
    log.info("Worker %s started. Ctrl+C to stop.", runner.worker)
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        log.info("Worker stopped.")
