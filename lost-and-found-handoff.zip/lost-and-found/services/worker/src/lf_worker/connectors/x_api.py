"""X (Twitter) API v2 recent search. Pay-per-use: every post returned costs money, so this connector
has a hard per-run cap and a monthly budget, and stays off unless X_BEARER_TOKEN is set.

Request format follows the official v2 docs: GET /2/tweets/search/recent with query, max_results
(10–100), since_id, tweet.fields. The X Developer Policy applies (e.g. honour deletions).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from lf_core.contracts import NormalizedPost
from lf_core.enums import SourcePlatform

from .base import (
    FetchResult,
    HttpConnector,
    Limits,
    NotConfigured,
    SourceError,
    parse_iso,
    request_with_backoff,
)

API = "https://api.x.com/2/tweets/search/recent"


@dataclass
class XConnector(HttpConnector):
    bearer_token: str | None = field(default=None, repr=False)
    queries: list[str] = field(default_factory=list)
    cost_per_post_usd: float = 0.005
    enabled: bool = False
    platform: SourcePlatform = field(default=SourcePlatform.X, init=False)

    def is_configured(self) -> tuple[bool, str]:
        if not self.enabled:
            return False, "disabled in config/sources.yaml"
        if not self.bearer_token:
            return False, "X_BEARER_TOKEN is not set"
        if not self.queries:
            return False, "no queries configured"
        return True, ""

    def fetch(self, cursor: dict, limits: Limits) -> FetchResult:
        if not self.bearer_token:
            raise NotConfigured("X_BEARER_TOKEN is not set")
        max_posts = limits.max_posts
        if limits.budget_remaining_usd is not None:
            affordable = int(limits.budget_remaining_usd // self.cost_per_post_usd)
            if affordable < 10:  # the API's minimum max_results
                return FetchResult([], cursor, message="Monthly X budget reached; skipping run")
            max_posts = min(max_posts, affordable)

        since = dict(cursor.get("since_id", {}))
        posts: list[NormalizedPost] = []
        returned = 0
        with self.client(headers={"Authorization": f"Bearer {self.bearer_token}"}) as http:
            for query in self.queries:
                remaining = max_posts - returned
                if remaining < 10:
                    break
                params = {
                    "query": f"({query}) -is:retweet",
                    "max_results": min(100, remaining),
                    "tweet.fields": "created_at,lang,conversation_id",
                }
                if since.get(query):
                    params["since_id"] = since[query]
                response = request_with_backoff(http, "GET", API, params=params, sleep=self.sleep)
                if response.status_code in (401, 403):
                    raise SourceError(f"X API refused access ({response.status_code}); check the token and plan")
                if response.status_code >= 400:
                    raise SourceError(f"X API error {response.status_code}")
                body = response.json()
                data = body.get("data", [])
                returned += len(data)
                for tweet in data:
                    published = parse_iso(tweet.get("created_at"))
                    if published is None:
                        continue
                    posts.append(
                        NormalizedPost(
                            source_platform=SourcePlatform.X,
                            source_id=tweet["id"],
                            # The /i/web/status form links to the post without needing (or storing) the author handle.
                            source_url=f"https://x.com/i/web/status/{tweet['id']}",
                            text=tweet.get("text", ""),
                            published_at=published,
                            raw_meta={"thread_id": tweet.get("conversation_id"), "lang": tweet.get("lang")},
                        )
                    )
                newest = body.get("meta", {}).get("newest_id")
                if newest:
                    since[query] = newest
        return FetchResult(
            posts,
            {"since_id": since},
            cost_units=round(returned * self.cost_per_post_usd, 4),
            message=f"{returned} posts returned (billable)",
        )
