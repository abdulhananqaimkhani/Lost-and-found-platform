"""RSS / Atom feeds: content that publishers syndicate on purpose. Each feed is added to
config/sources.yaml only after its terms of use have been checked (recorded next to the feed)."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from urllib.parse import urlsplit

import feedparser
from lf_core.contracts import NormalizedPost
from lf_core.enums import SourcePlatform

from .base import (
    INTENT_WORDS,
    FetchResult,
    HttpConnector,
    Limits,
    SourceError,
    request_with_backoff,
    strip_html,
)


@dataclass
class RssConnector(HttpConnector):
    url: str = ""
    name: str = ""
    require_keywords: bool = True
    publisher: str | None = None
    license_url: str | None = None
    max_age_days: int | None = None
    platform: SourcePlatform = field(default=SourcePlatform.RSS, init=False)

    def is_configured(self) -> tuple[bool, str]:
        if not self.url.startswith("https://"):
            return False, "feed URL must use https"
        if self.publisher and not (self.license_url or "").startswith("https://"):
            return False, "publisher feeds require an HTTPS license or reuse policy URL"
        return True, ""

    def fetch(self, cursor: dict, limits: Limits) -> FetchResult:
        headers = {}
        if cursor.get("etag"):
            headers["If-None-Match"] = cursor["etag"]
        if cursor.get("modified"):
            headers["If-Modified-Since"] = cursor["modified"]
        with self.client() as http:
            response = request_with_backoff(http, "GET", self.url, headers=headers, sleep=self.sleep)
        if response.status_code == 304:
            return FetchResult([], cursor, message="Feed unchanged (304)")
        if response.status_code >= 400:
            raise SourceError(f"Feed returned HTTP {response.status_code}")

        feed = feedparser.parse(response.content)
        if feed.bozo and not feed.entries:
            raise SourceError(f"Feed could not be parsed: {type(feed.bozo_exception).__name__}")

        last_seen = (cursor.get("last_published") or "", cursor.get("last_entry_id") or "")
        legacy_cursor = "last_entry_id" not in cursor
        now = datetime.now(UTC)
        cutoff = now - timedelta(days=self.max_age_days) if self.max_age_days is not None else None
        entries = []
        for entry in feed.entries:
            link = entry.get("link", "")
            try:
                article_url = urlsplit(link)
            except ValueError:
                continue
            if article_url.scheme not in {"http", "https"} or not article_url.hostname:
                continue
            if self.publisher and article_url.hostname != urlsplit(self.url).hostname:
                continue
            parsed_time = entry.get("published_parsed") or entry.get("updated_parsed")
            if not parsed_time and self.publisher:
                continue
            published = datetime(*parsed_time[:6], tzinfo=UTC) if parsed_time else now
            if cutoff and published < cutoff:
                continue
            entry_id = entry.get("id") or hashlib.sha256(link.encode()).hexdigest()
            position = (published.isoformat(), entry_id)
            if position <= last_seen or (legacy_cursor and position[0] == last_seen[0]):
                continue
            entries.append((position, published, link, entry))

        newest = last_seen
        truncated = False
        posts, skipped = [], 0
        for position, published, link, entry in sorted(entries, key=lambda row: row[0]):
            if len(posts) >= limits.max_posts:
                truncated = True
                break
            newest = position
            text = "\n".join(filter(None, [strip_html(entry.get("title", "")), strip_html(entry.get("summary", ""))]))
            if not text.strip():
                continue
            if self.require_keywords and not INTENT_WORDS.search(text):
                skipped += 1
                continue
            metadata = {"feed": self.name}
            if self.publisher:
                byline = strip_html(entry.get("author") or "")[:200]
                if not byline:
                    continue
                metadata.update(publisher=self.publisher, publisher_byline=byline, license_url=self.license_url or "")
            entry_id = entry.get("id") or position[1][:32]
            posts.append(
                NormalizedPost(
                    source_platform=SourcePlatform.RSS,
                    source_id=f"{self.name}:{entry_id}"[:200],
                    source_url=link,
                    text=text[:20_000],
                    published_at=published,
                    raw_meta=metadata,
                )
            )
        new_cursor = {
            "etag": None if truncated else response.headers.get("etag"),
            "modified": None if truncated else response.headers.get("last-modified"),
            "last_published": newest[0] or None,
            "last_entry_id": newest[1] or None,
        }
        return FetchResult(
            posts, new_cursor, message=f"{len(feed.entries)} entries in feed", skipped_irrelevant=skipped
        )
