"""Read-only Reddit Data API search using direct OAuth or an authorized Composio connection."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import UTC, datetime

import httpx
from lf_core.contracts import NormalizedPost
from lf_core.enums import SourcePlatform

from .base import (
    FetchResult,
    HttpConnector,
    Limits,
    NotConfigured,
    RateLimited,
    SourceError,
    request_with_backoff,
    retry_after_seconds,
)

TOKEN_URL = "https://www.reddit.com/api/v1/access_token"  # noqa: S105 - a URL, not a secret
API = "https://oauth.reddit.com"
COMPOSIO_PROXY = "https://backend.composio.dev/api/v3/tools/execute/proxy"
COMPOSIO_ACCOUNTS = "https://backend.composio.dev/api/v3.1/connected_accounts"


@dataclass
class RedditConnector(HttpConnector):
    client_id: str | None = None
    client_secret: str | None = field(default=None, repr=False)
    user_agent: str | None = None
    subreddits: list[str] = field(default_factory=list)
    query: str = "lost OR found"
    approved: bool = False
    access_method: str = "direct"
    composio_api_key: str | None = field(default=None, repr=False)
    composio_account_id: str | None = None
    composio_user_id: str | None = None
    platform: SourcePlatform = field(default=SourcePlatform.REDDIT, init=False)

    def is_configured(self) -> tuple[bool, str]:
        if not self.approved:
            return False, "Reddit API access not approved (set approved: true only after Reddit approves it)"
        if not self.subreddits or any(not re.fullmatch(r"[A-Za-z0-9_]+", sub) for sub in self.subreddits):
            return False, "Reddit requires valid subreddit names"
        if self.access_method == "composio":
            if not self.composio_api_key:
                return False, "COMPOSIO_API_KEY not set"
            return True, ""
        if self.access_method != "direct":
            return False, "Reddit transport must be direct or composio"
        if not (self.client_id and self.client_secret and self.user_agent):
            return False, "REDDIT_CLIENT_ID / REDDIT_CLIENT_SECRET / REDDIT_USER_AGENT not set"
        return True, ""

    def _token(self, http: httpx.Client) -> str:
        response = request_with_backoff(
            http,
            "POST",
            TOKEN_URL,
            data={"grant_type": "client_credentials"},
            auth=(self.client_id or "", self.client_secret or ""),
            max_retries=0,
            follow_redirects=False,
            sleep=self.sleep,
        )
        if response.status_code != 200:
            raise SourceError(f"Reddit token request failed ({response.status_code})")
        return response.json()["access_token"]

    def _composio_connection(self, http: httpx.Client) -> tuple[str, str | None]:
        if self.composio_account_id:
            return self.composio_account_id, self.composio_user_id
        params = {"toolkit_slugs": "reddit", "statuses": "ACTIVE", "limit": 2}
        if self.composio_user_id:
            params["user_ids"] = self.composio_user_id
        response = request_with_backoff(
            http,
            "GET",
            COMPOSIO_ACCOUNTS,
            params=params,
            headers={"x-api-key": self.composio_api_key or ""},
            max_retries=0,
            follow_redirects=False,
            sleep=self.sleep,
        )
        if not response.is_success:
            raise SourceError(f"Composio connected accounts request failed ({response.status_code})")
        body = response.json()
        if not isinstance(body, dict) or not isinstance(body.get("items"), list):
            raise SourceError("Composio returned an invalid connected accounts response")
        accounts = body["items"]
        if not accounts:
            raise SourceError("No active Reddit connection in this Composio project")
        if len(accounts) != 1 or body.get("next_cursor"):
            raise SourceError("Multiple active Reddit connections; set COMPOSIO_REDDIT_ACCOUNT_ID")
        account = accounts[0]
        if (
            not isinstance(account, dict)
            or account.get("toolkit", {}).get("slug") != "reddit"
            or account.get("status") != "ACTIVE"
            or not account.get("id")
        ):
            raise SourceError("Composio did not return an active Reddit connection")
        return account["id"], self.composio_user_id or account.get("user_id")

    def _search(
        self,
        http: httpx.Client,
        sub: str,
        token: str | None,
        limit: int,
        connection: tuple[str, str | None] | None,
    ) -> dict:
        url = f"{API}/r/{sub}/search"
        params = {"q": self.query, "restrict_sr": 1, "sort": "new", "limit": limit}
        if connection:
            account_id, user_id = connection
            payload = {
                "endpoint": url,
                "method": "GET",
                "connected_account_id": account_id,
                "parameters": [{"name": name, "value": str(value), "type": "query"} for name, value in params.items()],
            }
            if user_id:
                payload["user_id"] = user_id
            # Keep the Composio credential on its own HTTPS origin.
            response = request_with_backoff(
                http,
                "POST",
                COMPOSIO_PROXY,
                json=payload,
                headers={"x-api-key": self.composio_api_key or ""},
                max_retries=0,
                follow_redirects=False,
                sleep=self.sleep,
            )
            if not response.is_success:
                raise SourceError(f"Composio API error {response.status_code} for r/{sub}")
            wrapped = response.json()
            if not isinstance(wrapped, dict):
                raise SourceError(f"Reddit search via Composio failed for r/{sub}")
            status = wrapped.get("status")
            if status == 429:
                upstream = httpx.Response(429, headers=wrapped.get("headers") or {})
                hint = max(retry_after_seconds(response) or 0, retry_after_seconds(upstream) or 0)
                raise RateLimited("Reddit rate limit via Composio", hint)
            if isinstance(status, int) and status != 200:
                raise SourceError(f"Reddit returned HTTP {status} via Composio for r/{sub}")
            if status != 200 or not isinstance(wrapped.get("data"), dict):
                raise SourceError(f"Composio returned an invalid Reddit response for r/{sub}")
            return wrapped["data"]
        response = request_with_backoff(
            http,
            "GET",
            url,
            headers={"Authorization": f"bearer {token}", "User-Agent": self.user_agent or ""},
            max_retries=0,
            follow_redirects=False,
            sleep=self.sleep,
            params=params,
        )
        if not response.is_success:
            raise SourceError(f"Reddit API error {response.status_code} for r/{sub}")
        return response.json()

    def fetch(self, cursor: dict, limits: Limits) -> FetchResult:
        ok, why = self.is_configured()
        if not ok:
            raise NotConfigured(why)
        last = dict(cursor.get("last_created", {}))
        posts: list[NormalizedPost] = []
        with self.client(headers={"User-Agent": self.user_agent or ""}) as http:
            token = self._token(http) if self.access_method == "direct" else None
            connection = self._composio_connection(http) if self.access_method == "composio" else None
            for sub in self.subreddits:
                body = self._search(http, sub, token, min(100, limits.max_posts), connection)
                newest = last.get(sub, 0)
                for child in body.get("data", {}).get("children", []):
                    d = child.get("data", {})
                    created = float(d.get("created_utc", 0))
                    if created <= last.get(sub, 0):
                        continue
                    newest = max(newest, created)
                    text = "\n".join(filter(None, [d.get("title", ""), d.get("selftext", "")]))
                    posts.append(
                        NormalizedPost(
                            source_platform=SourcePlatform.REDDIT,
                            source_id=d["name"],
                            source_url=f"https://www.reddit.com{d['permalink']}",
                            text=text[:20_000],
                            published_at=datetime.fromtimestamp(created, UTC),
                            raw_meta={
                                "thread_id": d.get("name"),
                                "subreddit": sub,
                                "scope": "karachi" if sub.lower() == "karachi" else None,
                            },
                        )
                    )
                last[sub] = newest
        return FetchResult(posts[: limits.max_posts], {"last_created": last})
