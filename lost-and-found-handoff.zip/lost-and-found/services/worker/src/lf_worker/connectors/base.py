"""Connector contract (PROJECT_PLAN.md §4.1) and shared HTTP behaviour.

A connector turns one authorized source into NormalizedPost objects. It never scrapes, never logs in
with a person's credentials through a browser, and never works around a platform's restrictions.
Adding a platform = adding one class with `is_configured()` and `fetch()`.
"""

from __future__ import annotations

import html
import random
import re
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from typing import Protocol

import httpx
from lf_core.contracts import NormalizedPost
from lf_core.enums import SourcePlatform

USER_AGENT = "LostAndFoundFinder-dev/0.1 (university final year project)"

# Cheap relevance gate applied by connectors that search broad feeds (e.g. news RSS), so the
# system doesn't store large amounts of unrelated text. The pipeline's prefilter is stricter.
INTENT_WORDS = re.compile(
    r"\b(lost|found|missing|misplaced|left behind|kho|gum|mil gaya|mila|mili|gir gaya|reh gaya)\b|گم|کھو|مل گیا|ملا",
    re.IGNORECASE,
)


@dataclass
class Limits:
    max_posts: int = 50
    budget_remaining_usd: float | None = None


@dataclass
class FetchResult:
    posts: list[NormalizedPost]
    cursor: dict
    cost_units: float = 0.0
    message: str = ""
    skipped_irrelevant: int = 0


class SourceError(Exception):
    """The source failed in a way that should count towards pausing it."""


class RateLimited(SourceError):
    def __init__(self, message: str, retry_after_s: float | None = None):
        super().__init__(message)
        self.retry_after_s = retry_after_s


class NotConfigured(SourceError):
    pass


class Connector(Protocol):
    key: str
    platform: SourcePlatform

    def is_configured(self) -> tuple[bool, str]: ...

    def fetch(self, cursor: dict, limits: Limits) -> FetchResult: ...


def retry_after_seconds(response: httpx.Response, now: datetime | None = None) -> float | None:
    """Seconds to wait, from Retry-After (seconds or HTTP date) or X's x-rate-limit-reset (epoch)."""
    value = response.headers.get("retry-after")
    if value:
        if value.strip().isdigit():
            return float(value)
        try:
            when = parsedate_to_datetime(value)
            return max(0.0, (when - (now or datetime.now(UTC))).total_seconds())
        except (TypeError, ValueError):
            pass
    reset = response.headers.get("x-rate-limit-reset") or response.headers.get("x-ratelimit-reset")
    if reset and reset.strip().replace(".", "", 1).isdigit():
        number = float(reset)
        # Reddit sends seconds-until-reset; X sends an epoch timestamp.
        return max(0.0, number - (now or datetime.now(UTC)).timestamp()) if number > 1e9 else number
    return None


def request_with_backoff(
    client: httpx.Client,
    method: str,
    url: str,
    *,
    max_retries: int = 3,
    max_wait_s: float = 60.0,
    sleep=time.sleep,
    **kwargs,
) -> httpx.Response:
    """Retry 429 and 5xx with exponential backoff and jitter, honouring the server's wait hints.
    A wait longer than max_wait_s is not slept through: the run ends and the source is retried later."""
    for attempt in range(max_retries + 1):
        try:
            response = client.request(method, url, **kwargs)
        except httpx.TransportError as exc:
            if attempt == max_retries:
                raise SourceError(f"Network error: {type(exc).__name__}") from exc
            sleep(min(max_wait_s, 2**attempt + random.uniform(0, 1)))
            continue
        if response.status_code == 429 or response.status_code >= 500:
            hinted = retry_after_seconds(response)
            if response.status_code == 429 and hinted is not None and hinted > max_wait_s:
                raise RateLimited(f"Rate limited for {hinted:.0f}s", hinted)
            if attempt == max_retries:
                if response.status_code == 429:
                    raise RateLimited("Rate limited", hinted)
                raise SourceError(f"Server error {response.status_code}")
            sleep(min(max_wait_s, hinted if hinted is not None else 2**attempt + random.uniform(0, 1)))
            continue
        return response
    raise AssertionError("unreachable")


_TAGS = re.compile(r"<[^>]+>")
_SPACE = re.compile(r"[ \t\r\f\v]+")


def strip_html(text: str) -> str:
    text = re.sub(r"<br\s*/?>|</p>", "\n", text or "", flags=re.IGNORECASE)
    text = html.unescape(_TAGS.sub(" ", text)).replace(" ", " ")
    return "\n".join(_SPACE.sub(" ", line).strip() for line in text.splitlines() if line.strip())


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


def not_too_old(published: datetime, max_age_days: int = 60) -> bool:
    return published >= datetime.now(UTC) - timedelta(days=max_age_days)


@dataclass
class HttpConnector:
    """Common fields; subclasses implement is_configured/fetch."""

    key: str
    transport: httpx.BaseTransport | None = field(default=None, repr=False)
    sleep: object = field(default=time.sleep, repr=False)

    def client(self, **kwargs) -> httpx.Client:
        headers = {"User-Agent": USER_AGENT, **kwargs.pop("headers", {})}
        return httpx.Client(timeout=20, headers=headers, transport=self.transport, follow_redirects=True, **kwargs)
