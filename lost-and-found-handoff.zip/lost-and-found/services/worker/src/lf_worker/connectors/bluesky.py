"""Bluesky (AT Protocol) post search via the documented app.bsky.feed.searchPosts endpoint.

Authenticated with a free account's *app password* (not the account password), which is the method
Bluesky provides for third-party apps. Bluesky is an open protocol; public posts are public data."""

from __future__ import annotations

from dataclasses import dataclass, field

import httpx
from lf_core.contracts import NormalizedPost
from lf_core.enums import SourcePlatform

from .base import (
    FetchResult,
    HttpConnector,
    Limits,
    NotConfigured,
    SourceError,
    parse_iso,
    request_with_backoff,
)

PDS = "https://bsky.social/xrpc"


def post_url(uri: str) -> str | None:
    # at://did:plc:abc/app.bsky.feed.post/3kxyz → https://bsky.app/profile/did:plc:abc/post/3kxyz
    if not uri.startswith("at://"):
        return None
    parts = uri[5:].split("/")
    if len(parts) != 3 or parts[1] != "app.bsky.feed.post":
        return None
    return f"https://bsky.app/profile/{parts[0]}/post/{parts[2]}"


@dataclass
class BlueskyConnector(HttpConnector):
    handle: str | None = None
    app_password: str | None = field(default=None, repr=False)
    queries: list[str] = field(default_factory=list)
    enabled: bool = False
    platform: SourcePlatform = field(default=SourcePlatform.BLUESKY, init=False)

    def is_configured(self) -> tuple[bool, str]:
        if not self.enabled:
            return False, "disabled in config/sources.yaml"
        if not (self.handle and self.app_password):
            return False, "BLUESKY_HANDLE / BLUESKY_APP_PASSWORD not set"
        return True, ""

    def _session(self, http: httpx.Client) -> str:
        response = request_with_backoff(
            http,
            "POST",
            f"{PDS}/com.atproto.server.createSession",
            json={"identifier": self.handle, "password": self.app_password},
            sleep=self.sleep,
        )
        if response.status_code != 200:
            raise SourceError(f"Bluesky login failed ({response.status_code})")
        return response.json()["accessJwt"]

    def fetch(self, cursor: dict, limits: Limits) -> FetchResult:
        ok, why = self.is_configured()
        if not ok:
            raise NotConfigured(why)
        last = dict(cursor.get("last_indexed", {}))
        posts: list[NormalizedPost] = []
        with self.client() as http:
            token = self._session(http)
            for query in self.queries:
                response = request_with_backoff(
                    http,
                    "GET",
                    f"{PDS}/app.bsky.feed.searchPosts",
                    headers={"Authorization": f"Bearer {token}"},
                    params={"q": query, "sort": "latest", "limit": min(100, limits.max_posts)},
                    sleep=self.sleep,
                )
                if response.status_code >= 400:
                    raise SourceError(f"Bluesky search failed ({response.status_code})")
                newest = last.get(query, "")
                for item in response.json().get("posts", []):
                    indexed = item.get("indexedAt", "")
                    if indexed <= last.get(query, ""):
                        continue
                    newest = max(newest, indexed)
                    url = post_url(item.get("uri", ""))
                    record = item.get("record", {})
                    published = parse_iso(record.get("createdAt")) or parse_iso(indexed)
                    if not url or published is None or not record.get("text"):
                        continue
                    root = ((record.get("reply") or {}).get("root") or {}).get("uri") or item["uri"]
                    posts.append(
                        NormalizedPost(
                            source_platform=SourcePlatform.BLUESKY,
                            source_id=item["uri"],
                            source_url=url,
                            text=record["text"],
                            published_at=published,
                            raw_meta={"thread_id": root, "langs": record.get("langs")},
                        )
                    )
                last[query] = newest
        return FetchResult(posts[: limits.max_posts], {"last_indexed": last})
