"""Mastodon public hashtag timelines (GET /api/v1/timelines/tag/:hashtag), which instances expose
publicly unless their admins disable it. Only instances listed in config/sources.yaml are queried."""

from __future__ import annotations

from dataclasses import dataclass, field

from lf_core.contracts import NormalizedPost
from lf_core.enums import SourcePlatform

from .base import (
    INTENT_WORDS,
    FetchResult,
    HttpConnector,
    Limits,
    SourceError,
    parse_iso,
    request_with_backoff,
    strip_html,
)


@dataclass
class MastodonConnector(HttpConnector):
    instance: str = ""
    hashtags: list[str] = field(default_factory=list)
    enabled: bool = False
    platform: SourcePlatform = field(default=SourcePlatform.MASTODON, init=False)

    def is_configured(self) -> tuple[bool, str]:
        if not self.enabled:
            return False, "disabled in config/sources.yaml"
        if not self.instance.startswith("https://") or not self.hashtags:
            return False, "instance (https) and hashtags are required"
        return True, ""

    def fetch(self, cursor: dict, limits: Limits) -> FetchResult:
        since = dict(cursor.get("since_id", {}))
        posts: list[NormalizedPost] = []
        skipped = 0
        with self.client() as http:
            for tag in self.hashtags:
                params = {"limit": min(40, limits.max_posts)}
                if since.get(tag):
                    params["since_id"] = since[tag]
                response = request_with_backoff(
                    http,
                    "GET",
                    f"{self.instance.rstrip('/')}/api/v1/timelines/tag/{tag}",
                    params=params,
                    sleep=self.sleep,
                )
                if response.status_code >= 400:
                    raise SourceError(f"Mastodon {self.instance} returned {response.status_code} for #{tag}")
                statuses = response.json()
                for status in statuses:
                    if status.get("visibility") not in (None, "public") or status.get("reblog"):
                        continue
                    published = parse_iso(status.get("created_at"))
                    text = strip_html(status.get("content", ""))
                    if not published or not text or not status.get("url"):
                        continue
                    if not INTENT_WORDS.search(text):
                        skipped += 1  # broad hashtags: keep only lost/found posts, store nothing else
                        continue
                    posts.append(
                        NormalizedPost(
                            source_platform=SourcePlatform.MASTODON,
                            source_id=status["uri"][:200],
                            source_url=status["url"],
                            text=text,
                            published_at=published,
                            raw_meta={
                                "thread_id": status.get("in_reply_to_id") or status.get("id"),
                                "instance": self.instance,
                                "lang": status.get("language"),
                                "hashtag": tag,
                                "scope": "karachi" if "karachi" in tag.lower() else None,
                            },
                        )
                    )
                if statuses:
                    since[tag] = max((s["id"] for s in statuses), key=lambda v: (len(v), v))
        return FetchResult(posts[: limits.max_posts], {"since_id": since}, skipped_irrelevant=skipped)
