"""Possible matches between LOST and FOUND reports, and near-duplicate detection (PROJECT_PLAN.md §11).

A match is only ever shown as "possible": the score explains *why* two reports look related,
it never claims they are the same item.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta

from lf_core.enums import ReportStatus, StatusActor
from lf_core.models import Geography, Report, ReportMatch
from lf_core.scoring import RELATED_CATEGORIES, ScoredPair, score_pair
from lf_core.status import change_status
from lf_core.text import normalize_text
from rapidfuzz import fuzz
from sqlalchemy import func, or_, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

CANDIDATE_RADIUS_M = 5000
CANDIDATE_DAYS = 14


def describe(report: Report) -> str:
    attrs = report.attributes or {}
    return normalize_text(
        " ".join(filter(None, [report.item_name, report.description, attrs.get("colour"), attrs.get("brand")]))
    )


def text_similarity(a: Report, b: Report) -> float:
    return fuzz.token_set_ratio(describe(a), describe(b)) / 100


def _when(report: Report) -> date | datetime:
    return report.incident_date or report.reported_at


def related_categories(category: str) -> list[str]:
    related = {category}
    for pair in RELATED_CATEGORIES:
        if category in pair:
            related |= pair
    return sorted(related)


def candidates(session: Session, report: Report) -> list[Report]:
    opposite = "FOUND" if report.report_type == "LOST" else "LOST"
    when = _when(report)
    day = when.date() if isinstance(when, datetime) else when
    effective_day = func.coalesce(Report.incident_date, func.date(Report.reported_at))
    conds = [
        Report.report_type == opposite,
        Report.item_category.in_(related_categories(report.item_category)),
        Report.status.notin_([ReportStatus.RESOLVED.value, ReportStatus.DISPUTED.value]),
        Report.is_demo.is_(report.is_demo),
        effective_day.between(day - timedelta(days=CANDIDATE_DAYS), day + timedelta(days=CANDIDATE_DAYS)),
    ]
    if report.latitude is not None:
        point = func.ST_SetSRID(func.ST_MakePoint(report.longitude, report.latitude), 4326).cast(Geography())
        conds.append(
            or_(
                func.ST_DWithin(Report.geog, point, CANDIDATE_RADIUS_M, False),
                Report.latitude.is_(None) & (func.lower(Report.city) == (report.city or "karachi").lower()),
            )
        )
    elif report.city:
        conds.append(func.lower(Report.city) == report.city.lower())
    return list(session.scalars(select(Report).where(*conds).limit(200)).all())


def score(a: Report, b: Report) -> ScoredPair:
    return score_pair(
        category_a=a.item_category,
        category_b=b.item_category,
        text_similarity=text_similarity(a, b),
        coords_a=(a.latitude, a.longitude) if a.latitude is not None else None,
        coords_b=(b.latitude, b.longitude) if b.latitude is not None else None,
        when_a=_when(a),
        when_b=_when(b),
        attributes_a=a.attributes,
        attributes_b=b.attributes,
    )


def find_and_store_matches(session: Session, report: Report, threshold: float) -> list[tuple[Report, ScoredPair]]:
    stored = []
    for other in candidates(session, report):
        pair = score(report, other)
        if pair.score < threshold:
            continue
        lost, found = (report, other) if report.report_type == "LOST" else (other, report)
        values = {
            "lost_report_id": lost.id,
            "found_report_id": found.id,
            "score": pair.score,
            "breakdown": pair.breakdown,
            "distance_km": pair.distance_km,
            "days_apart": pair.days_apart,
        }
        stmt = pg_insert(ReportMatch).values(**values)
        session.execute(
            stmt.on_conflict_do_update(
                constraint="uq_match_pair",
                set_={k: stmt.excluded[k] for k in ("score", "breakdown", "distance_km", "days_apart")},
            )
        )
        for r in (lost, found):
            if r.status == ReportStatus.ACTIVE.value:
                change_status(
                    session,
                    r,
                    ReportStatus.POTENTIAL_MATCH,
                    reason=f"Possible match scored {pair.score:.2f}",
                    actor=StatusActor.SYSTEM,
                )
        stored.append((other, pair))
    return stored


def near_duplicate(
    session: Session,
    *,
    report_type: str,
    category: str,
    text: str,
    published_at: datetime,
    location_text: str | None,
    is_demo: bool = False,
) -> Report | None:
    """The same incident posted again (reworded, or on another platform) → attach, don't create."""
    window = timedelta(days=7)
    reports = session.scalars(
        select(Report)
        .where(
            Report.report_type == report_type,
            Report.item_category == category,
            Report.is_demo.is_(is_demo),
            Report.reported_at.between(published_at - window, published_at + window),
        )
        .limit(200)
    ).all()
    norm = normalize_text(text)
    for report in reports:
        for source in report.sources:
            if not source.original_text:
                continue
            if fuzz.token_set_ratio(norm, normalize_text(source.original_text)) < 90:
                continue
            if (
                location_text
                and report.location_text
                and fuzz.token_set_ratio(normalize_text(location_text), normalize_text(report.location_text)) < 60
            ):
                continue
            return report
    return None
