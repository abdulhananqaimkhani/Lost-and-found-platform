"""Stage 2: classify the post and extract its facts as JSON in one Ollama call."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from lf_core.enums import ItemCategory
from lf_core.text import redact_text
from pydantic import BaseModel, Field, ValidationError, field_validator

from .ollama_client import ChatStats, OllamaBadOutput, OllamaClient
from .openrouter_client import OpenRouterClient

MAX_POST_CHARS = 1500
CATEGORIES = [c.value for c in ItemCategory]


class ExtractionResult(BaseModel):
    report_type: Literal["LOST", "FOUND", "IRRELEVANT", "UNCERTAIN"]
    item_name: str | None = Field(default=None, max_length=120)
    item_category: Literal[tuple(CATEGORIES)] | None = None  # type: ignore[valid-type]
    description: str | None = Field(default=None, max_length=400)
    colour: str | None = Field(default=None, max_length=40)
    brand: str | None = Field(default=None, max_length=60)
    location_text: str | None = Field(default=None, max_length=200)
    city: str | None = Field(default=None, max_length=60)
    date_expression: str | None = Field(default=None, max_length=100)
    is_resolution_update: bool = False
    confidence: float = Field(default=0.5, ge=0, le=1)

    @field_validator("item_name", "description", "colour", "brand", "location_text", "city", "date_expression")
    @classmethod
    def _blank_to_none(cls, value: str | None) -> str | None:
        if value is None:
            return None
        value = value.strip()
        return None if value.lower() in {"", "null", "none", "unknown", "n/a", "not stated", "not mentioned"} else value

    @field_validator("confidence", mode="before")
    @classmethod
    def _clamp(cls, value: object) -> object:
        if isinstance(value, int | float):
            return min(1.0, max(0.0, float(value)))
        return value


def _nullable(kind: str, **extra) -> dict:
    return {"type": [kind, "null"], **extra}


# Hand-written (instead of Pydantic's generated schema) to keep it small: every token of the
# schema is processed by the model on every call.
OLLAMA_SCHEMA: dict = {
    "type": "object",
    "properties": {
        "report_type": {"type": "string", "enum": ["LOST", "FOUND", "IRRELEVANT", "UNCERTAIN"]},
        "item_name": _nullable("string"),
        "item_category": {"type": ["string", "null"], "enum": [*CATEGORIES, None]},
        "description": _nullable("string"),
        "colour": _nullable("string"),
        "brand": _nullable("string"),
        "location_text": _nullable("string"),
        "city": _nullable("string"),
        "date_expression": _nullable("string"),
        "is_resolution_update": {"type": "boolean"},
        "confidence": {"type": "number"},
    },
    "required": [
        "report_type",
        "item_name",
        "item_category",
        "description",
        "colour",
        "brand",
        "location_text",
        "city",
        "date_expression",
        "is_resolution_update",
        "confidence",
    ],
}

SYSTEM_PROMPT = f"""You read public social media posts about lost or found items in Karachi, Pakistan, and extract facts as JSON.
Posts can be in English, Roman Urdu (Urdu written in English letters) or Urdu script.

Rules:
- report_type: LOST if the writer lost something. FOUND if the writer found something that belongs to someone else.
  IRRELEVANT if the post is not about a lost or found object or pet (sports, news, adverts, sales, jokes, feelings).
  Rediscovering an item among one's own possessions, reviewing it, or showing it off is IRRELEVANT.
  FOUND requires a genuine lost-property event involving someone else's belongings or an unknown owner.
  Posts about missing or found PEOPLE are IRRELEVANT for this app. UNCERTAIN if you cannot tell.
- item_name: a short English name for the item, e.g. "black leather wallet".
- item_category: one of {", ".join(CATEGORIES)}.
  ID cards, licences, certificates and papers are DOCUMENT_ID. Purses are WALLET. Watches, earbuds, chargers,
  laptops and tablets are ELECTRONICS. Glasses, shoes and clothes are CLOTHING. Bikes, cycles, helmets and
  number plates are VEHICLE. Anything else is OTHER.
- location_text and date_expression: copy the exact words from the post. Do not translate, correct or guess.
- city: only if the post names a city.
- colour and brand: only if the post states them.
- description: one short English sentence about the item, using only facts in the post.
  Never include names, phone numbers, ID numbers or addresses of people.
- is_resolution_update: true only if the post says the item has already been returned or the owner was found.
- confidence: from 0 to 1, how sure you are about report_type.
Never invent information. Use null for anything the post does not say."""

# Few-shot examples. These posts are written for the prompt only and are NOT in the evaluation set.
FEW_SHOT: list[tuple[str, dict]] = [
    (
        "Lost my brown leather wallet yesterday evening near Dolmen Mall Tariq Road. Has my CNIC and some cash. "
        "Please DM if found, reward guaranteed.",
        {
            "report_type": "LOST",
            "item_name": "brown leather wallet",
            "item_category": "WALLET",
            "description": "Brown leather wallet containing a CNIC and cash.",
            "colour": "brown",
            "brand": None,
            "location_text": "near Dolmen Mall Tariq Road",
            "city": None,
            "date_expression": "yesterday evening",
            "is_resolution_update": False,
            "confidence": 0.95,
        },
    ),
    (
        "Aaj subah North Nazimabad Block H ke bus stop pe ek Samsung mobile mila hai, blue cover. "
        "Jis ka hai wo nishani bata kar le jaye.",
        {
            "report_type": "FOUND",
            "item_name": "Samsung mobile phone",
            "item_category": "PHONE",
            "description": "Samsung phone with a blue cover found at a bus stop.",
            "colour": "blue",
            "brand": "Samsung",
            "location_text": "North Nazimabad Block H ke bus stop",
            "city": None,
            "date_expression": "Aaj subah",
            "is_resolution_update": False,
            "confidence": 0.93,
        },
    ),
    (
        "میرا شناختی کارڈ صدر میں کہیں گر گیا ہے۔ کسی کو ملے تو رابطہ کریں۔",
        {
            "report_type": "LOST",
            "item_name": "CNIC card",
            "item_category": "DOCUMENT_ID",
            "description": "National identity card dropped somewhere.",
            "colour": None,
            "brand": None,
            "location_text": "صدر",
            "city": None,
            "date_expression": None,
            "is_resolution_update": False,
            "confidence": 0.9,
        },
    ),
    (
        "We lost the match by 3 wickets yesterday but found our form again. Karachi Kings next week!",
        {
            "report_type": "IRRELEVANT",
            "item_name": None,
            "item_category": None,
            "description": None,
            "colour": None,
            "brand": None,
            "location_text": None,
            "city": "Karachi",
            "date_expression": None,
            "is_resolution_update": False,
            "confidence": 0.97,
        },
    ),
    (
        "UPDATE: the grey cat we found near Bahadurabad chowrangi has gone home to her family. Thanks everyone!",
        {
            "report_type": "FOUND",
            "item_name": "grey cat",
            "item_category": "PET",
            "description": "Grey cat that has now been returned to its family.",
            "colour": "grey",
            "brand": None,
            "location_text": "near Bahadurabad chowrangi",
            "city": None,
            "date_expression": None,
            "is_resolution_update": True,
            "confidence": 0.9,
        },
    ),
]


def build_messages(text: str, *, article: bool = False) -> list[dict]:
    import json

    system = SYSTEM_PROMPT
    if article:
        system += (
            "\n\nThe final input is a newspaper or news article excerpt. Use LOST when it reports that someone "
            "lost a specific item or pet, and FOUND when someone found one, even when written in the third person. "
            "Only classify an actual lost-property or pet notice with a clear case. General news, unrelated uses of "
            "'lost' or 'found', missing people, and crime stories without a specific recovery appeal are IRRELEVANT. "
            "Use only evidence in the supplied article excerpt."
        )
    messages = [{"role": "system", "content": system}]
    for post, answer in FEW_SHOT:
        messages.append({"role": "user", "content": f"Post:\n{post}"})
        messages.append({"role": "assistant", "content": json.dumps(answer, ensure_ascii=False)})
    label = "Article" if article else "Post"
    messages.append({"role": "user", "content": f"{label}:\n{text[:MAX_POST_CHARS]}"})
    return messages


@dataclass
class ExtractionOutcome:
    result: ExtractionResult
    raw: str
    model: str
    attempts: int
    stats: list[ChatStats] = field(default_factory=list)

    @property
    def latency_s(self) -> float:
        return sum(s.latency_s for s in self.stats)


class Extractor:
    """Runs the extraction call, with one repair attempt if the output doesn't validate."""

    def __init__(self, client: OllamaClient | OpenRouterClient):
        self.client = client

    @property
    def model(self) -> str:
        return self.client.model

    def extract(self, text: str, *, article: bool = False) -> ExtractionOutcome:
        messages = build_messages(redact_text(text) if self.client.is_cloud else text, article=article)
        stats: list[ChatStats] = []
        raw = ""
        for attempt in (1, 2):
            try:
                parsed, raw, stat = self.client.chat_json(messages, OLLAMA_SCHEMA)
                stats.append(stat)
                return ExtractionOutcome(
                    ExtractionResult.model_validate(parsed), raw, self.client.model, attempt, stats
                )
            except (OllamaBadOutput, ValidationError) as exc:
                raw = getattr(exc, "raw", raw) or raw
                if attempt == 2:
                    raise OllamaBadOutput(f"Invalid model output after a repair attempt: {exc}", raw) from exc
                messages = [
                    *messages,
                    {"role": "assistant", "content": raw[:2000]},
                    {
                        "role": "user",
                        "content": "That answer was not valid. Reply with only one JSON object that "
                        "follows the schema exactly.",
                    },
                ]
        raise AssertionError("unreachable")
