"""Resolve the date phrase the AI copied from the post ("kal shaam", "22 Nov", "2 din pehle")
into a calendar date, relative to when the post was published.

The AI never outputs dates itself (PROJECT_PLAN.md §5.3): small models are bad at date arithmetic,
and a wrong date presented as fact is worse than "date not stated".
"""

from __future__ import annotations

import re
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

from lf_core.enums import DatePrecision

KARACHI = ZoneInfo("Asia/Karachi")

MONTHS = {
    "jan": 1,
    "january": 1,
    "feb": 2,
    "february": 2,
    "mar": 3,
    "march": 3,
    "apr": 4,
    "april": 4,
    "may": 5,
    "jun": 6,
    "june": 6,
    "jul": 7,
    "july": 7,
    "aug": 8,
    "august": 8,
    "sep": 9,
    "sept": 9,
    "september": 9,
    "oct": 10,
    "october": 10,
    "nov": 11,
    "november": 11,
    "dec": 12,
    "december": 12,
}
WEEKDAYS = {
    "monday": 0,
    "mon": 0,
    "peer": 0,
    "pir": 0,
    "tuesday": 1,
    "tue": 1,
    "mangal": 1,
    "wednesday": 2,
    "wed": 2,
    "budh": 2,
    "budh ko": 2,
    "thursday": 3,
    "thu": 3,
    "jumerat": 3,
    "jumeraat": 3,
    "friday": 4,
    "fri": 4,
    "juma": 4,
    "jumma": 4,
    "jummah": 4,
    "saturday": 5,
    "sat": 5,
    "hafta": 5,
    "sunday": 6,
    "sun": 6,
    "itwar": 6,
    "itwaar": 6,
    "atwar": 6,
    "پیر": 0,
    "منگل": 1,
    "بدھ": 2,
    "جمعرات": 3,
    "جمعہ": 4,
    "ہفتہ": 5,
    "اتوار": 6,
}

# Relative phrases → (days before the post, precision). Checked longest-first.
RELATIVE = [
    ("day before yesterday", 2, DatePrecision.EXACT),
    ("parson", 2, DatePrecision.APPROXIMATE),
    ("parso", 2, DatePrecision.APPROXIMATE),
    ("پرسوں", 2, DatePrecision.APPROXIMATE),
    ("yesterday", 1, DatePrecision.EXACT),
    ("last night", 1, DatePrecision.EXACT),
    ("kal raat", 1, DatePrecision.EXACT),
    ("kal shaam", 1, DatePrecision.EXACT),
    ("kal subah", 1, DatePrecision.EXACT),
    ("kal", 1, DatePrecision.EXACT),
    ("kl", 1, DatePrecision.EXACT),
    ("گزشتہ روز", 1, DatePrecision.EXACT),
    ("کل", 1, DatePrecision.EXACT),
    ("today", 0, DatePrecision.EXACT),
    ("this morning", 0, DatePrecision.EXACT),
    ("tonight", 0, DatePrecision.EXACT),
    ("this evening", 0, DatePrecision.EXACT),
    ("this afternoon", 0, DatePrecision.EXACT),
    ("aaj", 0, DatePrecision.EXACT),
    ("aj", 0, DatePrecision.EXACT),
    ("abhi", 0, DatePrecision.EXACT),
    ("آج", 0, DatePrecision.EXACT),
    ("last week", 7, DatePrecision.APPROXIMATE),
    ("pichle hafte", 7, DatePrecision.APPROXIMATE),
    ("pichlay haftay", 7, DatePrecision.APPROXIMATE),
    ("گزشتہ ہفتے", 7, DatePrecision.APPROXIMATE),
]
N_DAYS_AGO = re.compile(r"(\d{1,2})\s*(?:days?|din)\s*(?:ago|pehle|pehlay|qabl|back)")
DAY_MONTH = re.compile(r"\b(\d{1,2})(?:st|nd|rd|th)?\s*(?:of\s+)?([a-z]{3,9})\.?(?:,?\s*(\d{4}))?")
MONTH_DAY = re.compile(r"\b([a-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s*(\d{4}))?")
NUMERIC = re.compile(r"\b(\d{1,2})[/\-.](\d{1,2})(?:[/\-.](\d{2,4}))?\b")


def _local_day(published_at: datetime) -> date:
    return published_at.astimezone(KARACHI).date()


def _safe_date(year: int, month: int, day: int) -> date | None:
    try:
        return date(year, month, day)
    except ValueError:
        return None


def _explicit(expression: str, posted: date) -> date | None:
    for pattern, order in ((DAY_MONTH, "dm"), (MONTH_DAY, "md")):
        for m in pattern.finditer(expression):
            day_s, month_s = (m.group(1), m.group(2)) if order == "dm" else (m.group(2), m.group(1))
            month = MONTHS.get(month_s)
            if month is None:
                continue
            year = int(m.group(3)) if m.group(3) else posted.year
            found = _safe_date(year, month, int(day_s))
            if found and not m.group(3) and found > posted:
                found = _safe_date(year - 1, month, int(day_s))  # "28 Dec" posted on 2 Jan
            if found:
                return found
    m = NUMERIC.search(expression)
    if m:
        # Pakistan writes dates day-first: 22/11 = 22 November.
        day, month = int(m.group(1)), int(m.group(2))
        year = int(m.group(3)) if m.group(3) else posted.year
        if year < 100:
            year += 2000
        found = _safe_date(year, month, day)
        if found and not m.group(3) and found > posted:
            found = _safe_date(year - 1, month, day)
        return found
    return None


def resolve_date(expression: str | None, published_at: datetime) -> tuple[date | None, DatePrecision]:
    """Turn a verbatim date phrase into (date, precision). Never returns a date after the post."""
    if not expression or not expression.strip():
        return None, DatePrecision.UNKNOWN
    expr = " ".join(expression.lower().split())
    posted = _local_day(published_at)

    explicit = _explicit(expr, posted)
    if explicit is not None:
        return (explicit, DatePrecision.EXACT) if explicit <= posted else (None, DatePrecision.UNKNOWN)

    m = N_DAYS_AGO.search(expr)
    if m:
        return posted - timedelta(days=int(m.group(1))), DatePrecision.APPROXIMATE

    for phrase, days, precision in RELATIVE:
        if re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", expr):
            return posted - timedelta(days=days), precision

    for name, weekday in sorted(WEEKDAYS.items(), key=lambda kv: -len(kv[0])):
        if re.search(rf"(?<!\w){re.escape(name)}(?!\w)", expr):
            back = (posted.weekday() - weekday) % 7
            return posted - timedelta(days=back), DatePrecision.APPROXIMATE

    return None, DatePrecision.UNKNOWN
