"""OpenRouter chat completions for explicitly free hosted models."""

from __future__ import annotations

import time

import httpx

from .ollama_client import (
    ChatStats,
    ConfigurationRefused,
    Health,
    OllamaBadOutput,
    OllamaTimeout,
    OllamaUnavailable,
    parse_json_object,
    prompt_for_json,
)


class OpenRouterClient:
    is_cloud = True
    provider_name = "OpenRouter"

    def __init__(self, model: str, *, api_key: str | None, timeout_s: float):
        if not api_key or not api_key.strip():
            raise ConfigurationRefused("Set OPENROUTER_API_KEY in the project .env to use OpenRouter.")
        if not model.endswith(":free"):
            raise ConfigurationRefused("OPENROUTER_MODEL must name an OpenRouter :free model.")
        self.model = model
        self.inference_verified = False
        self._http = httpx.Client(
            base_url="https://openrouter.ai",
            headers={"Authorization": f"Bearer {api_key.strip()}"},
            timeout=httpx.Timeout(timeout_s, connect=5.0),
            follow_redirects=False,
            trust_env=False,
        )

    def close(self) -> None:
        self._http.close()

    def unload(self) -> None:
        """Hosted model weights are managed by OpenRouter."""

    def health(self) -> Health:
        try:
            response = self._http.get("/api/v1/key", timeout=5.0)
        except (httpx.HTTPError, OSError):
            return Health(False, False, "OpenRouter is unreachable.")
        if not response.is_success:
            return Health(True, False, f"OpenRouter key check failed (HTTP {response.status_code}).")
        return Health(True, True, "OpenRouter key accepted. Run check-ai to verify inference.")

    def chat_json(self, messages: list[dict], schema: dict) -> tuple[dict, str, ChatStats]:
        started = time.perf_counter()
        self.inference_verified = False
        try:
            response = self._http.post(
                "/api/v1/chat/completions",
                json={
                    "model": self.model,
                    "messages": prompt_for_json(messages, schema),
                    "stream": False,
                    "temperature": 0,
                    "max_tokens": 4096,
                    "response_format": {"type": "json_object"},
                    "provider": {
                        "data_collection": "deny",
                        "max_price": {"prompt": 0, "completion": 0, "request": 0},
                    },
                },
            )
        except httpx.TimeoutException as exc:
            raise OllamaTimeout(f"No answer from {self.model} within the timeout") from exc
        except (httpx.TransportError, OSError) as exc:
            raise OllamaUnavailable(f"OpenRouter unreachable ({type(exc).__name__})") from exc
        if not response.is_success:
            status = response.status_code
            retry_after = response.headers.get("Retry-After", "")
            delay = int(retry_after) if retry_after.isdecimal() and len(retry_after) <= 10 else 900
            raise OllamaUnavailable(
                f"OpenRouter refused the free model request (HTTP {status}).",
                retry_after_s=delay if status in {402, 429} else None,
            )
        try:
            body = response.json()
            choice = (body.get("choices") or [{}])[0]
            if body.get("error") or choice.get("error"):
                raise OllamaUnavailable("OpenRouter returned a provider error for the free model.")
            raw = (choice.get("message") or {}).get("content")
            if choice.get("finish_reason") == "length":
                final_text = raw if isinstance(raw, str) else ""
                raise OllamaBadOutput("OpenRouter stopped before finishing the JSON response", final_text)
            if not isinstance(raw, str):
                raise TypeError("message.content must be text")
        except (ValueError, KeyError, IndexError, TypeError, AttributeError) as exc:
            raise OllamaBadOutput("OpenRouter response is missing text content") from exc
        result = parse_json_object(raw, allow_fences=True)
        self.inference_verified = True
        usage = body.get("usage") or {}
        stats = ChatStats(
            time.perf_counter() - started, usage.get("prompt_tokens"), usage.get("completion_tokens"), None
        )
        return result, raw, stats
