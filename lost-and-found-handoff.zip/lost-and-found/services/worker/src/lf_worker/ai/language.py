"""Deterministic language detection (English / Roman Urdu / Urdu / mixed).

Done in Python rather than by the AI: it is fast, explainable, and doesn't cost output tokens.
"""

from __future__ import annotations

import re

from lf_core.enums import Language

ROMAN_URDU_MARKERS = {
    "hai",
    "hain",
    "ka",
    "ki",
    "ke",
    "ko",
    "se",
    "mein",
    "main",
    "mera",
    "meri",
    "mere",
    "gaya",
    "gayi",
    "gaye",
    "gya",
    "gyi",
    "mila",
    "mili",
    "mil",
    "kal",
    "aaj",
    "aj",
    "raha",
    "rahi",
    "tha",
    "thi",
    "kahin",
    "kisi",
    "agar",
    "bhai",
    "yaar",
    "plz",
    "hua",
    "hui",
    "wala",
    "wali",
    "walay",
    "kar",
    "karen",
    "karein",
    "rabta",
    "paas",
    "pas",
    "kho",
    "gum",
    "nahi",
    "nahin",
    "batwa",
    "chabi",
    "sath",
    "saath",
    "abhi",
    "jo",
    "jis",
    "kya",
    "koi",
    "hoga",
    "hogi",
    "diya",
    "liye",
    "lye",
    "shukriya",
    "meherbani",
    "bohat",
    "bahut",
    "wapas",
}
ENGLISH_MARKERS = {
    "the",
    "a",
    "an",
    "my",
    "is",
    "was",
    "near",
    "at",
    "in",
    "on",
    "lost",
    "found",
    "please",
    "if",
    "anyone",
    "has",
    "have",
    "it",
    "this",
    "with",
    "and",
    "of",
    "to",
    "from",
    "contact",
    "black",
    "brown",
    "blue",
    "yesterday",
    "today",
    "morning",
    "evening",
    "around",
    "inside",
    "outside",
    "someone",
    "owner",
}
_ARABIC = re.compile(r"[؀-ۿ]")
_LATIN = re.compile(r"[a-zA-Z]")


def detect_language(text: str) -> Language:
    arabic, latin = len(_ARABIC.findall(text)), len(_LATIN.findall(text))
    letters = arabic + latin
    if letters == 0:
        return Language.OTHER
    if arabic / letters >= 0.6:
        return Language.URDU
    if arabic / letters >= 0.15:
        return Language.MIXED
    words = re.findall(r"[a-z]+", text.lower())
    ru = sum(1 for w in words if w in ROMAN_URDU_MARKERS)
    en = sum(1 for w in words if w in ENGLISH_MARKERS)
    if ru >= 2 and ru >= en:
        return Language.ROMAN_URDU
    if ru >= 2 and en >= 3:
        return Language.MIXED
    if en >= 1 or ru == 0:
        return Language.ENGLISH
    return Language.ROMAN_URDU
