"""Stage 3: check the AI's answer against the original post (the anti-hallucination layer).

The model's output is treated as a *claim*. Every field that should be copied from the post is
checked against the post text. Anything that can't be found there is removed and the report is
flagged for review. Coordinates and dates are never taken from the model (see dates.py, geocoding/).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date, datetime

from lf_core.enums import CitySource, DatePrecision, Language
from lf_core.text import CATEGORY_LABEL, expand_token, normalize_text
from rapidfuzz import fuzz

from .dates import resolve_date
from .extraction import ExtractionResult
from .language import detect_language
from .prefilter import PrefilterResult

GROUNDING_THRESHOLD = 85
KNOWN_CITIES = {
    "karachi": "Karachi",
    "khi": "Karachi",
    "کراچی": "Karachi",
    "lahore": "Lahore",
    "islamabad": "Islamabad",
    "rawalpindi": "Rawalpindi",
    "hyderabad": "Hyderabad",
    "peshawar": "Peshawar",
    "quetta": "Quetta",
    "multan": "Multan",
    "faisalabad": "Faisalabad",
}
ITEM_SYNONYMS = {
    "wallet": {"batwa", "purse", "بٹوا", "پرس"},
    "phone": {"mobile", "cell", "موبائل", "فون", "iphone"},
    "mobile": {"phone", "موبائل", "فون"},
    "cnic": {"id", "shanakhti", "شناختی", "card", "کارڈ"},
    "id": {"cnic", "shanakhti", "شناختی", "card"},
    "card": {"cnic", "id", "کارڈ"},
    "keys": {"key", "chabi", "chaabi", "چابی", "چابیاں"},
    "key": {"keys", "chabi", "چابی"},
    "bag": {"backpack", "basta", "handbag", "بیگ", "بستہ"},
    "cat": {"billi", "kitten", "بلی"},
    "dog": {"kutta", "puppy", "کتا"},
    "ring": {"angoothi", "انگوٹھی"},
    "licence": {"license", "لائسنس"},
    "license": {"licence", "لائسنس"},
    "documents": {"papers", "kaghzat", "کاغذات", "file"},
    "parrot": {"tota", "طوطا"},
    "motorcycle": {"bike", "motorbike", "موٹر سائیکل"},
    "bike": {"motorcycle", "cycle"},
    "glasses": {"specs", "chashma", "عینک"},
    "laptop": {"لیپ ٹاپ"},
}
# Words that describe but don't identify an item: sharing only these isn't evidence.
GENERIC = {
    "black",
    "brown",
    "blue",
    "red",
    "white",
    "green",
    "grey",
    "gray",
    "small",
    "big",
    "new",
    "old",
    "leather",
    "a",
    "the",
    "and",
    "with",
    "of",
    "card",
    "phone",
    "bag",
}


@dataclass
class GroundedExtraction:
    report_type: str  # LOST / FOUND / IRRELEVANT
    item_name: str
    item_category: str
    description: str | None
    colour: str | None
    brand: str | None
    location_text: str | None
    city: str | None
    city_source: str | None
    date_expression: str | None
    incident_date: date | None
    date_precision: DatePrecision
    language: Language
    is_resolution_update: bool
    model_confidence: float
    confidence: float
    needs_review: bool
    review_reasons: list[str] = field(default_factory=list)
    # For evaluation: what the model said before grounding removed it.
    removed: dict[str, str] = field(default_factory=dict)


# Connective words a model may add, drop or reorder when it copies a place phrase.
FUNCTION_WORDS = {
    "near",
    "the",
    "a",
    "an",
    "at",
    "in",
    "on",
    "of",
    "to",
    "from",
    "and",
    "between",
    "inside",
    "outside",
    "around",
    "ke",
    "ki",
    "ka",
    "pe",
    "par",
    "mein",
    "paas",
    "pas",
    "se",
    "کے",
    "کی",
    "کا",
    "میں",
    "پر",
    "پاس",
    "قریب",
    "سے",
}
WORD_SHARE = 0.8


def appears_in(fragment: str, text: str, threshold: int = GROUNDING_THRESHOLD) -> bool:
    """True if the fragment was copied from the text: exactly, with small typos, or with its words
    reordered. A translation ("University of Karachi" for an Urdu post) does not count."""
    a, b = normalize_text(fragment), normalize_text(text)
    if not a:
        return False
    if a in b or (len(a) >= 4 and fuzz.partial_ratio(a, b) >= threshold):
        return True
    words = [w for w in a.split() if w not in FUNCTION_WORDS]
    if not words:
        return False
    post_words = set(b.split())
    hits = sum(
        1
        for w in words
        if w in post_words or (len(w) >= 5 and any(fuzz.ratio(w, x) >= GROUNDING_THRESHOLD for x in post_words))
    )
    return hits / len(words) >= WORD_SHARE


def item_name_grounded(item_name: str, text: str) -> bool:
    words = set(normalize_text(text).split())
    for token in normalize_text(item_name).split():
        if token in GENERIC:
            continue
        options = {token, token.rstrip("s"), *expand_token(token), *ITEM_SYNONYMS.get(token, set())}
        if words & options or any(o in normalize_text(text) for o in options if " " in o):
            return True
    return False


def stated_city(text: str) -> str | None:
    words = normalize_text(text).split()
    for word in words:
        if word in KNOWN_CITIES:
            return KNOWN_CITIES[word]
    return None


def ground(
    extraction: ExtractionResult,
    text: str,
    published_at: datetime,
    prefilter_result: PrefilterResult,
    *,
    min_confidence_active: float = 0.6,
    place_finder: Callable[[str], str | None] | None = None,
    allow_keyword_fallback: bool = True,
) -> GroundedExtraction:
    reasons: list[str] = []
    removed: dict[str, str] = {}

    report_type = extraction.report_type
    if report_type == "UNCERTAIN":
        # Fall back to the keywords only when they point one way; otherwise treat as not a report.
        if allow_keyword_fallback and prefilter_result.intent:
            report_type = prefilter_result.intent
            reasons.append("type_from_keywords")
        else:
            report_type = "IRRELEVANT"

    def keep_if_grounded(name: str, value: str | None) -> str | None:
        if value and not appears_in(value, text):
            removed[name] = value
            reasons.append(f"{name}_not_in_post")
            return None
        return value

    location_text = keep_if_grounded("location_text", extraction.location_text)
    if location_text is None and place_finder is not None:
        # Deterministic fallback: a known Karachi place named in the post itself (any language).
        found_place = place_finder(text)
        if found_place:
            location_text = found_place
            if "location_text_not_in_post" in reasons:
                reasons.remove("location_text_not_in_post")
                reasons.append("location_replaced_from_gazetteer")
            else:
                reasons.append("location_from_gazetteer")
    date_expression = keep_if_grounded("date_expression", extraction.date_expression)
    colour = keep_if_grounded("colour", extraction.colour)
    brand = keep_if_grounded("brand", extraction.brand)

    category = extraction.item_category or "OTHER"
    if extraction.item_category is None and report_type != "IRRELEVANT":
        reasons.append("category_missing")
    if prefilter_result.categories and category not in prefilter_result.categories and category != "OTHER":
        reasons.append("category_not_supported_by_keywords")

    item_name = extraction.item_name
    item_ok = bool(item_name) and item_name_grounded(item_name, text)
    if not item_name:
        item_name = CATEGORY_LABEL[category]
        reasons.append("item_name_missing")
    elif not item_ok:
        reasons.append("item_name_not_in_post")

    city = stated_city(text)
    city_source = CitySource.STATED.value if city else None

    incident_date, date_precision = resolve_date(date_expression, published_at)

    # Combined confidence: half the model's own (poorly calibrated) score, half deterministic checks.
    checks = [
        item_ok,
        extraction.location_text is None or "location_text" not in removed,
        extraction.date_expression is None or date_expression is not None,
        "category_not_supported_by_keywords" not in reasons and "category_missing" not in reasons,
        prefilter_result.intent in (None, report_type),
    ]
    deterministic = sum(checks) / len(checks)
    confidence = round(0.5 * extraction.confidence + 0.5 * deterministic, 3)
    if confidence < min_confidence_active:
        reasons.append("low_confidence")

    return GroundedExtraction(
        report_type=report_type,
        item_name=item_name[:120],
        item_category=category,
        description=extraction.description,
        colour=colour.lower() if colour else None,
        brand=brand,
        location_text=location_text,
        city=city,
        city_source=city_source,
        date_expression=date_expression,
        incident_date=incident_date,
        date_precision=date_precision,
        language=detect_language(text),
        is_resolution_update=extraction.is_resolution_update,
        model_confidence=extraction.confidence,
        confidence=confidence,
        needs_review=bool(reasons),
        review_reasons=reasons,
        removed=removed,
    )
