"""Stage 1: a cheap keyword filter that runs before the AI.

On this laptop each AI call takes tens of seconds, so obviously irrelevant posts ("lost the match",
"found the best biryani") are dropped here. The filter is tuned for recall: a relevant post wrongly
rejected here is lost for good, while an irrelevant post that gets through only costs one AI call.
Its recall and precision are measured on the labelled dataset (scripts/evaluate_model.py).
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

# Roman Urdu has no standard spelling. Collapse common variants before matching.
SPELLING_VARIANTS = {
    "gya": "gaya",
    "gyi": "gayi",
    "gae": "gaye",
    "gye": "gaye",
    "gai": "gayi",
    "milla": "mila",
    "mla": "mila",
    "mili": "mili",
    "milli": "mili",
    "hy": "hai",
    "he": "hai",
    "h": "hai",
    "ha": "hai",
    "hain": "hain",
    "mobail": "mobile",
    "moblie": "mobile",
    "wallat": "wallet",
    "walet": "wallet",
    "batua": "batwa",
    "chabi": "chabi",
    "chaabi": "chabi",
    "chabiyan": "chabi",
    "kaho": "kho",
    "khoo": "kho",
    "gum": "gum",
}

LOST_PATTERNS = [
    r"\blost\b",
    r"\bmissing\b",
    r"\bmisplaced\b",
    r"\bleft (?:behind|in|at|on)\b",
    r"\bdropped\b",
    r"\bforgot\b",
    r"\bkho (?:gaya|gayi|gaye|diya|di|diye)\b",
    r"\bkho\b",
    r"\bgum (?:ho )?(?:gaya|gayi|gaye)\b",
    r"\bgum\b",
    r"\bgir (?:gaya|gayi|gaye)\b",
    r"\breh (?:gaya|gayi|gaye)\b",
    r"\bnahi mil (?:raha|rahi|rahe)\b",
    "گم",
    "کھو",
    "گر گیا",
    "رہ گیا",
    r"\bleft (?:my|his|her|their|our|a|an|the|someone'?s?)\b",
    r"\bfell\b",
    r"\bran away\b",
    r"\bescaped\b",
    r"\bflew (?:away|off)\b",
    r"\b(?:rah|reh) (?:gaya|gayi|gaye|gayin)\b",
    r"\bgir(?:a|i|e)?\b",
    r"\bud (?:gaya|gayi|gaye)\b",
    r"\bnikal (?:gaya|gayi|gaye)\b",
    r"\bbhaag (?:gaya|gayi|gaye)\b",
    r"\blaapata\b",
    r"\blapata\b",
    "لاپتہ",
    "غائب",
]
FOUND_PATTERNS = [
    r"\bfound\b",
    r"\bpicked up\b",
    r"\bhanded (?:over|in)\b",
    r"\bmil (?:gaya|gayi|gaye|gya)\b",
    r"\bmila\b",
    r"\bmili\b",
    r"\bmile\b",
    r"\bowner\b",
    r"\bclaim\b",
    r"\bpara hua\b",
    r"\bpari hui\b",
    r"\bkis(?:i)? ka hai\b",
    "مل گیا",
    "ملا",
    "ملی",
    "مالک",
    r"\bpicked\b",
    r"\b(?:i|we) have (?:it|them|her|him)\b",
    r"\bkept (?:it|them)\b",
    r"\bis (?:this|it|she|he) yours\b",
    r"\bis this your\b",
    r"\b(?:mere|mery|hamare|humare) paas hai\b",
    r"\bjama (?:kara|kar|hai)\b",
    r"\bpaya\b",
    r"\bhanded it\b",
    "میرے پاس",
    "پڑا",
]
ITEM_PATTERNS = {
    "WALLET": [r"\bwallets?\b", r"\bbatwa\b", r"\bpurse\b", "بٹوا", "پرس"],
    "PHONE": [
        r"\bphones?\b",
        r"\bmobiles?\b",
        r"\biphone\b",
        r"\bsamsung\b",
        r"\boppo\b",
        r"\bvivo\b",
        r"\binfinix\b",
        r"\bredmi\b",
        r"\btecno\b",
        "موبائل",
        "فون",
    ],
    "DOCUMENT_ID": [
        r"\bcnic\b",
        r"\bid card\b",
        r"\bshanakhti\b",
        r"\blicen[cs]e\b",
        r"\bpassport\b",
        r"\bdocuments?\b",
        r"\bcards?\b",
        r"\bfile\b",
        r"\bdegree\b",
        r"\bcertificate\b",
        "شناختی",
        "کارڈ",
        "لائسنس",
        "پاسپورٹ",
        "کاغذات",
        r"\bcertificates\b",
        r"\bfolder\b",
        r"\bpapers\b",
        r"\badmit cards?\b",
        r"\bregistration\b",
        r"\bpouch\b",
    ],
    "BAG": [
        r"\bbags?\b",
        r"\bbackpack\b",
        r"\bbasta\b",
        r"\bhandbag\b",
        r"\bsuitcase\b",
        "بیگ",
        "بستہ",
        r"\bbackpacks\b",
        r"\bshopping bag\b",
        r"\bthaila\b",
    ],
    "KEYS": [r"\bkeys?\b", r"\bchabi\b", "چابی", "چابیاں", r"\bkey ?(?:chain|ring|fob)s?\b"],
    "JEWELLERY": [
        r"\brings?\b",
        r"\bchain\b",
        r"\bbracelet\b",
        r"\bearrings?\b",
        r"\bangoothi\b",
        r"\bjewel",
        r"\bgold\b",
        r"\bsona\b",
        r"\blocket\b",
        "انگوٹھی",
        "چین",
        "سونے",
    ],
    "ELECTRONICS": [
        r"\blaptop\b",
        r"\btablet\b",
        r"\bipad\b",
        r"\bcharger\b",
        r"\bearbuds\b",
        r"\bairpods\b",
        r"\bheadphones?\b",
        r"\bwatch\b",
        r"\bcamera\b",
        r"\bpower ?bank\b",
        r"\busb\b",
        "لیپ ٹاپ",
        r"\bmi band\b",
        r"\bsmart ?watch\b",
        r"\bfitbit\b",
        r"\bearphones\b",
        r"\bbuds\b",
        r"\bkindle\b",
    ],
    "PET": [
        r"\bcats?\b",
        r"\bkitten\b",
        r"\bdogs?\b",
        r"\bpupp(?:y|ies)\b",
        r"\bbilli\b",
        r"\bkutta\b",
        r"\bparrot\b",
        r"\btota\b",
        r"\bpet\b",
        "بلی",
        "کتا",
        "طوطا",
        r"\bbirds?\b",
        r"\bkittens\b",
        r"\bpersian\b",
        r"\bshepherd\b",
        r"\blabrador\b",
        r"\bbilli ka baccha\b",
        "طوطا",
    ],
    "VEHICLE": [
        r"\bbike\b",
        r"\bmotorcycle\b",
        r"\bmotorbike\b",
        r"\bcycle\b",
        r"\bcar\b",
        r"\bnumber plate\b",
        r"\bhelmet\b",
        "موٹر سائیکل",
        "گاڑی",
    ],
    "CLOTHING": [
        r"\bjacket\b",
        r"\bshoes?\b",
        r"\bdupatta\b",
        r"\bshawl\b",
        r"\bsweater\b",
        r"\bclothes\b",
        r"\bcap\b",
        r"\bglasses\b",
        r"\bspecs\b",
        r"\bchashma\b",
        "عینک",
        "جیکٹ",
        r"\bsunglasses\b",
        r"\bspectacles\b",
        r"\bhoodie\b",
        r"\bscarf\b",
        r"\bchador\b",
        r"\bkapr[ae]\b",
    ],
    "OTHER": [
        r"\bumbrella\b",
        r"\bbooks?\b",
        r"\bnotebook\b",
        r"\bbottle\b",
        r"\btoy\b",
        r"\bcheque\b",
        r"\benvelope\b",
        r"\bcash\b",
        r"\bmoney\b",
        r"\bpaise\b",
        r"\bparcel\b",
    ],
}
SUPPORT_PATTERNS = [
    r"\bcontact\b",
    r"\brabta\b",
    r"\bdm\b",
    r"\binbox\b",
    r"\breward\b",
    r"\binaam\b",
    r"\bplease help\b",
    r"\bplz\b",
    r"\bplease\b",
    r"\bshare\b",
    r"\breturn\b",
    r"\bwapas\b",
    r"\bif anyone\b",
    r"\bagar kisi\b",
    r"\bnear\b",
    r"\bke paas\b",
    "رابطہ",
    "انعام",
    "براہ کرم",
    "واپس",
]
# Common phrases that use "lost"/"found"/"missing" in an unrelated sense, or are adverts and news.
NEGATIVE_PATTERNS = [
    r"\blost (?:my|his|her|their|our) (?:mind|temper|cool|patience|job|life|lives|way)\b",
    r"\blost (?:the|a|their|our) (?:match|game|final|series|election|battle|case|seat|toss)\b",
    r"\blost (?:weight|hope|interest|touch|faith|money in|connection|count|sleep)\b",
    r"\blost to\b",
    r"\blost by\b",
    r"\bfound (?:dead|guilty|innocent|out|that|it hard|a way)\b",
    r"\bfound (?:the|this) (?:best|perfect|cutest|new)\b",
    r"\bfound [^.]{0,60}\b(?:in|among) (?:some |my |our )?old (?:boxed up (?:stuff|things)|boxes)\b",
    r"\bfound [^.]{0,60}\bamong (?:my|our) (?:own )?belongings\b",
    r"\bmissing out\b",
    r"\bmiss(?:ing)? you\b",
    r"\bfor sale\b",
    r"\bsale\b",
    r"\bdiscount\b",
    r"\bprice\b",
    r"\brs\.? ?\d",
    r"\bbuy\b",
    r"\border now\b",
    r"\bdelivery\b",
    r"\bfound(?:ed)? in \d{4}\b",
    r"\bmissing funds\b",
    r"\bmissing persons?\b",
    r"\bkho (?:diya|di) (?:dil|hosh)\b",
    r"\bmiss(?:ing)? (?:the )?(?:bus|flight|deadline|class)\b",
]

_compiled = {
    "lost": [re.compile(p) for p in LOST_PATTERNS],
    "found": [re.compile(p) for p in FOUND_PATTERNS],
    "support": [re.compile(p) for p in SUPPORT_PATTERNS],
    "negative": [re.compile(p) for p in NEGATIVE_PATTERNS],
}
_items = {cat: [re.compile(p) for p in pats] for cat, pats in ITEM_PATTERNS.items()}

PASS_THRESHOLD = 1.5


def normalize_for_matching(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).lower()
    text = re.sub(r"[^\w\s؀-ۿ.]", " ", text)
    words = [SPELLING_VARIANTS.get(w, w) for w in text.split()]
    return " ".join(words)


@dataclass
class PrefilterResult:
    score: float
    passed: bool
    lost_hits: int
    found_hits: int
    categories: list[str] = field(default_factory=list)
    negative_hits: int = 0

    @property
    def intent(self) -> str | None:
        """LOST/FOUND when the keywords point one way only; None when mixed or absent."""
        if self.lost_hits and not self.found_hits:
            return "LOST"
        if self.found_hits and not self.lost_hits:
            return "FOUND"
        return None


def _count(patterns: list[re.Pattern], text: str) -> int:
    return sum(1 for p in patterns if p.search(text))


def prefilter(text: str) -> PrefilterResult:
    norm = normalize_for_matching(text)
    lost, found = _count(_compiled["lost"], norm), _count(_compiled["found"], norm)
    support, negative = _count(_compiled["support"], norm), _count(_compiled["negative"], norm)
    categories = [cat for cat, pats in _items.items() if any(p.search(norm) for p in pats)]
    score = (1.0 if lost or found else 0.0) + (1.0 if categories else 0.0) + min(support, 2) * 0.25
    score -= 1.0 * negative
    passed = bool(lost or found) and bool(categories) and score >= PASS_THRESHOLD
    return PrefilterResult(round(score, 2), passed, lost, found, categories, negative)
