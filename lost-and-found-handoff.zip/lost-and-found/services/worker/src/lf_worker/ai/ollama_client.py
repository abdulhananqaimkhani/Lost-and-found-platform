"""Direct Ollama Cloud client that also supports explicit local benchmark runs."""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from urllib.parse import urlsplit

import httpx

LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1", "[::1]"}
CLOUD_BASE_URL = "https://ollama.com"


class OllamaError(Exception):
    """Base class."""


class OllamaUnavailable(OllamaError):
    """The configured Ollama service cannot process jobs right now."""

    def __init__(self, message: str, *, retry_after_s: float | None = None):
        super().__init__(message)
        self.retry_after_s = retry_after_s


class OllamaTimeout(OllamaError):
    """The model took longer than the timeout."""


class OllamaBadOutput(OllamaError):
    """The model answered, but not with valid JSON matching the schema."""

    def __init__(self, message: str, raw: str = ""):
        super().__init__(message)
        self.raw = raw


class ConfigurationRefused(ValueError):
    """The Ollama endpoint, model or credential configuration is invalid."""


def ensure_local(base_url: str) -> None:
    try:
        url = urlsplit(base_url)
        if (
            url.scheme in {"http", "https"}
            and url.hostname in LOOPBACK_HOSTS
            and "@" not in url.netloc
            and not (url.path or url.query or url.fragment)
        ):
            return
    except ValueError:
        pass
    raise ConfigurationRefused("OLLAMA_BASE_URL must be https://ollama.com or a loopback Ollama server.")


def ensure_local_model(model: str) -> None:
    tag = model.split(":", 1)[1] if ":" in model else ""
    if model.endswith("-cloud") or tag == "cloud" or tag.endswith("-cloud"):
        raise ConfigurationRefused(
            f"{model!r} is an Ollama cloud model (it runs on ollama.com, not this computer). Use a local model."
        )


@dataclass
class ChatStats:
    latency_s: float
    prompt_tokens: int | None
    output_tokens: int | None
    load_s: float | None


@dataclass
class Health:
    reachable: bool
    model_available: bool
    message: str

    @property
    def ok(self) -> bool:
        return self.reachable and self.model_available


def prompt_for_json(messages: list[dict], schema: dict) -> list[dict]:
    schema_json = json.dumps(schema, separators=(",", ":"))
    instruction = "Return only a JSON object matching this schema:\n" + schema_json
    if messages and messages[0]["role"] == "system":
        instruction = messages[0]["content"] + "\n\n" + instruction
        messages = messages[1:]
    return [{"role": "system", "content": instruction}, *messages]


def parse_json_object(raw: str, *, allow_fences: bool = False) -> dict:
    content = raw.strip()
    if allow_fences:
        fenced = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", content, re.IGNORECASE | re.DOTALL)
        if fenced:
            content = fenced[1]
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError as exc:
        raise OllamaBadOutput("Model output is not valid JSON", raw) from exc
    if not isinstance(parsed, dict):
        raise OllamaBadOutput("Model output is not a JSON object", raw)
    return parsed


class OllamaClient:
    provider_name = "Ollama"

    def __init__(
        self,
        base_url: str,
        model: str,
        *,
        api_key: str | None = None,
        timeout_s: float = 180.0,
        num_ctx: int = 2048,
        think: bool | str | None = None,
        seed: int = 42,
        transport: httpx.BaseTransport | None = None,
    ):
        base_url = base_url.rstrip("/")
        self.is_cloud = base_url in (CLOUD_BASE_URL, f"{CLOUD_BASE_URL}/api")
        self.inference_verified = False
        headers = {}
        if self.is_cloud:
            base_url = CLOUD_BASE_URL
            if not api_key or not api_key.strip():
                raise ConfigurationRefused("Set OLLAMA_API_KEY in the project .env to use Ollama Cloud.")
            headers["Authorization"] = f"Bearer {api_key.strip()}"
            if model.startswith("gpt-oss:") and think is None:
                think = "low"
        else:
            ensure_local(base_url)
            ensure_local_model(model)
        self.model, self.num_ctx, self.think, self.seed = model, num_ctx, think, seed
        self._http = httpx.Client(
            base_url=base_url,
            headers=headers,
            timeout=httpx.Timeout(timeout_s, connect=5.0),
            transport=transport,
            follow_redirects=False,
            trust_env=False,
        )

    def close(self) -> None:
        self._http.close()

    def _cloud_rejection(self, response: httpx.Response) -> OllamaUnavailable:
        status = response.status_code
        if status in {402, 429}:
            retry_after = response.headers.get("Retry-After", "")
            delay = int(retry_after) if retry_after.isdecimal() and len(retry_after) <= 10 else 900
            message = (
                "Ollama Cloud returned HTTP 402 Payment Required. Check your account's credits and model access."
                if status == 402
                else "Ollama Cloud rate limit reached (HTTP 429). Check your Ollama usage."
            )
            return OllamaUnavailable(
                message,
                retry_after_s=delay,
            )
        if status in {401, 403}:
            return OllamaUnavailable(
                f"Ollama Cloud denied access (HTTP {status}). Check OLLAMA_API_KEY and your account's model access."
            )
        if status == 404:
            return OllamaUnavailable(f"Model {self.model} is unavailable through Ollama Cloud. Check OLLAMA_MODEL.")
        return OllamaUnavailable(f"Ollama Cloud rejected the request (HTTP {status}). Check the provider and model.")

    def health(self) -> Health:
        try:
            response = self._http.get("/api/tags", timeout=5.0)
            if self.is_cloud and not response.is_success:
                return Health(True, False, str(self._cloud_rejection(response)))
            response.raise_for_status()
            models = response.json()["models"]
            names = {model.get(key) for model in models for key in ("name", "model")}
        except (httpx.HTTPError, OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
            return Health(False, False, f"Ollama unreachable at {self._http.base_url} ({type(exc).__name__})")
        wanted = self.model if ":" in self.model else f"{self.model}:latest"
        if self.model not in names and wanted not in names:
            if self.is_cloud:
                return Health(True, False, f"Model {self.model} is absent from the Ollama Cloud catalog.")
            return Health(True, False, f'Model {self.model} not found: run "ollama pull {self.model}"')
        message = "Cloud model listed. Run check-ai to verify inference access." if self.is_cloud else "ok"
        return Health(True, True, message)

    def chat_json(
        self, messages: list[dict], schema: dict, *, num_predict: int | None = None, keep_alive: str = "10m"
    ) -> tuple[dict, str, ChatStats]:
        """One structured-output chat call. Returns (parsed JSON, raw text, stats)."""
        payload: dict = {
            "model": self.model,
            "messages": messages,
            "stream": False,
        }
        if self.is_cloud:
            payload["messages"] = prompt_for_json(messages, schema)
            payload["options"] = {"temperature": 0, "num_predict": 1024 if num_predict is None else num_predict}
        else:
            payload.update(
                format=schema,
                keep_alive=keep_alive,
                options={
                    "temperature": 0,
                    "num_ctx": self.num_ctx,
                    "num_predict": 320 if num_predict is None else num_predict,
                    "seed": self.seed,
                },
            )
        if self.think is not None:
            payload["think"] = self.think
        started = time.perf_counter()
        try:
            response = self._http.post("/api/chat", json=payload)
        except httpx.TimeoutException as exc:
            self.inference_verified = False
            raise OllamaTimeout(f"No answer from {self.model} within the timeout") from exc
        except (httpx.TransportError, OSError) as exc:
            self.inference_verified = False
            raise OllamaUnavailable(f"Ollama unreachable ({type(exc).__name__})") from exc
        self.inference_verified = response.is_success
        if self.is_cloud and not response.is_success:
            raise self._cloud_rejection(response)
        if response.status_code == 404:
            raise OllamaUnavailable(f'Model {self.model} not found: run "ollama pull {self.model}"')
        if response.status_code >= 500:
            raise OllamaUnavailable(f"Ollama error {response.status_code}: {response.text[:200]}")
        if response.status_code >= 400:
            raise OllamaBadOutput(f"Ollama rejected the request ({response.status_code}): {response.text[:200]}")

        try:
            body = response.json()
            raw = body["message"]["content"]
            if not isinstance(raw, str):
                raise TypeError("message.content must be text")
        except (ValueError, KeyError, TypeError) as exc:
            raise OllamaBadOutput("Ollama response is missing text content") from exc
        stats = ChatStats(
            latency_s=time.perf_counter() - started,
            prompt_tokens=body.get("prompt_eval_count"),
            output_tokens=body.get("eval_count"),
            load_s=(body.get("load_duration") or 0) / 1e9 or None,
        )
        return parse_json_object(raw, allow_fences=self.is_cloud), raw, stats

    def unload(self) -> None:
        """Free the model's RAM now (used between benchmark runs)."""
        if self.is_cloud:
            return
        try:
            self._http.post("/api/generate", json={"model": self.model, "keep_alive": 0}, timeout=30)
        except httpx.HTTPError:
            pass


class CircuitBreaker:
    """After Ollama fails, stop calling it for `cooldown_s` seconds. Jobs wait in the queue meanwhile."""

    def __init__(self, cooldown_s: float = 60.0, clock=time.monotonic):
        self.cooldown_s, self._clock = cooldown_s, clock
        self._open_until = 0.0
        self.last_error: str | None = None

    def allow(self) -> bool:
        return self._clock() >= self._open_until

    def trip(self, error: str, retry_after_s: float | None = None) -> None:
        cooldown = max(self.cooldown_s, retry_after_s or 0)
        self._open_until = max(self._open_until, self._clock() + cooldown)
        self.last_error = error

    def reset(self) -> None:
        self._open_until = 0.0
        self.last_error = None

    @property
    def is_open(self) -> bool:
        return not self.allow()
