"""The processing pipeline: what happens to each queued job (PROJECT_PLAN.md §5).

EXTRACT  source  → stage 0 copy check → stage 1 keyword filter → stage 2 Ollama → stage 3 grounding
                   → report created (or attached to an existing one) → GEOCODE job
GEOCODE  report  → gazetteer / Nominatim → coordinates + precision → MATCH job
MATCH    report  → candidate search + scoring → report_matches

Errors are classified so the queue can treat them correctly:
* AIUnavailable  → job deferred, no attempt used (Ollama is down; never switch to another AI)
* RetryableError → retried with backoff
* PermanentError → job FAILED, details kept for debugging
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

import httpx
from lf_core.enums import JobType, ReportStatus, SourcePlatform, SourceState, StatusActor
from lf_core.ingest import attach_source_to_report
from lf_core.models import ProcessingJob, Report, Source, StatusChange
from lf_core.queue import enqueue
from lf_core.settings import Settings
from lf_core.status import change_status
from lf_core.text import build_search_text, normalize_text, redact_text
from sqlalchemy import select
from sqlalchemy.orm import Session

from .ai.extraction import Extractor
from .ai.grounding import ground
from .ai.ollama_client import CircuitBreaker, OllamaBadOutput, OllamaTimeout, OllamaUnavailable
from .ai.prefilter import prefilter
from .geocoding.geocoder import Geocoder
from .matching import find_and_store_matches, near_duplicate

log = logging.getLogger("lf_worker.pipeline")
COVERAGE_CITY = "Karachi"
KARACHI_WORDS = {"karachi", "khi", "کراچی"}

# Review reasons that mean the report shouldn't be presented as a confident listing.
UNVERIFIED_REASONS = {
    "low_confidence",
    "item_name_not_in_post",
    "type_from_keywords",
    "category_not_supported_by_keywords",
    "location_text_not_in_post",
}


class AIUnavailable(Exception):
    pass


class RetryableError(Exception):
    pass


class PermanentError(Exception):
    def __init__(self, message: str, details: dict | None = None):
        super().__init__(message)
        self.details = details or {}


@dataclass
class JobOutcome:
    label: str
    result: dict


def rebuild_search_text(report: Report) -> None:
    report.search_text = build_search_text(
        item_name=report.item_name,
        description=report.description,
        location_text=report.location_text,
        city=report.city,
        item_category=report.item_category,
        source_texts=[s.original_text for s in report.sources if s.original_text],
    )


class Pipeline:
    def __init__(
        self, settings: Settings, extractor: Extractor | None, geocoder: Geocoder, breaker: CircuitBreaker | None = None
    ):
        self.settings, self.extractor, self.geocoder = settings, extractor, geocoder
        self.breaker = breaker or CircuitBreaker()

    def handle(self, session: Session, job: ProcessingJob) -> JobOutcome:
        if job.job_type == JobType.EXTRACT.value:
            return self.extract(session, job)
        if job.job_type == JobType.GEOCODE.value:
            return self.geocode(session, job)
        if job.job_type == JobType.MATCH.value:
            return self.match(session, job)
        raise PermanentError(f"Unknown job type {job.job_type}")

    # ---- EXTRACT -----------------------------------------------------------------------------

    def extract(self, session: Session, job: ProcessingJob) -> JobOutcome:
        source = session.get(Source, job.source_id)
        if source is None:
            return JobOutcome("source_missing", {})
        if source.report_id:
            return JobOutcome("already_processed", {"report_id": source.report_id})

        copy = session.scalars(
            select(Source)
            .where(Source.text_hash == source.text_hash, Source.report_id.is_not(None), Source.id != source.id)
            .limit(1)
        ).first()
        if copy is not None and copy.report is not None:
            attach_source_to_report(session, source, copy.report, SourceState.ATTACHED_DUPLICATE)
            return JobOutcome("attached_copy", {"report_id": copy.report_id})

        pf = prefilter(source.original_text)
        source.prefilter_score = pf.score
        if not pf.passed and self.settings.prefilter_enabled:
            source.processing_state = SourceState.PREFILTER_REJECTED.value
            return JobOutcome("prefilter_rejected", {"prefilter_score": pf.score})

        if self.extractor is None:
            raise AIUnavailable("No extraction model configured")
        if not self.breaker.allow():
            raise AIUnavailable(self.breaker.last_error or "AI provider unavailable")
        article = source.platform == SourcePlatform.RSS.value
        try:
            outcome = self.extractor.extract(source.original_text, article=article)
        except OllamaUnavailable as exc:
            self.breaker.trip(str(exc), exc.retry_after_s)
            raise AIUnavailable(str(exc)) from exc
        except OllamaTimeout as exc:
            raise RetryableError(str(exc)) from exc
        except OllamaBadOutput as exc:
            raise PermanentError(str(exc), {"raw_output": exc.raw[:4000]}) from exc
        self.breaker.reset()

        gazetteer = getattr(self.geocoder, "gazetteer", None)

        def place_finder(text: str) -> str | None:
            place = gazetteer.find_in_text(session, text) if gazetteer else None
            return place.label if place else None

        grounded = ground(
            outcome.result,
            source.original_text,
            source.published_at,
            pf,
            min_confidence_active=self.settings.min_confidence_active,
            place_finder=place_finder,
            allow_keyword_fallback=not article,
        )
        result = {
            "model": outcome.model,
            "attempts": outcome.attempts,
            "latency_s": round(outcome.latency_s, 2),
            "extraction": outcome.result.model_dump(),
            "review_reasons": grounded.review_reasons,
            "removed_by_grounding": grounded.removed,
            "confidence": grounded.confidence,
        }

        if grounded.report_type == "IRRELEVANT":
            source.processing_state = SourceState.IRRELEVANT.value
            return JobOutcome("irrelevant", result)

        if grounded.is_resolution_update:
            original = self._same_thread_report(session, source)
            if original is None:
                # "Found it, thanks!" with no original post we know about: nothing to list.
                source.processing_state = SourceState.IRRELEVANT.value
                return JobOutcome("resolution_update_without_original", result)
            attach_source_to_report(session, source, original, SourceState.ATTACHED_DUPLICATE)
            change_status(
                session,
                original,
                ReportStatus.RESOLVED,
                actor=StatusActor.SOURCE_EVIDENCE,
                reason=f"Later post in the same thread says it was returned (source {source.id})",
            )
            return JobOutcome("resolved_by_source", {**result, "report_id": original.id})

        if not self.in_coverage(session, grounded, source):
            # A real lost/found post, but not about Karachi: the map and gazetteer cover Karachi only,
            # and listing it would only republish a stranger's post without benefit to this app's users.
            source.processing_state = SourceState.IRRELEVANT.value
            return JobOutcome("outside_coverage", result)

        duplicate = near_duplicate(
            session,
            report_type=grounded.report_type,
            category=grounded.item_category,
            text=source.original_text,
            published_at=source.published_at,
            location_text=grounded.location_text,
            is_demo=source.is_demo,
        )
        if duplicate is not None:
            attach_source_to_report(session, source, duplicate, SourceState.ATTACHED_DUPLICATE)
            rebuild_search_text(duplicate)
            return JobOutcome("attached_near_duplicate", {**result, "report_id": duplicate.id})

        unverified = bool(UNVERIFIED_REASONS & set(grounded.review_reasons))
        status = ReportStatus.UNVERIFIED if unverified else ReportStatus.ACTIVE
        report = Report(
            report_type=grounded.report_type,
            item_name=grounded.item_name,
            item_category=grounded.item_category,
            description=redact_text(grounded.description) if grounded.description else None,
            attributes={"colour": grounded.colour, "brand": grounded.brand},
            location_text=grounded.location_text,
            city=grounded.city,
            city_source=grounded.city_source,
            location_precision="UNKNOWN",
            incident_date=grounded.incident_date,
            date_expression=grounded.date_expression,
            date_precision=grounded.date_precision.value,
            reported_at=source.published_at,
            collected_at=source.collected_at,
            status=status.value,
            confidence_score=grounded.confidence,
            needs_review=grounded.needs_review,
            review_reasons=grounded.review_reasons,
            language=grounded.language.value,
            extraction_model=outcome.model,
            primary_platform=source.platform,
            source_count=1,
            is_demo=source.is_demo,
            last_activity_at=source.published_at,
        )
        session.add(report)
        source.report = report
        source.processing_state = SourceState.EXTRACTED.value
        session.flush()
        rebuild_search_text(report)
        session.add(
            StatusChange(
                report_id=report.id,
                from_status=None,
                to_status=status.value,
                actor=StatusActor.SYSTEM.value,
                reason=f"Created by {outcome.model} from a {source.platform} post"
                + (f"; review: {', '.join(grounded.review_reasons)}" if unverified else ""),
            )
        )
        enqueue(session, JobType.GEOCODE, report_id=report.id)
        return JobOutcome("report_created", {**result, "report_id": report.id, "status": status.value})

    def in_coverage(self, session: Session, grounded, source: Source) -> bool:
        if grounded.city:
            return grounded.city == COVERAGE_CITY
        if KARACHI_WORDS & set(normalize_text(source.original_text).split()):
            return True
        if (source.raw_meta or {}).get("scope") == "karachi":
            return True  # the source itself is Karachi-only (e.g. #karachi, r/karachi)
        gazetteer = getattr(self.geocoder, "gazetteer", None)
        return bool(grounded.location_text and gazetteer and gazetteer.geocode(session, grounded.location_text, None))

    def _same_thread_report(self, session: Session, source: Source) -> Report | None:
        thread = (source.raw_meta or {}).get("thread_id")
        if not thread:
            return None
        sibling = session.scalars(
            select(Source)
            .where(
                Source.platform == source.platform,
                Source.raw_meta["thread_id"].astext == str(thread),
                Source.report_id.is_not(None),
                Source.id != source.id,
            )
            .limit(1)
        ).first()
        return sibling.report if sibling else None

    # ---- GEOCODE -----------------------------------------------------------------------------

    def geocode(self, session: Session, job: ProcessingJob) -> JobOutcome:
        report = session.get(Report, job.report_id)
        if report is None:
            return JobOutcome("report_missing", {})
        try:
            result = self.geocoder.geocode(session, report.location_text, report.city)
        except httpx.HTTPError as exc:
            raise RetryableError(f"Geocoder unavailable: {exc}") from exc
        report.location_precision = result.precision.value
        report.geocode_provider = result.provider
        report.place_key = result.place_key
        if result.mapped:
            report.latitude, report.longitude, report.location_radius_m = (
                result.latitude,
                result.longitude,
                result.radius_m,
            )
        else:
            report.latitude = report.longitude = report.location_radius_m = None
        if report.city is None and result.city:
            report.city, report.city_source = result.city, "INFERRED_FROM_GAZETTEER"
        if result.reasons:
            report.review_reasons = sorted({*(report.review_reasons or []), *result.reasons})
            report.needs_review = report.needs_review or result.needs_review
        rebuild_search_text(report)
        enqueue(session, JobType.MATCH, report_id=report.id)
        return JobOutcome(
            "geocoded",
            {
                "precision": result.precision.value,
                "provider": result.provider,
                "mapped": result.mapped,
                "reasons": result.reasons,
            },
        )

    # ---- MATCH -------------------------------------------------------------------------------

    def match(self, session: Session, job: ProcessingJob) -> JobOutcome:
        report = session.get(Report, job.report_id)
        if report is None:
            return JobOutcome("report_missing", {})
        matches = find_and_store_matches(session, report, self.settings.match_threshold)
        return JobOutcome("matched", {"matches": [{"report_id": r.id, "score": p.score} for r, p in matches]})
