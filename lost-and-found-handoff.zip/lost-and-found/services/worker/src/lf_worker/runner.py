"""Runs queued jobs: claim → process → complete/retry/defer, each step in its own transaction."""

from __future__ import annotations

import logging
import socket
import time
from collections import Counter
from datetime import UTC, datetime, timedelta

from lf_core.enums import JobType, SourceState
from lf_core.models import ProcessingJob, Source, WorkerHeartbeat
from lf_core.queue import claim, complete, defer, fail, recover_stale_locks
from lf_core.status import mark_stale_reports
from sqlalchemy import update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session, sessionmaker

from .pipeline import AIUnavailable, PermanentError, Pipeline, RetryableError

log = logging.getLogger("lf_worker.runner")
AI_DEFER_SECONDS = 60


def worker_id() -> str:
    return f"{socket.gethostname()}-{id(object()) % 10_000}"


class Runner:
    def __init__(
        self,
        sessions: sessionmaker[Session],
        pipeline: Pipeline,
        *,
        worker: str | None = None,
        ai_min_interval_s: float = 0.0,
        clock=time.monotonic,
        sleep=time.sleep,
    ):
        self.sessions, self.pipeline = sessions, pipeline
        self.worker = worker or worker_id()
        self.ai_min_interval_s = ai_min_interval_s
        self._clock, self._sleep = clock, sleep
        self._last_ai_call = -1e9

    def _job_types(self) -> list[JobType]:
        # While the AI is unavailable, keep geocoding and matching; extraction jobs simply wait.
        if self.pipeline.breaker.is_open or self.pipeline.extractor is None:
            return [JobType.GEOCODE, JobType.MATCH]
        return [JobType.EXTRACT, JobType.GEOCODE, JobType.MATCH]

    def run_one(self) -> str | None:
        with self.sessions() as session:
            job = claim(session, self.worker, self._job_types())
            session.commit()
            if job is None:
                return None
            job_id, job_type = job.id, job.job_type

        if job_type == JobType.EXTRACT.value and self.ai_min_interval_s:
            wait = self._last_ai_call + self.ai_min_interval_s - self._clock()
            if wait > 0:
                self._sleep(wait)  # AI_MAX_JOBS_PER_MINUTE limits extraction throughput.

        with self.sessions() as session:
            job = session.get(ProcessingJob, job_id)
            try:
                if job_type == JobType.EXTRACT.value:
                    self._last_ai_call = self._clock()
                outcome = self.pipeline.handle(session, job)
                complete(session, job, {"outcome": outcome.label, **outcome.result})
                session.commit()
                log.info("job %s %s → %s", job_id, job_type, outcome.label)
                return outcome.label
            except AIUnavailable as exc:
                session.rollback()
                job = session.get(ProcessingJob, job_id)
                defer(session, job, AI_DEFER_SECONDS, f"AI unavailable: {exc}")
                session.commit()
                log.warning("job %s deferred while waiting for AI: %s", job_id, exc)
                return "deferred"
            except RetryableError as exc:
                session.rollback()
                job = session.get(ProcessingJob, job_id)
                fail(session, job, str(exc), retryable=True)
                session.commit()
                log.warning("job %s will retry: %s", job_id, exc)
                return "retry"
            except Exception as exc:  # noqa: BLE001 - any other error is permanent for this job
                session.rollback()
                job = session.get(ProcessingJob, job_id)
                details = exc.details if isinstance(exc, PermanentError) else {}
                fail(session, job, f"{type(exc).__name__}: {exc}", retryable=False)
                job.result = details or None
                if job.source_id and job_type == JobType.EXTRACT.value:
                    session.execute(
                        update(Source)
                        .where(Source.id == job.source_id)
                        .values(processing_state=SourceState.FAILED.value)
                    )
                session.commit()
                log.exception("job %s failed permanently", job_id)
                return "failed"

    def run_batch(self, max_jobs: int = 20, max_seconds: float = 600) -> Counter:
        counts: Counter = Counter()
        started = self._clock()
        while counts.total() < max_jobs and self._clock() - started < max_seconds:
            label = self.run_one()
            if label is None:
                break
            counts[label] += 1
            if label == "deferred":
                break
        return counts

    def heartbeat(self, ai_available: bool, message: str = "") -> None:
        with self.sessions() as session:
            stmt = pg_insert(WorkerHeartbeat).values(
                worker_id=self.worker,
                last_seen=datetime.now(UTC),
                info={"ai_available": ai_available, "message": message[:200]},
            )
            session.execute(
                stmt.on_conflict_do_update(
                    index_elements=["worker_id"],
                    set_={"last_seen": stmt.excluded.last_seen, "info": stmt.excluded.info},
                )
            )
            session.commit()


def maintenance(session: Session, *, stale_after_days: int, retention_days: int) -> dict:
    """Daily housekeeping: stale reports, crashed-job recovery, and privacy purge of irrelevant text."""
    recovered = recover_stale_locks(session)
    stale = mark_stale_reports(session, older_than_days=stale_after_days)
    cutoff = datetime.now(UTC) - timedelta(days=retention_days)
    purged = session.execute(
        update(Source)
        .where(
            Source.processing_state.in_([SourceState.PREFILTER_REJECTED.value, SourceState.IRRELEVANT.value]),
            Source.collected_at < cutoff,
            Source.text_purged_at.is_(None),
            Source.is_demo.is_(False),
        )
        .values(original_text="", text_purged_at=datetime.now(UTC))
    ).rowcount
    return {"recovered_jobs": recovered, "marked_stale": stale, "purged_texts": purged}
