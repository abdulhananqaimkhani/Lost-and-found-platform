"""Runs one connector: cursor in → posts → dedupe/ingest → cursor out, recorded in collection_runs.

A source that keeps failing is paused with a growing cooldown, without affecting the others.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx
import yaml
from lf_core.enums import RunStatus, SourcePlatform
from lf_core.ingest import IngestStatus, ingest_post
from lf_core.models import CollectionRun, SourceStateRow
from lf_core.settings import Settings
from sqlalchemy import func, select
from sqlalchemy.orm import Session, sessionmaker

from .connectors.base import Connector, Limits, NotConfigured, RateLimited, SourceError
from .connectors.bluesky import BlueskyConnector
from .connectors.mastodon import MastodonConnector
from .connectors.reddit import RedditConnector
from .connectors.rss import RssConnector
from .connectors.x_api import XConnector

log = logging.getLogger("lf_worker.collector")
PAUSE_AFTER_FAILURES = 3
REDDIT_MIN_INTERVAL = timedelta(hours=1)


@dataclass
class SourceSpec:
    connector: Connector
    interval_minutes: int
    max_posts: int
    monthly_budget_usd: float | None = None


def load_sources(settings: Settings, path: Path | None = None) -> list[SourceSpec]:
    path = path or settings.resolve_path(settings.sources_config)
    config = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    sources = config.get("sources", {})
    specs: list[SourceSpec] = []

    rss = sources.get("rss", {})
    if rss.get("enabled"):
        for feed in rss.get("feeds", []):
            if feed.get("enabled", True) is not True:
                continue
            specs.append(
                SourceSpec(
                    RssConnector(
                        key=f"rss:{feed['name']}",
                        url=feed.get("url") or "",
                        name=feed["name"],
                        require_keywords=feed.get("require_keywords", True),
                        publisher=feed.get("publisher"),
                        license_url=feed.get("license_url"),
                        max_age_days=settings.stale_after_days,
                    ),
                    rss.get("interval_minutes", 60),
                    rss.get("max_posts_per_run", 50),
                )
            )

    x = sources.get("x", {})
    specs.append(
        SourceSpec(
            XConnector(
                key="x:recent-search",
                enabled=bool(x.get("enabled")),
                queries=x.get("queries", []),
                bearer_token=settings.x_bearer_token.get_secret_value() if settings.x_bearer_token else None,
                cost_per_post_usd=float(x.get("cost_per_post_usd", 0.005)),
            ),
            x.get("interval_minutes", 120),
            x.get("max_posts_per_run", 50),
            float(x.get("monthly_budget_usd", 0)),
        )
    )

    reddit = sources.get("reddit", {})
    specs.append(
        SourceSpec(
            RedditConnector(
                key="reddit:search",
                approved=reddit.get("approved") is True,
                access_method=reddit.get("transport", "direct"),
                subreddits=reddit.get("subreddits", []),
                query=reddit.get("query", "lost OR found"),
                client_id=settings.reddit_client_id,
                user_agent=settings.reddit_user_agent,
                client_secret=settings.reddit_client_secret.get_secret_value()
                if settings.reddit_client_secret
                else None,
                composio_api_key=settings.composio_api_key.get_secret_value() if settings.composio_api_key else None,
                composio_account_id=settings.composio_reddit_account_id,
                composio_user_id=settings.composio_reddit_user_id,
            ),
            reddit.get("interval_minutes", 60),
            reddit.get("max_posts_per_run", 50),
        )
    )

    bsky = sources.get("bluesky", {})
    specs.append(
        SourceSpec(
            BlueskyConnector(
                key="bluesky:search",
                enabled=bool(bsky.get("enabled")),
                queries=bsky.get("queries", []),
                handle=settings.bluesky_handle,
                app_password=settings.bluesky_app_password.get_secret_value()
                if settings.bluesky_app_password
                else None,
            ),
            bsky.get("interval_minutes", 60),
            bsky.get("max_posts_per_run", 50),
        )
    )

    for instance in sources.get("mastodon", {}).get("instances", []):
        specs.append(
            SourceSpec(
                MastodonConnector(
                    key=f"mastodon:{instance['name']}",
                    instance=instance["url"],
                    hashtags=instance.get("hashtags", []),
                    enabled=bool(instance.get("enabled")),
                ),
                sources["mastodon"].get("interval_minutes", 60),
                sources["mastodon"].get("max_posts_per_run", 40),
            )
        )
    return specs


def spent_this_month(session: Session, platform: SourcePlatform, now: datetime) -> float:
    start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    total = session.scalar(
        select(func.coalesce(func.sum(CollectionRun.cost_units), 0.0)).where(
            CollectionRun.platform == platform.value, CollectionRun.started_at >= start
        )
    )
    return float(total or 0.0)


def run_source(sessions: sessionmaker[Session], spec: SourceSpec, *, now: datetime | None = None) -> dict:
    connector = spec.connector
    now = now or datetime.now(UTC)
    configured, why = connector.is_configured()
    if not configured:
        log.info("source %s skipped: %s", connector.key, why)
        return {"source": connector.key, "status": "NOT_CONFIGURED", "message": why}

    with sessions() as session:
        if connector.platform == SourcePlatform.REDDIT:
            # Serialize the slot reservation across the scheduler and manual CLI runs.
            session.execute(select(func.pg_advisory_xact_lock(func.hashtext(connector.key))))
        state = session.get(SourceStateRow, connector.key) or SourceStateRow(
            source_key=connector.key, cursor={}, consecutive_failures=0
        )
        state = session.merge(state)
        if state.paused_until and state.paused_until > now:
            session.commit()
            log.info("source %s paused until %s", connector.key, state.paused_until.isoformat())
            return {"source": connector.key, "status": "PAUSED", "until": state.paused_until.isoformat()}
        if connector.platform == SourcePlatform.REDDIT:
            last_attempt = session.scalar(
                select(func.max(CollectionRun.started_at)).where(CollectionRun.source_key == connector.key)
            )
            if last_attempt is not None:
                next_attempt = last_attempt + max(REDDIT_MIN_INTERVAL, timedelta(minutes=spec.interval_minutes))
                if next_attempt > now:
                    return {"source": connector.key, "status": "PAUSED", "until": next_attempt.isoformat()}
        budget = None
        if spec.monthly_budget_usd is not None:
            budget = max(0.0, spec.monthly_budget_usd - spent_this_month(session, connector.platform, now))
        run = CollectionRun(
            source_key=connector.key,
            platform=connector.platform.value,
            status=RunStatus.RUNNING.value,
            started_at=now,
            cursor_before=dict(state.cursor or {}),
        )
        session.add(run)
        session.commit()
        run_id, cursor = run.id, dict(state.cursor or {})

    try:
        result = connector.fetch(cursor, Limits(max_posts=spec.max_posts, budget_remaining_usd=budget))
    except (SourceError, httpx.HTTPError, ValueError) as exc:
        return _record_failure(sessions, connector.key, run_id, exc, now)

    counts = {s: 0 for s in IngestStatus}
    with sessions() as session:
        for post in result.posts:
            counts[ingest_post(session, post, source_key=connector.key, collection_run_id=run_id).status] += 1
        run = session.get(CollectionRun, run_id)
        run.status = RunStatus.SUCCESS.value
        run.completed_at = datetime.now(UTC)
        run.records_fetched = len(result.posts)
        run.records_new = counts[IngestStatus.NEW]
        run.records_duplicate = counts[IngestStatus.DUPLICATE] + counts[IngestStatus.ATTACHED_COPY]
        run.cost_units = result.cost_units
        run.cursor_after = result.cursor
        run.message = (
            result.message
            + (f"; {result.skipped_irrelevant} skipped by keyword gate" if result.skipped_irrelevant else "")
        ).strip("; ")
        state = session.get(SourceStateRow, connector.key)
        state.cursor, state.consecutive_failures, state.paused_until = result.cursor, 0, None
        state.last_success_at = datetime.now(UTC)
        session.commit()
    log.info(
        "source %s: %d fetched, %d new, %d duplicate",
        connector.key,
        len(result.posts),
        counts[IngestStatus.NEW],
        counts[IngestStatus.DUPLICATE],
    )
    return {
        "source": connector.key,
        "status": "SUCCESS",
        "fetched": len(result.posts),
        "new": counts[IngestStatus.NEW],
        "duplicate": counts[IngestStatus.DUPLICATE],
        "attached_copy": counts[IngestStatus.ATTACHED_COPY],
        "message": run_message(result),
    }


def run_message(result) -> str:
    return result.message


def _record_failure(sessions, key: str, run_id: int, exc: Exception, now: datetime) -> dict:
    with sessions() as session:
        run = session.get(CollectionRun, run_id)
        run.status = RunStatus.SKIPPED.value if isinstance(exc, NotConfigured) else RunStatus.FAILED.value
        run.completed_at = datetime.now(UTC)
        run.errors = [{"type": type(exc).__name__, "message": str(exc)[:500]}]
        state = session.get(SourceStateRow, key)
        state.consecutive_failures += 1
        if state.consecutive_failures >= PAUSE_AFTER_FAILURES:
            minutes = min(24 * 60, 30 * 2 ** (state.consecutive_failures - PAUSE_AFTER_FAILURES))
            state.paused_until = now + timedelta(minutes=minutes)
        if run.platform == SourcePlatform.REDDIT.value and isinstance(exc, RateLimited):
            retry_at = run.completed_at + max(REDDIT_MIN_INTERVAL, timedelta(seconds=exc.retry_after_s or 0))
            state.paused_until = max(state.paused_until or retry_at, retry_at)
        session.commit()
        log.warning("source %s failed (%s): %s", key, type(exc).__name__, exc)
        return {
            "source": key,
            "status": "FAILED",
            "error": f"{type(exc).__name__}: {exc}",
            "consecutive_failures": state.consecutive_failures,
            "paused_until": state.paused_until.isoformat() if state.paused_until else None,
        }
