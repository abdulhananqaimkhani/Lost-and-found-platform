"""Command-line entry point:  uv run python -m lf_worker <command>

These commands are the operator's tools. There is no web admin dashboard (by design):
  run                    start the scheduler (collection + AI queue + maintenance)
  collect [KEY|all]      run collection once
  process [--limit N]    process queued jobs once
  status                 queue, sources and AI health
  check-ai               verify extraction with one synthetic post
  review-suggestions     list visitor suggestions; --accept / --reject one (the only way to resolve by hand)
  set-status ID STATUS   operator status change, always with a reason (audited)
  maintenance            stale reports, crashed jobs, purge of irrelevant text
  seed-demo / seed-gazetteer
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import UTC, datetime

from lf_core.db import session_factory, session_scope
from lf_core.enums import ReportStatus, ReviewStatus, StatusActor, SuggestionType
from lf_core.models import CollectionRun, ProcessingJob, Report, Source, StatusSuggestion
from lf_core.settings import get_settings
from lf_core.status import change_status
from sqlalchemy import func, select

log = logging.getLogger("lf_worker")


def cmd_seed_demo(args: argparse.Namespace) -> int:
    from lf_core.demo import load_demo_dataset, remove_demo_data

    with session_scope() as session:
        if args.remove:
            print(f"Removed {remove_demo_data(session)} demo reports.")
        else:
            counts = load_demo_dataset(session)
            print(
                f"Loaded demo data: {counts['reports']} reports, {counts['places']} places, "
                f"{counts['matches']} matches."
            )
    return 0


def cmd_seed_gazetteer(args: argparse.Namespace) -> int:
    from lf_core.demo import upsert_places
    from lf_core.settings import REPO_ROOT

    path = REPO_ROOT / "database" / "schema" / "karachi_gazetteer.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    with session_scope() as session:
        count = upsert_places(session, data["places"])
    print(f"Loaded {count} gazetteer places from {path.name} ({data['attribution']}).")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    from .app import run_forever

    run_forever(get_settings())
    return 0


def cmd_collect(args: argparse.Namespace) -> int:
    from .collector import load_sources, run_source

    specs = load_sources(get_settings())
    chosen = [s for s in specs if args.source in ("all", s.connector.key)]
    if not chosen:
        print(f"No source named {args.source!r}. Known: {', '.join(s.connector.key for s in specs)}")
        return 2
    sessions = session_factory()
    for spec in chosen:
        print(json.dumps(run_source(sessions, spec), default=str))
    return 0


def cmd_process(args: argparse.Namespace) -> int:
    from .app import build_runner, check_ai

    runner = build_runner(get_settings())
    if not check_ai(runner):
        print("AI provider unavailable. Extraction jobs stay queued. Geocoding and matching can still run.")
    counts = runner.run_batch(max_jobs=args.limit, max_seconds=args.max_minutes * 60)
    print(json.dumps(dict(counts)))
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    from .ai.ollama_client import ConfigurationRefused
    from .app import build_client

    with session_scope() as session:
        jobs = session.execute(
            select(ProcessingJob.job_type, ProcessingJob.status, func.count()).group_by(
                ProcessingJob.job_type, ProcessingJob.status
            )
        ).all()
        states = session.execute(
            select(Source.processing_state, func.count())
            .where(Source.is_demo.is_(False))
            .group_by(Source.processing_state)
        ).all()
        reports = session.execute(
            select(Report.is_demo, Report.status, func.count()).group_by(Report.is_demo, Report.status)
        ).all()
        runs = session.scalars(select(CollectionRun).order_by(CollectionRun.started_at.desc()).limit(8)).all()
        print("Queue:", {f"{t}/{s}": n for t, s, n in jobs} or "empty")
        print("Collected posts by state:", dict(states) or "none")
        print("Reports:", {f"{'demo' if d else 'real'}/{s}": n for d, s, n in reports} or "none")
        for run in runs:
            print(
                f"  run {run.id} {run.source_key} {run.status} fetched={run.records_fetched} new={run.records_new}"
                f" {run.started_at:%Y-%m-%d %H:%M} {run.message or ''} {run.errors or ''}"
            )
    try:
        client = build_client(get_settings())
    except ConfigurationRefused as exc:
        print("AI:", exc)
    else:
        try:
            print(f"{client.provider_name}:", client.health().message)
        finally:
            client.close()
    return 0


def cmd_check_ai(args: argparse.Namespace) -> int:
    from .ai.extraction import Extractor
    from .ai.ollama_client import ConfigurationRefused, OllamaBadOutput, OllamaError
    from .app import build_client

    try:
        client = build_client(get_settings())
        try:
            outcome = Extractor(client).extract("I lost my black wallet in Saddar, Karachi yesterday.")
        finally:
            client.close()
    except OllamaBadOutput:
        print("The AI provider returned invalid extraction data for the synthetic post.")
        return 1
    except (OllamaError, ConfigurationRefused) as exc:
        print("AI:", exc)
        return 1
    if outcome.result.report_type != "LOST" or outcome.result.item_category != "WALLET":
        print(f"The AI provider returned an unexpected classification with {outcome.model}.")
        return 1
    print(f"Extraction verified with {outcome.model} ({outcome.latency_s:.1f}s).")
    return 0


def cmd_review(args: argparse.Namespace) -> int:
    with session_scope() as session:
        if args.accept or args.reject:
            suggestion = session.get(StatusSuggestion, args.accept or args.reject)
            if suggestion is None:
                print("No such suggestion.")
                return 2
            report = session.get(Report, suggestion.report_id)
            if args.reject:
                suggestion.review_status = ReviewStatus.REJECTED.value
                suggestion.reviewed_at = datetime.now(UTC)
                print(f"Rejected suggestion {suggestion.id}; report {report.id} unchanged.")
                return 0
            if not args.reason:
                print("--reason is required when accepting (it goes in the audit log).")
                return 2
            target = (
                ReportStatus.RESOLVED
                if suggestion.suggested_status == SuggestionType.RESOLVED.value
                else ReportStatus.DISPUTED
            )
            change_status(
                session,
                report,
                target,
                actor=StatusActor.OPERATOR_CLI,
                reason=f"Operator accepted suggestion {suggestion.id}: {args.reason}",
            )
            for s in session.scalars(
                select(StatusSuggestion).where(
                    StatusSuggestion.report_id == report.id,
                    StatusSuggestion.suggested_status == suggestion.suggested_status,
                    StatusSuggestion.review_status == ReviewStatus.PENDING.value,
                )
            ):
                s.review_status = ReviewStatus.ACCEPTED.value
                s.reviewed_at = datetime.now(UTC)
            print(f"Report {report.id} is now {target.value}.")
            return 0

        pending = session.scalars(
            select(StatusSuggestion)
            .where(
                StatusSuggestion.review_status == ReviewStatus.PENDING.value,
                ~StatusSuggestion.fingerprint_hash.startswith("demo-seed"),
            )
            .order_by(StatusSuggestion.report_id, StatusSuggestion.created_at)
        ).all()
        if not pending:
            print("No pending suggestions.")
        for s in pending:
            report = session.get(Report, s.report_id)
            print(
                f"#{s.id}  {s.suggested_status:<10} report {report.id} [{report.status}] {report.item_name!r}"
                f"  {s.created_at:%Y-%m-%d %H:%M}  reason: {s.reason or '-'}"
            )
        if pending:
            print("\nAccept: review-suggestions --accept ID --reason '...'   Reject: review-suggestions --reject ID")
    return 0


def cmd_set_status(args: argparse.Namespace) -> int:
    with session_scope() as session:
        report = session.get(Report, args.report_id)
        if report is None:
            print("No such report.")
            return 2
        changed = change_status(
            session, report, ReportStatus(args.status), actor=StatusActor.OPERATOR_CLI, reason=args.reason
        )
        print(f"Report {report.id}: {'now ' + args.status if changed else 'already ' + args.status}.")
    return 0


def cmd_maintenance(args: argparse.Namespace) -> int:
    from .runner import maintenance

    settings = get_settings()
    with session_scope() as session:
        print(
            maintenance(
                session,
                stale_after_days=settings.stale_after_days,
                retention_days=settings.irrelevant_text_retention_days,
            )
        )
    return 0


COMMANDS = {
    "seed-demo": cmd_seed_demo,
    "seed-gazetteer": cmd_seed_gazetteer,
    "run": cmd_run,
    "collect": cmd_collect,
    "process": cmd_process,
    "status": cmd_status,
    "check-ai": cmd_check_ai,
    "review-suggestions": cmd_review,
    "set-status": cmd_set_status,
    "maintenance": cmd_maintenance,
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="lf_worker", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("seed-demo", help="Load (or --remove) the labelled demo dataset")
    p.add_argument("--remove", action="store_true")
    sub.add_parser("seed-gazetteer", help="Load the OSM-derived Karachi gazetteer")
    sub.add_parser("run", help="Start the scheduler")
    p = sub.add_parser("collect", help="Run collection once")
    p.add_argument("source", nargs="?", default="all")
    p = sub.add_parser("process", help="Process queued jobs once")
    p.add_argument("--limit", type=int, default=20)
    p.add_argument("--max-minutes", type=float, default=30)
    sub.add_parser("status", help="Queue, sources, reports and AI health")
    sub.add_parser("check-ai", help="Verify extraction with one synthetic post")
    p = sub.add_parser("review-suggestions", help="Review visitor suggestions")
    group = p.add_mutually_exclusive_group()
    group.add_argument("--accept", type=int)
    group.add_argument("--reject", type=int)
    p.add_argument("--reason")
    p = sub.add_parser("set-status", help="Operator status change (audited)")
    p.add_argument("report_id")
    p.add_argument("status", choices=[s.value for s in ReportStatus])
    p.add_argument("--reason", required=True)
    sub.add_parser("maintenance", help="Stale reports, crashed jobs, privacy purge")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s"
    )
    return COMMANDS[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
