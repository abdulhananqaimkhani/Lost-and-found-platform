"""Turning a place phrase from a post into map coordinates, honestly.

Chain: local gazetteer (OSM-derived `places` table, with an alias list) → cached Nominatim result →
live Nominatim (1 request/second, Karachi only). Every coordinate comes from an OSM object.
If the phrase is ambiguous or only names the city, the report is NOT put on the map.
"""

from __future__ import annotations

import math
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Protocol

import httpx
from lf_core.enums import MAPPABLE_PRECISIONS, LocationPrecision
from lf_core.models import GeocodeCache, Place
from lf_core.text import normalize_text
from rapidfuzz import fuzz
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

KARACHI_VIEWBOX = "66.65,25.25,67.55,24.70"  # west,north,east,south (Nominatim order)
KARACHI_BOUNDS = (66.65, 24.70, 67.55, 25.25)  # west,south,east,north
POI_CATEGORIES = {"amenity", "shop", "building", "tourism", "aeroway", "railway", "leisure", "historic", "office"}
NEIGHBOURHOOD_TYPES = {"suburb", "neighbourhood", "quarter", "residential", "administrative", "village", "town"}
RADIUS_BY_PRECISION = {LocationPrecision.POI: 120, LocationPrecision.STREET: 400}
NEIGHBOURHOOD_RADIUS_RANGE_M = (400, 2500)
AMBIGUITY_DISTANCE_KM = 2.0

# Connective words around a place name, in English, Roman Urdu and Urdu ("ke paas" = near).
# Only connective words are removed; words that are part of names ("road", "karachi") are kept,
# otherwise "University Road" would collapse to "university" and match the wrong place.
FILLER = {
    "near",
    "nearby",
    "outside",
    "inside",
    "opposite",
    "behind",
    "at",
    "in",
    "on",
    "around",
    "somewhere",
    "ke",
    "ki",
    "ka",
    "paas",
    "pas",
    "pe",
    "par",
    "mein",
    "bahar",
    "andar",
    "qareeb",
    "saamne",
    "samne",
    "کے",
    "کی",
    "کا",
    "پاس",
    "قریب",
    "میں",
    "پر",
    "باہر",
    "سامنے",
}
# Spelling and abbreviation variants that people use for the same place.
ALIASES = [
    # "Gulshan" alone means Gulshan-e-Iqbal, but not Gulshan-e-Hadeed / -Maymar / -Jamal.
    (r"\bgulshan e iqbal\b|\bgulshan iqbal\b|\bgulshan\b(?! e (?:hadeed|maymar|jamal))|\bgei\b", "gulshan e iqbal"),
    (r"\bgulistan e jauhar\b|\bgulistan e johar\b|\bjauhar\b|\bjohar\b", "gulistan e jauhar"),
    (r"\bdefence\b|\bdefense\b|\bd h a\b", "dha"),
    (r"\bph\b|\bphase\b", "phase"),
    (r"\bblk\b|\bblock\b", "block"),
    (r"\bn nazimabad\b|\bnorth nazimabad\b|\bnorth naz\b", "north nazimabad"),
    (r"\bfb area\b|\bf b area\b|\bfederal b area\b", "federal b area"),
    (r"\bluckyone\b|\blucky one\b", "lucky one"),
    (r"\bkarachi university\b|\bku\b|\buniversity of karachi\b", "university of karachi"),
    (r"\bned(?: university)?\b", "ned university"),
    (r"\b(?:jinnah )?(?:international )?airport\b|\bjinnah terminal\b", "jinnah international airport"),
    (r"\bseaview\b|\bsea view\b|\bclifton beach\b", "sea view"),
    (r"\bcantt station\b|\bcantonment station\b", "karachi cantonment station"),
    (r"\bmalir cantt\b", "malir cantonment"),
]


@dataclass
class GeocodeResult:
    precision: LocationPrecision
    latitude: float | None = None
    longitude: float | None = None
    radius_m: int | None = None
    provider: str = "NONE"
    place_key: str | None = None
    display_name: str | None = None
    city: str | None = None
    needs_review: bool = False
    reasons: list[str] = field(default_factory=list)

    @property
    def mapped(self) -> bool:
        return self.precision in MAPPABLE_PRECISIONS and self.latitude is not None


class Geocoder(Protocol):
    def geocode(self, session: Session, location_text: str | None, city: str | None) -> GeocodeResult: ...


def normalize_location(text: str) -> str:
    norm = normalize_text(text)
    for pattern, replacement in ALIASES:
        norm = re.sub(pattern, replacement, norm)
    words = [w for w in norm.split() if w not in FILLER]
    return " ".join(words)


def classify_precision(category: str, place_type: str) -> LocationPrecision:
    if category in POI_CATEGORIES:
        return LocationPrecision.POI
    if category == "highway":
        return LocationPrecision.STREET
    if place_type == "city":
        return LocationPrecision.CITY
    if place_type in NEIGHBOURHOOD_TYPES or category in {"place", "boundary", "landuse"}:
        return LocationPrecision.NEIGHBOURHOOD
    return LocationPrecision.POI


def bbox_radius_m(bbox: list[str] | list[float]) -> int:
    """Half the diagonal of an OSM bounding box [south, north, west, east], in metres."""
    south, north, west, east = (float(v) for v in bbox)
    mid_lat = math.radians((south + north) / 2)
    height_m = (north - south) * 111_320
    width_m = (east - west) * 111_320 * math.cos(mid_lat)
    return round(math.hypot(height_m, width_m) / 2)


def radius_for(precision: LocationPrecision, bbox: list | None) -> int | None:
    if precision == LocationPrecision.NEIGHBOURHOOD:
        if not bbox:
            return 1000
        low, high = NEIGHBOURHOOD_RADIUS_RANGE_M
        return max(low, min(high, bbox_radius_m(bbox)))
    return RADIUS_BY_PRECISION.get(precision)


def _km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    a = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(math.radians(lng2 - lng1) / 2) ** 2
    return 2 * 6371 * math.asin(math.sqrt(a))


def in_karachi(lat: float, lng: float) -> bool:
    w, s, e, n = KARACHI_BOUNDS
    return s <= lat <= n and w <= lng <= e


class GazetteerGeocoder:
    """Matches the phrase against known places. Prefers the most specific (longest) name found."""

    def __init__(self, places: list[Place] | None = None):
        self._places = places

    def _load(self, session: Session) -> list[Place]:
        if self._places is None:
            self._places = list(session.scalars(select(Place)).all())
        return self._places

    def _names(self, place: Place) -> list[str]:
        names = {normalize_location(n) for n in [place.name, place.label, *(place.aliases or [])] if n}
        return [n for n in names if n]

    def find_in_text(self, session: Session | None, text: str) -> Place | None:
        """The most specific known place whose name or alias appears word-for-word in the text."""
        padded = f" {normalize_location(text)} "
        best: tuple[int, Place] | None = None
        for place in self._load(session):
            for name in self._names(place):
                if f" {name} " in padded and (best is None or len(name) > best[0]):
                    best = (len(name), place)
        return best[1] if best else None

    def geocode(self, session: Session, location_text: str | None, city: str | None) -> GeocodeResult | None:
        if not location_text:
            return None
        query = normalize_location(location_text)
        if not query:
            return None
        padded = f" {query} "
        best: tuple[int, Place] | None = None
        for place in self._load(session):
            for name in self._names(place):
                if f" {name} " in padded and (best is None or len(name) > best[0]):
                    best = (len(name), place)
        if best is None:
            # Fuzzy fallback for spelling variants ("bahadur abad"), only for reasonably long names.
            scored = [
                (fuzz.ratio(name, query), place)
                for place in self._load(session)
                for name in self._names(place)
                if len(name) >= 6
            ]
            scored = [s for s in scored if s[0] >= 90]
            if scored:
                best = (0, max(scored, key=lambda s: s[0])[1])
        if best is None:
            return None
        place = best[1]
        precision = LocationPrecision(place.precision)
        return GeocodeResult(
            precision=precision,
            latitude=place.latitude,
            longitude=place.longitude,
            radius_m=place.radius_m or radius_for(precision, None),
            provider="GAZETTEER",
            place_key=place.key,
            display_name=place.display_name,
            city=place.city,
        )


class RateLimiter:
    def __init__(self, min_interval_s: float, clock=time.monotonic, sleep=time.sleep):
        self.min_interval_s, self._clock, self._sleep = min_interval_s, clock, sleep
        self._last = -1e9
        self._lock = threading.Lock()

    def wait(self) -> None:
        with self._lock:
            delay = self._last + self.min_interval_s - self._clock()
            if delay > 0:
                self._sleep(delay)
            self._last = self._clock()


class NominatimGeocoder:
    """OpenStreetMap Nominatim, following its usage policy: max 1 request/second, an identifying
    User-Agent, and results cached so the same phrase is never looked up twice."""

    PROVIDER = "NOMINATIM"

    def __init__(
        self,
        base_url: str,
        user_agent: str,
        *,
        transport: httpx.BaseTransport | None = None,
        limiter: RateLimiter | None = None,
    ):
        self._http = httpx.Client(
            base_url=base_url.rstrip("/"), headers={"User-Agent": user_agent}, timeout=20, transport=transport
        )
        self._limiter = limiter or RateLimiter(1.1)

    def _lookup(self, session: Session, query: str) -> list[dict]:
        cache_key = f"nominatim:{normalize_text(query)}"[:300]
        cached = session.get(GeocodeCache, cache_key)
        if cached is not None:
            return (cached.result or {}).get("candidates", [])
        self._limiter.wait()
        response = self._http.get(
            "/search",
            params={
                "q": query,
                "format": "jsonv2",
                "limit": 3,
                "countrycodes": "pk",
                "viewbox": KARACHI_VIEWBOX,
                "bounded": 1,
                "accept-language": "en",
            },
        )
        response.raise_for_status()
        candidates = [
            {
                k: c.get(k)
                for k in (
                    "lat",
                    "lon",
                    "category",
                    "type",
                    "boundingbox",
                    "display_name",
                    "importance",
                    "osm_type",
                    "osm_id",
                )
            }
            for c in response.json()
        ]
        session.execute(
            pg_insert(GeocodeCache)
            .values(
                query_norm=cache_key, provider=self.PROVIDER, result={"candidates": candidates} if candidates else None
            )
            .on_conflict_do_nothing()
        )
        return candidates

    def geocode(self, session: Session, location_text: str | None, city: str | None) -> GeocodeResult | None:
        if not location_text:
            return None
        query = f"{location_text}, Karachi"
        candidates = [c for c in self._lookup(session, query) if in_karachi(float(c["lat"]), float(c["lon"]))]
        if not candidates:
            return None
        top = candidates[0]
        lat, lng = float(top["lat"]), float(top["lon"])
        reasons: list[str] = []
        for other in candidates[1:]:
            far = _km(lat, lng, float(other["lat"]), float(other["lon"])) > AMBIGUITY_DISTANCE_KM
            close_importance = abs((top.get("importance") or 0) - (other.get("importance") or 0)) < 0.05
            if far and close_importance:
                # Two equally likely places far apart: don't guess. List it, but don't map it.
                return GeocodeResult(
                    precision=LocationPrecision.CITY,
                    provider=self.PROVIDER,
                    city="Karachi",
                    needs_review=True,
                    reasons=["location_ambiguous"],
                )
        precision = classify_precision(top.get("category") or "", top.get("type") or "")
        if precision == LocationPrecision.CITY:
            return GeocodeResult(precision=precision, provider=self.PROVIDER, city="Karachi")
        return GeocodeResult(
            precision=precision,
            latitude=round(lat, 6),
            longitude=round(lng, 6),
            radius_m=radius_for(precision, top.get("boundingbox")),
            provider=self.PROVIDER,
            display_name=top.get("display_name"),
            city="Karachi",
            reasons=reasons,
        )


KARACHI_ONLY = {"karachi", "khi", "کراچی"}


class ChainGeocoder:
    def __init__(self, gazetteer: GazetteerGeocoder, nominatim: NominatimGeocoder | None):
        self.gazetteer, self.nominatim = gazetteer, nominatim

    def geocode(self, session: Session, location_text: str | None, city: str | None) -> GeocodeResult:
        if city and city.strip().lower() not in KARACHI_ONLY:
            # The gazetteer and map cover Karachi only (multi-city support = seed another gazetteer).
            return GeocodeResult(precision=LocationPrecision.CITY, city=city, reasons=["outside_coverage"])
        if not location_text or normalize_text(location_text) in KARACHI_ONLY:
            precision = LocationPrecision.CITY if (city or location_text) else LocationPrecision.UNKNOWN
            return GeocodeResult(precision=precision, city="Karachi" if precision == LocationPrecision.CITY else None)
        result = self.gazetteer.geocode(session, location_text, city)
        if result is None and self.nominatim is not None:
            result = self.nominatim.geocode(session, location_text, city)
        if result is None:
            return GeocodeResult(
                precision=LocationPrecision.CITY if city else LocationPrecision.UNKNOWN,
                city=city,
                needs_review=True,
                reasons=["location_not_found"],
            )
        return result
