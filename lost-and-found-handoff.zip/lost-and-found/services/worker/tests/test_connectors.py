"""Connectors against recorded-shape fixtures (respx). No network, no credentials, no cost."""

import json
from datetime import UTC, datetime, timedelta

import httpx
import pytest
import respx
from lf_core.enums import SourcePlatform
from lf_core.models import CollectionRun, SourceStateRow
from lf_worker.collector import SourceSpec, run_source, spent_this_month
from lf_worker.connectors.base import Limits, RateLimited, SourceError, retry_after_seconds, strip_html
from lf_worker.connectors.bluesky import BlueskyConnector, post_url
from lf_worker.connectors.mastodon import MastodonConnector
from lf_worker.connectors.reddit import COMPOSIO_ACCOUNTS, COMPOSIO_PROXY, RedditConnector
from lf_worker.connectors.rss import RssConnector
from lf_worker.connectors.x_api import API as X_API
from lf_worker.connectors.x_api import XConnector
from sqlalchemy import select

NO_SLEEP = lambda _s: None  # noqa: E731

RSS_XML = b"""<?xml version="1.0"?><rss version="2.0"><channel><title>Test feed</title>
<item><title>Wallet found at Saddar bus stop</title><link>https://news.test/a</link><guid>a</guid>
<description>&lt;p&gt;A wallet was &lt;b&gt;found&lt;/b&gt; by a commuter.&lt;/p&gt;</description>
<pubDate>Fri, 20 Nov 2026 10:00:00 GMT</pubDate></item>
<item><title>Budget debate continues</title><link>https://news.test/b</link><guid>b</guid>
<pubDate>Fri, 20 Nov 2026 11:00:00 GMT</pubDate></item>
</channel></rss>"""


@respx.mock
def test_rss_parses_strips_html_and_keeps_only_lost_found_items():
    respx.get("https://news.test/feed").respond(200, content=RSS_XML, headers={"ETag": '"v1"'})
    result = RssConnector(key="rss:test", url="https://news.test/feed", name="test", sleep=NO_SLEEP).fetch({}, Limits())
    assert [p.source_id for p in result.posts] == ["test:a"]
    assert result.posts[0].text == "Wallet found at Saddar bus stop\nA wallet was found by a commuter."
    assert result.skipped_irrelevant == 1 and result.cursor["etag"] == '"v1"'


@respx.mock
def test_rss_sends_conditional_headers_and_handles_304():
    route = respx.get("https://news.test/feed").respond(304)
    result = RssConnector(key="rss:test", url="https://news.test/feed", name="test").fetch(
        {"etag": '"v1"', "last_published": "x"}, Limits()
    )
    assert result.posts == [] and route.calls.last.request.headers["if-none-match"] == '"v1"'


@respx.mock
def test_rss_cursor_skips_items_already_seen():
    respx.get("https://news.test/feed").respond(200, content=RSS_XML)
    connector = RssConnector(key="rss:test", url="https://news.test/feed", name="test", require_keywords=False)
    first = connector.fetch({}, Limits())
    second = connector.fetch(first.cursor, Limits())
    assert len(first.posts) == 2 and second.posts == []


@respx.mock
def test_publisher_feed_keeps_attribution_and_resumes_at_the_batch_limit():
    feed = RSS_XML.replace(
        b'<rss version="2.0">', b'<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/">'
    ).replace(b"<pubDate>", b"<dc:creator>A Reporter</dc:creator><pubDate>")
    feed = feed.replace(b"11:00:00", b"10:00:00")
    route = respx.get("https://news.test/feed").respond(200, content=feed, headers={"ETag": '"v1"'})
    connector = RssConnector(
        key="rss:test",
        url="https://news.test/feed",
        name="test",
        publisher="Test Newspaper",
        license_url="https://news.test/license",
        require_keywords=False,
    )
    first = connector.fetch({}, Limits(max_posts=1))
    second = connector.fetch(first.cursor, Limits(max_posts=1))
    assert [p.source_id for p in first.posts + second.posts] == ["test:a", "test:b"]
    assert first.posts[0].raw_meta["publisher_byline"] == "A Reporter"
    assert first.posts[0].raw_meta["license_url"] == "https://news.test/license"
    assert "if-none-match" not in route.calls.last.request.headers
    assert second.cursor["etag"] == '"v1"'


def tweet(i, text="Lost my wallet in Karachi Saddar", conv=None):
    return {
        "id": str(i),
        "text": text,
        "created_at": "2026-11-20T10:00:00.000Z",
        "lang": "en",
        "conversation_id": conv or str(i),
    }


@respx.mock
def test_x_request_shape_cursor_cost_and_no_author_data():
    route = respx.get(X_API).respond(200, json={"data": [tweet(11), tweet(12)], "meta": {"newest_id": "12"}})
    connector = XConnector(key="x", enabled=True, bearer_token="t0ken", queries=["wallet Karachi"], sleep=NO_SLEEP)
    result = connector.fetch({}, Limits(max_posts=50, budget_remaining_usd=5.0))
    request = route.calls.last.request
    assert request.headers["authorization"] == "Bearer t0ken"
    assert request.url.params["query"] == "(wallet Karachi) -is:retweet"
    assert request.url.params["max_results"] == "50" and "since_id" not in request.url.params
    assert result.cursor == {"since_id": {"wallet Karachi": "12"}} and result.cost_units == pytest.approx(0.01)
    assert str(result.posts[0].source_url) == "https://x.com/i/web/status/11"
    assert result.posts[0].raw_meta == {"thread_id": "11", "lang": "en"}
    connector.fetch(result.cursor, Limits(max_posts=50))
    assert route.calls.last.request.url.params["since_id"] == "12"


def test_x_refuses_to_run_when_the_budget_is_spent():
    result = XConnector(key="x", enabled=True, bearer_token="t", queries=["q"]).fetch(
        {}, Limits(max_posts=50, budget_remaining_usd=0.02)
    )
    assert result.posts == [] and "budget" in result.message.lower()


@respx.mock
def test_x_budget_caps_the_number_of_posts_requested():
    route = respx.get(X_API).respond(200, json={"data": [], "meta": {}})
    XConnector(key="x", enabled=True, bearer_token="t", queries=["q"]).fetch(
        {}, Limits(max_posts=100, budget_remaining_usd=0.1)
    )
    assert route.calls.last.request.url.params["max_results"] == "20"  # $0.10 / $0.005


def test_x_is_off_without_token_or_when_disabled():
    assert XConnector(key="x", enabled=True, bearer_token=None, queries=["q"]).is_configured()[0] is False
    assert XConnector(key="x", enabled=False, bearer_token="t", queries=["q"]).is_configured()[0] is False


@respx.mock
def test_rate_limit_with_long_reset_ends_the_run_instead_of_sleeping():
    reset = int((datetime.now(UTC) + timedelta(minutes=15)).timestamp())
    respx.get(X_API).respond(429, headers={"x-rate-limit-reset": str(reset)})
    with pytest.raises(RateLimited) as info:
        XConnector(key="x", enabled=True, bearer_token="t", queries=["q"], sleep=NO_SLEEP).fetch({}, Limits())
    assert info.value.retry_after_s > 800


@respx.mock
def test_short_rate_limit_and_server_errors_are_retried():
    slept = []
    respx.get(X_API).mock(
        side_effect=[
            httpx.Response(429, headers={"retry-after": "2"}),
            httpx.Response(503),
            httpx.Response(200, json={"data": [tweet(1)], "meta": {"newest_id": "1"}}),
        ]
    )
    result = XConnector(key="x", enabled=True, bearer_token="t", queries=["q"], sleep=slept.append).fetch({}, Limits())
    assert len(result.posts) == 1 and slept[0] == 2


def test_retry_after_parsing():
    assert retry_after_seconds(httpx.Response(429, headers={"retry-after": "30"})) == 30
    assert retry_after_seconds(httpx.Response(429, headers={"x-ratelimit-reset": "12"})) == 12  # Reddit: seconds
    assert retry_after_seconds(httpx.Response(429)) is None


def test_reddit_stays_off_until_access_is_approved():
    connector = RedditConnector(key="r", client_id="id", client_secret="s", user_agent="ua", subreddits=["karachi"])
    ok, why = connector.is_configured()
    assert not ok and "approved" in why


@respx.mock
@pytest.mark.parametrize("discover_connection", [False, True])
def test_reddit_composio_proxies_read_only_search(discover_connection):
    item = {
        "name": "t3_abc",
        "title": "Lost wallet near Clifton",
        "selftext": "Brown wallet",
        "permalink": "/r/karachi/comments/abc/lost_wallet/",
        "created_utc": 1795000000,
        "author": "someone",
    }
    route = respx.post(COMPOSIO_PROXY).respond(
        json={"status": 200, "data": {"data": {"children": [{"data": item}]}}}
    )
    if discover_connection:
        active_account = {"id": "ca_test", "toolkit": {"slug": "reddit"}, "status": "ACTIVE", "user_id": "operator"}
        accounts = respx.get(COMPOSIO_ACCOUNTS).respond(json={"items": [active_account]})
    connector = RedditConnector(
        key="reddit:search",
        access_method="composio",
        composio_api_key="test-key",
        composio_account_id=None if discover_connection else "ca_test",
        composio_user_id=None if discover_connection else "operator",
        subreddits=["karachi"],
        sleep=NO_SLEEP,
    )
    assert not connector.is_configured()[0] and not route.called
    connector.approved = True
    result = connector.fetch({}, Limits(max_posts=10))
    if discover_connection:
        lookup = accounts.calls.last.request
        assert lookup.headers["x-api-key"] == "test-key"
        assert dict(lookup.url.params) == {"toolkit_slugs": "reddit", "statuses": "ACTIVE", "limit": "2"}
    request = route.calls.last.request
    payload = json.loads(request.content)
    assert request.headers["x-api-key"] == "test-key" and "authorization" not in request.headers
    assert payload["endpoint"] == "https://oauth.reddit.com/r/karachi/search" and payload["method"] == "GET"
    assert payload["connected_account_id"] == "ca_test" and payload["user_id"] == "operator"
    assert {"name": "limit", "value": "10", "type": "query"} in payload["parameters"]
    assert result.posts[0].text == "Lost wallet near Clifton\nBrown wallet"
    assert "author" not in result.posts[0].raw_meta
    assert result.cursor == {"last_created": {"karachi": 1795000000.0}}


@respx.mock
def test_reddit_composio_requires_explicit_selection_when_multiple_connections_exist():
    respx.get(COMPOSIO_ACCOUNTS).respond(json={"items": [{"id": "ca_one"}, {"id": "ca_two"}]})
    connector = RedditConnector(
        key="reddit:search",
        approved=True,
        access_method="composio",
        composio_api_key="test-key",
        subreddits=["karachi"],
    )
    with pytest.raises(SourceError, match="COMPOSIO_REDDIT_ACCOUNT_ID"):
        connector.fetch({}, Limits())


@respx.mock
@pytest.mark.parametrize("wrapped", [False, True])
def test_reddit_composio_stops_after_one_rate_limited_request(wrapped):
    route = respx.post(COMPOSIO_PROXY)
    if wrapped:
        route.respond(json={"status": 429, "headers": {"Retry-After": "25"}})
    else:
        route.respond(429, headers={"Retry-After": "25"})
    connector = RedditConnector(
        key="reddit:search",
        approved=True,
        access_method="composio",
        composio_api_key="test-key",
        composio_account_id="ca_test",
        subreddits=["karachi"],
        sleep=NO_SLEEP,
    )
    with pytest.raises(RateLimited) as exc:
        connector.fetch({}, Limits())
    assert exc.value.retry_after_s == 25
    assert route.call_count == 1


@respx.mock
def test_reddit_oauth_flow_and_normalization():
    respx.post("https://www.reddit.com/api/v1/access_token").respond(200, json={"access_token": "tok"})
    search = respx.get("https://oauth.reddit.com/r/karachi/search").respond(
        200,
        json={
            "data": {
                "children": [
                    {
                        "data": {
                            "name": "t3_abc",
                            "title": "Lost wallet near Clifton",
                            "selftext": "Brown, has CNIC",
                            "permalink": "/r/karachi/comments/abc/lost_wallet/",
                            "created_utc": 1795000000,
                            "author": "someone",
                        }
                    }
                ]
            }
        },
    )
    connector = RedditConnector(
        key="r",
        client_id="id",
        client_secret="s",
        user_agent="ua/1.0",
        subreddits=["karachi"],
        approved=True,
        sleep=NO_SLEEP,
    )
    result = connector.fetch({}, Limits())
    assert search.calls.last.request.headers["authorization"] == "bearer tok"
    p = result.posts[0]
    assert p.text == "Lost wallet near Clifton\nBrown, has CNIC" and "author" not in p.raw_meta
    assert str(p.source_url) == "https://www.reddit.com/r/karachi/comments/abc/lost_wallet/"
    assert result.cursor == {"last_created": {"karachi": 1795000000.0}}


@respx.mock
def test_bluesky_login_with_app_password_and_search():
    respx.post("https://bsky.social/xrpc/com.atproto.server.createSession").respond(200, json={"accessJwt": "jwt"})
    respx.get("https://bsky.social/xrpc/app.bsky.feed.searchPosts").respond(
        200,
        json={
            "posts": [
                {
                    "uri": "at://did:plc:xyz/app.bsky.feed.post/3kabc",
                    "indexedAt": "2026-11-20T10:00:00Z",
                    "record": {"text": "Found keys near Frere Hall", "createdAt": "2026-11-20T09:59:00Z"},
                    "author": {"handle": "someone.bsky.social"},
                }
            ]
        },
    )
    connector = BlueskyConnector(
        key="b",
        enabled=True,
        handle="me.bsky.social",
        app_password="app-pass",
        queries=["karachi found"],
        sleep=NO_SLEEP,
    )
    result = connector.fetch({}, Limits())
    assert str(result.posts[0].source_url) == "https://bsky.app/profile/did:plc:xyz/post/3kabc"
    assert "handle" not in json.dumps(result.posts[0].raw_meta)
    assert post_url("https://example.com") is None


@respx.mock
def test_mastodon_public_hashtag_timeline_keeps_only_public_lost_found_posts():
    respx.get("https://mastodon.test/api/v1/timelines/tag/karachi").respond(
        200,
        json=[
            {
                "id": "105",
                "uri": "https://mastodon.test/users/a/statuses/105",
                "url": "https://mastodon.test/@a/105",
                "content": "<p>Lost my cat near <b>Clifton</b></p>",
                "created_at": "2026-11-20T10:00:00Z",
                "visibility": "public",
                "reblog": None,
                "language": "en",
            },
            {
                "id": "106",
                "uri": "u2",
                "url": "https://mastodon.test/@b/106",
                "content": "<p>Lovely sunset</p>",
                "created_at": "2026-11-20T10:00:00Z",
                "visibility": "public",
                "reblog": None,
            },
            {
                "id": "107",
                "uri": "u3",
                "url": "https://mastodon.test/@c/107",
                "content": "<p>Lost phone</p>",
                "created_at": "2026-11-20T10:00:00Z",
                "visibility": "unlisted",
                "reblog": None,
            },
        ],
    )
    connector = MastodonConnector(key="m", instance="https://mastodon.test", hashtags=["karachi"], enabled=True)
    result = connector.fetch({}, Limits())
    assert [p.text for p in result.posts] == ["Lost my cat near Clifton"]
    assert result.skipped_irrelevant == 1 and result.cursor == {"since_id": {"karachi": "107"}}


def test_strip_html():
    assert strip_html("<p>Hello&nbsp;<b>world</b></p><p>Two</p>") == "Hello world\nTwo"


# ---- collector (database) -----------------------------------------------------------------------


class StubConnector:
    platform = "X"

    def __init__(self, result=None, error=None):
        self.key, self.platform, self.result, self.error = "stub:x", SourcePlatform.X, result, error

    def is_configured(self):
        return True, ""

    def fetch(self, cursor, limits):
        self.seen_limits = limits
        if self.error:
            raise self.error
        return self.result


@pytest.mark.db
def test_collector_records_run_ingests_and_saves_cursor(sessions, session):
    from lf_core.contracts import NormalizedPost
    from lf_worker.connectors.base import FetchResult

    posts = [
        NormalizedPost(
            source_platform="X",
            source_id=str(i),
            source_url=f"https://x.com/i/web/status/{i}",
            text=f"Lost wallet number {i} in Saddar",
            published_at=datetime.now(UTC),
        )
        for i in (1, 2)
    ]
    stub = StubConnector(FetchResult(posts, {"since_id": {"q": "2"}}, cost_units=0.01))
    summary = run_source(sessions, SourceSpec(stub, 60, 50, monthly_budget_usd=5.0))
    assert summary["status"] == "SUCCESS" and summary["new"] == 2
    assert stub.seen_limits.budget_remaining_usd == pytest.approx(5.0)
    again = run_source(sessions, SourceSpec(StubConnector(FetchResult(posts, {})), 60, 50, monthly_budget_usd=5.0))
    assert again["duplicate"] == 2
    assert session.get(SourceStateRow, "stub:x").cursor == {}
    assert spent_this_month(session, stub.platform, datetime.now(UTC)) == pytest.approx(0.01)


@pytest.mark.db
def test_collector_enforces_reddit_interval_and_honors_longer_retry_after(sessions, session):
    from lf_worker.connectors.base import FetchResult

    stub = StubConnector(error=RateLimited("slow down", 7200))
    stub.key, stub.platform = "reddit:search", SourcePlatform.REDDIT
    spec = SourceSpec(stub, 1, 50)
    now = datetime.now(UTC)
    assert run_source(sessions, spec, now=now)["status"] == "FAILED"
    assert run_source(sessions, spec, now=now + timedelta(minutes=90))["status"] == "PAUSED"
    stub.error, stub.result = None, FetchResult([], {})
    later = now + timedelta(hours=3)
    assert run_source(sessions, spec, now=later)["status"] == "SUCCESS"
    assert run_source(sessions, spec, now=later + timedelta(minutes=59))["status"] == "PAUSED"
    assert run_source(sessions, spec, now=later + timedelta(hours=1))["status"] == "SUCCESS"
    assert len(session.scalars(select(CollectionRun).where(CollectionRun.source_key == stub.key)).all()) == 3


@pytest.mark.db
def test_collector_pauses_a_source_after_repeated_failures(sessions, session):
    spec = SourceSpec(StubConnector(error=SourceError("down")), 60, 50)
    results = [run_source(sessions, spec) for _ in range(3)]
    assert [r["status"] for r in results] == ["FAILED", "FAILED", "FAILED"]
    assert results[-1]["paused_until"] is not None
    assert run_source(sessions, spec)["status"] == "PAUSED"
    runs = session.scalars(select(CollectionRun).where(CollectionRun.source_key == "stub:x")).all()
    assert len(runs) == 3 and all(r.errors[0]["message"] == "down" for r in runs)


def test_sources_yaml_keeps_unpermitted_sources_off():
    from lf_core.settings import Settings
    from lf_worker.collector import load_sources

    specs = load_sources(Settings(database_url="postgresql+psycopg://x@h/x", _env_file=None))
    configured = {s.connector.key for s in specs if s.connector.is_configured()[0]}
    assert configured == {"mastodon:mastodon-social", "rss:global-voices-pakistan"}
