"""Ollama client and extraction, with Ollama mocked (respx). No running Ollama needed."""

import json
from unittest.mock import Mock

import httpx
import pytest
import respx
from lf_core.settings import Settings
from lf_worker.ai.extraction import OLLAMA_SCHEMA, Extractor, build_messages
from lf_worker.ai.ollama_client import (
    CircuitBreaker,
    ConfigurationRefused,
    OllamaBadOutput,
    OllamaClient,
    OllamaTimeout,
    OllamaUnavailable,
)
from lf_worker.app import build_client, build_pipeline, check_ai
from lf_worker.cli import main

BASE = "http://127.0.0.1:11434"
CLOUD = "https://ollama.com"
CLOUD_MODEL = "gpt-oss:20b"
GOOD = {
    "report_type": "LOST",
    "item_name": "black wallet",
    "item_category": "WALLET",
    "description": "A black wallet.",
    "colour": "black",
    "brand": None,
    "location_text": "Saddar",
    "city": None,
    "date_expression": "kal",
    "is_resolution_update": False,
    "confidence": 0.9,
}


def chat_reply(content: str) -> httpx.Response:
    return httpx.Response(
        200,
        json={
            "message": {"role": "assistant", "content": content},
            "prompt_eval_count": 600,
            "eval_count": 80,
            "load_duration": 0,
        },
    )


@pytest.mark.parametrize("url", ["http://10.0.0.5:11434", "https://api.openai.com", "http://ollama.example.com"])
def test_refuses_non_local_ai_addresses(url):
    with pytest.raises(ConfigurationRefused):
        OllamaClient(url, "qwen2.5:3b")


@pytest.mark.parametrize("model", ["gpt-oss:120b-cloud", "qwen3-coder:480b-cloud", "deepseek-v3.1:cloud"])
def test_refuses_ollama_cloud_models(model):
    with pytest.raises(ConfigurationRefused):
        OllamaClient(BASE, model)


def test_local_addresses_and_models_are_accepted():
    for url in ("http://127.0.0.1:11434", "http://localhost:11434", "http://[::1]:11434"):
        OllamaClient(url, "qwen2.5:3b").close()


def test_cloud_defaults_and_missing_key(monkeypatch):
    for name in ("OLLAMA_API_KEY", "OLLAMA_BASE_URL", "OLLAMA_MODEL"):
        monkeypatch.delenv(name, raising=False)
    settings = Settings(database_url="unused", _env_file=None)
    assert (settings.ollama_base_url, settings.ollama_model) == (CLOUD, CLOUD_MODEL)
    with pytest.raises(ConfigurationRefused, match="OLLAMA_API_KEY"):
        build_client(settings)
    assert build_pipeline(settings).extractor is None


@respx.mock
def test_cloud_extraction_uses_direct_api_with_redacted_post(monkeypatch):
    monkeypatch.setenv("OLLAMA_API_KEY", "test-key")
    settings = Settings(database_url="unused", ollama_base_url=f"{CLOUD}/api", _env_file=None)
    route = respx.post(f"{CLOUD}/api/chat").mock(
        return_value=chat_reply("```json\n" + json.dumps(GOOD) + "\n```")
    )
    client = build_client(settings)
    report = Extractor(client).extract("Lost black wallet in Saddar, call 03001234567 or person@example.com")
    client.unload()
    client.close()

    request = route.calls.last.request
    body = json.loads(request.content)
    assert route.call_count == 1
    assert request.headers["Authorization"] == "Bearer test-key"
    assert body["model"] == CLOUD_MODEL and body["think"] == "low" and body["stream"] is False
    assert "format" not in body and "keep_alive" not in body and "num_ctx" not in body["options"]
    assert "report_type" in body["messages"][0]["content"]
    post = body["messages"][-1]["content"]
    assert "Saddar" in post and "03001234567" not in post and "person@example.com" not in post
    assert report.result.item_category == "WALLET"


@respx.mock
def test_cloud_catalogue_health_does_not_send_a_chat_request():
    route = respx.get(f"{CLOUD}/api/tags").respond(json={"models": [{"model": CLOUD_MODEL}]})
    client = OllamaClient(CLOUD, CLOUD_MODEL, api_key="test-key")
    health = client.health()
    client.close()
    assert health.ok and "check-ai" in health.message
    assert route.calls.last.request.headers["Authorization"] == "Bearer test-key"


@pytest.mark.parametrize("code", [401, 402, 403, 404, 429, 503])
@respx.mock
def test_cloud_account_and_service_errors_defer_extraction(code):
    respx.post(f"{CLOUD}/api/chat").respond(code, headers={"Retry-After": "1200"}, text="upstream details")
    client = OllamaClient(CLOUD, CLOUD_MODEL, api_key="test-key")
    with pytest.raises(OllamaUnavailable) as info:
        client.chat_json([], OLLAMA_SCHEMA)
    client.close()
    assert info.value.retry_after_s == (1200 if code in {402, 429} else None)
    assert "upstream details" not in str(info.value)


@respx.mock
def test_cloud_bearer_token_does_not_follow_redirects():
    respx.post(f"{CLOUD}/api/chat").respond(307, headers={"Location": "https://elsewhere.example/api/chat"})
    client = OllamaClient(CLOUD, CLOUD_MODEL, api_key="test-key")
    with pytest.raises(OllamaUnavailable, match="307"):
        client.chat_json([], OLLAMA_SCHEMA)
    client.close()


@respx.mock
def test_check_ai_runs_a_synthetic_cloud_extraction(settings, monkeypatch, capsys):
    settings = Settings(database_url=settings.database_url, ollama_api_key="test-key", _env_file=None)
    monkeypatch.setattr("lf_worker.cli.get_settings", lambda: settings)
    respx.post(f"{CLOUD}/api/chat").mock(return_value=chat_reply(json.dumps(GOOD)))
    assert main(["check-ai"]) == 0
    assert CLOUD_MODEL in capsys.readouterr().out


def test_health_poll_preserves_an_active_quota_cooldown(settings, monkeypatch):
    monkeypatch.setenv("OLLAMA_API_KEY", "test-key")
    runner = Mock(pipeline=build_pipeline(Settings(database_url=settings.database_url, _env_file=None)))
    runner.pipeline.breaker.trip("usage limited", retry_after_s=900)
    assert not check_ai(runner)
    runner.heartbeat.assert_called_once_with(False, "usage limited")


@respx.mock
def test_cloud_health_distinguishes_catalogue_access_from_inference(settings, monkeypatch):
    monkeypatch.setenv("OLLAMA_API_KEY", "test-key")
    runner = Mock(pipeline=build_pipeline(Settings(database_url=settings.database_url, _env_file=None)))
    respx.get(f"{CLOUD}/api/tags").respond(json={"models": [{"model": CLOUD_MODEL}]})
    respx.post(f"{CLOUD}/api/chat").mock(return_value=chat_reply(json.dumps(GOOD)))
    assert check_ai(runner)  # The queue may try an extraction.
    assert runner.heartbeat.call_args.args[0] is False
    runner.pipeline.extractor.extract("Lost black wallet in Saddar")
    assert check_ai(runner)
    assert runner.heartbeat.call_args.args[0] is True


@respx.mock
def test_openrouter_routes_only_to_free_endpoints(settings):
    settings = settings.model_copy(update={"ai_provider": "openrouter"})
    with pytest.raises(ConfigurationRefused, match="OPENROUTER_API_KEY"):
        build_client(settings)
    settings = Settings(
        database_url=settings.database_url, ai_provider="openrouter", openrouter_api_key="test-key", _env_file=None
    )
    with pytest.raises(ConfigurationRefused, match=":free"):
        build_client(settings, "openai/gpt-oss-20b")
    route = respx.post("https://openrouter.ai/api/v1/chat/completions").respond(
        json={"choices": [{"message": {"content": json.dumps(GOOD)}}]}
    )
    client = build_client(settings)
    result = Extractor(client).extract("Lost wallet in Saddar, call 03001234567")
    request = route.calls.last.request
    payload = json.loads(request.content)
    assert request.headers["Authorization"] == "Bearer test-key"
    assert payload["model"] == "recursive/flint-v1.0:free"
    assert payload["max_tokens"] == 4096
    assert payload["response_format"] == {"type": "json_object"}
    assert payload["provider"] == {
        "data_collection": "deny",
        "max_price": {"prompt": 0, "completion": 0, "request": 0},
    }
    assert "03001234567" not in payload["messages"][-1]["content"]
    assert result.result.item_category == "WALLET" and client.inference_verified
    route.respond(429, headers={"Retry-After": "120"})
    with pytest.raises(OllamaUnavailable) as info:
        Extractor(client).extract("Lost wallet in Saddar")
    assert info.value.retry_after_s == 120 and not client.inference_verified
    client.close()


@respx.mock
def test_health_reports_missing_model_with_the_fix():
    respx.get(f"{BASE}/api/tags").respond(json={"models": [{"name": "llama3.2:3b", "model": "llama3.2:3b"}]})
    health = OllamaClient(BASE, "qwen2.5:3b").health()
    assert not health.ok and "ollama pull qwen2.5:3b" in health.message


@respx.mock
def test_health_when_ollama_is_down():
    respx.get(f"{BASE}/api/tags").mock(side_effect=httpx.ConnectError("refused"))
    health = OllamaClient(BASE, "qwen2.5:3b").health()
    assert not health.reachable and "unreachable" in health.message


@respx.mock
def test_chat_sends_schema_and_deterministic_options():
    route = respx.post(f"{BASE}/api/chat").mock(return_value=chat_reply(json.dumps(GOOD)))
    parsed, _, stats = OllamaClient(BASE, "qwen2.5:3b").chat_json([{"role": "user", "content": "x"}], OLLAMA_SCHEMA)
    body = json.loads(route.calls.last.request.content)
    assert body["format"] == OLLAMA_SCHEMA and body["stream"] is False
    assert body["options"]["temperature"] == 0 and body["options"]["num_ctx"] == 2048
    assert "think" not in body  # only sent when configured, since non-thinking models reject it
    assert parsed["item_category"] == "WALLET" and stats.output_tokens == 80


@respx.mock
def test_think_flag_is_sent_when_configured():
    route = respx.post(f"{BASE}/api/chat").mock(return_value=chat_reply(json.dumps(GOOD)))
    OllamaClient(BASE, "qwen3:4b", think=False).chat_json([], OLLAMA_SCHEMA)
    assert json.loads(route.calls.last.request.content)["think"] is False


@respx.mock
@pytest.mark.parametrize(
    ("mock", "error"),
    [
        ({"side_effect": httpx.ConnectError("refused")}, OllamaUnavailable),
        ({"side_effect": httpx.ReadTimeout("slow")}, OllamaTimeout),
        ({"return_value": httpx.Response(404, text="model not found")}, OllamaUnavailable),
        ({"return_value": httpx.Response(500, text="boom")}, OllamaUnavailable),
        ({"return_value": chat_reply("not json {")}, OllamaBadOutput),
        ({"return_value": chat_reply("[1, 2]")}, OllamaBadOutput),
    ],
)
def test_errors_are_classified(mock, error):
    respx.post(f"{BASE}/api/chat").mock(**mock)
    with pytest.raises(error):
        OllamaClient(BASE, "qwen2.5:3b").chat_json([], OLLAMA_SCHEMA)


@respx.mock
def test_extractor_repairs_once_then_succeeds():
    route = respx.post(f"{BASE}/api/chat").mock(
        side_effect=[chat_reply('{"report_type": "LOST"'), chat_reply(json.dumps(GOOD))]
    )
    outcome = Extractor(OllamaClient(BASE, "qwen2.5:3b")).extract("Lost black wallet in Saddar kal")
    assert outcome.attempts == 2 and outcome.result.item_category == "WALLET"
    second = json.loads(route.calls[1].request.content)["messages"]
    assert second[-1]["role"] == "user" and "not valid" in second[-1]["content"]


@respx.mock
def test_extractor_gives_up_after_one_repair():
    respx.post(f"{BASE}/api/chat").mock(return_value=chat_reply('{"report_type": "MAYBE"}'))
    with pytest.raises(OllamaBadOutput) as info:
        Extractor(OllamaClient(BASE, "qwen2.5:3b")).extract("text")
    assert "MAYBE" in info.value.raw


def test_prompt_truncates_long_posts_and_keeps_few_shot_prefix_stable():
    a, b = build_messages("x" * 5000), build_messages("other post")
    assert len(a[-1]["content"]) < 1600
    assert a[:-1] == b[:-1]  # identical prefix lets Ollama reuse its prompt cache between posts


def test_circuit_breaker():
    now = [0.0]
    breaker = CircuitBreaker(60, clock=lambda: now[0])
    assert breaker.allow()
    breaker.trip("down")
    assert not breaker.allow() and breaker.last_error == "down"
    now[0] = 61
    assert breaker.allow()
