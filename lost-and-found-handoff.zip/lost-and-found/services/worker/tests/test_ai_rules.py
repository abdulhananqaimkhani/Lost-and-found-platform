"""Deterministic AI-stage logic: keyword prefilter, language, dates, grounding."""

from datetime import date, datetime
from zoneinfo import ZoneInfo

import pytest
from lf_core.enums import DatePrecision, Language
from lf_worker.ai.dates import resolve_date
from lf_worker.ai.extraction import ExtractionResult
from lf_worker.ai.grounding import ground
from lf_worker.ai.language import detect_language
from lf_worker.ai.prefilter import prefilter

PKT = ZoneInfo("Asia/Karachi")
FRIDAY_EVENING = datetime(2026, 11, 20, 18, 30, tzinfo=PKT)


@pytest.mark.parametrize(
    "text",
    [
        "Lost my black wallet near Saddar, please contact",
        "Kal Gulshan mein mera mobile gir gya, koi mile to rabta karein",
        "Mujhe ek batwa mila hai Tariq Road pe",
        "میرا شناختی کارڈ گم ہو گیا ہے",
        "Found a grey cat near Bahadurabad",
    ],
)
def test_prefilter_passes_real_lost_and_found_posts(text):
    assert prefilter(text).passed


@pytest.mark.parametrize(
    "text",
    [
        "We lost the match by 3 wickets",
        "Just found the best biryani in town",
        "iPhone 13 for sale, price 120k",
        "I lost my mind during exams",
        "Missing you guys so much",
        "Found it in some old boxed-up stuff. This fountain pen is fun to use again.",
        "I found a phone among my own belongings while tidying up.",
    ],
)
def test_prefilter_rejects_common_false_alarms(text):
    assert not prefilter(text).passed


def test_prefilter_intent():
    assert prefilter("Lost my phone in Saddar").intent == "LOST"
    assert prefilter("Found a phone in Saddar").intent == "FOUND"


@pytest.mark.parametrize(
    ("text", "language"),
    [
        ("Lost my wallet near the mall yesterday, please contact", Language.ENGLISH),
        ("Mera wallet kal gir gaya tha, koi mile to rabta karein", Language.ROMAN_URDU),
        ("میرا بٹوا گم ہو گیا ہے", Language.URDU),
    ],
)
def test_language_detection(text, language):
    assert detect_language(text) == language


@pytest.mark.parametrize(
    ("expression", "expected", "precision"),
    [
        ("yesterday evening", date(2026, 11, 19), DatePrecision.EXACT),
        ("kal raat", date(2026, 11, 19), DatePrecision.EXACT),
        ("aaj subah", date(2026, 11, 20), DatePrecision.EXACT),
        ("parson", date(2026, 11, 18), DatePrecision.APPROXIMATE),
        ("2 din pehle", date(2026, 11, 18), DatePrecision.APPROXIMATE),
        ("on Tuesday", date(2026, 11, 17), DatePrecision.APPROXIMATE),
        ("jumma ko", date(2026, 11, 20), DatePrecision.APPROXIMATE),
        ("15 Nov", date(2026, 11, 15), DatePrecision.EXACT),
        ("November 3rd", date(2026, 11, 3), DatePrecision.EXACT),
        ("14/11", date(2026, 11, 14), DatePrecision.EXACT),  # day-first, as written in Pakistan
        ("28 Dec", date(2025, 12, 28), DatePrecision.EXACT),  # no year + would be in the future → last year
        ("کل", date(2026, 11, 19), DatePrecision.EXACT),
        ("some time ago", None, DatePrecision.UNKNOWN),
        (None, None, DatePrecision.UNKNOWN),
    ],
)
def test_date_resolution(expression, expected, precision):
    assert resolve_date(expression, FRIDAY_EVENING) == (expected, precision)


def test_dates_are_never_after_the_post():
    assert resolve_date("25/12/2026", FRIDAY_EVENING) == (None, DatePrecision.UNKNOWN)


def test_date_uses_karachi_local_day():
    # 23:30 UTC on the 19th is already the 20th in Karachi.
    from datetime import UTC

    assert resolve_date("today", datetime(2026, 11, 19, 23, 30, tzinfo=UTC))[0] == date(2026, 11, 20)


def extraction(**overrides) -> ExtractionResult:
    base = {
        "report_type": "LOST",
        "item_name": "black wallet",
        "item_category": "WALLET",
        "description": "Black wallet.",
        "colour": "black",
        "location_text": "near Gulshan Chowrangi",
        "date_expression": "yesterday",
        "confidence": 0.9,
    }
    return ExtractionResult(**{**base, **overrides})


POST = "Lost my black wallet yesterday near Gulshan Chowrangi. Please contact."


def test_grounded_extraction_passes_through():
    g = ground(extraction(), POST, FRIDAY_EVENING, prefilter(POST))
    assert g.location_text == "near Gulshan Chowrangi" and g.incident_date == date(2026, 11, 19)
    assert g.review_reasons == [] and not g.needs_review and g.confidence >= 0.9


def test_hallucinated_location_is_removed_and_flagged():
    g = ground(extraction(location_text="Dolmen Mall Clifton"), POST, FRIDAY_EVENING, prefilter(POST))
    assert g.location_text is None and g.removed == {"location_text": "Dolmen Mall Clifton"}
    assert "location_text_not_in_post" in g.review_reasons and g.needs_review


def test_invented_date_colour_and_brand_are_removed():
    g = ground(
        extraction(date_expression="on 3 March", colour="red", brand="Gucci"), POST, FRIDAY_EVENING, prefilter(POST)
    )
    assert g.date_expression is None and g.incident_date is None and g.colour is None and g.brand is None


def test_urdu_location_copied_from_post_is_kept():
    text = "میرا بٹوا صدر میں گر گیا"
    g = ground(
        extraction(item_name="wallet", location_text="صدر", colour=None, date_expression=None),
        text,
        FRIDAY_EVENING,
        prefilter(text),
    )
    assert g.location_text == "صدر"


def test_item_name_synonym_counts_as_grounded():
    text = "Mera batwa Saddar mein gir gaya"
    g = ground(
        extraction(item_name="wallet", location_text="Saddar", colour=None, date_expression=None),
        text,
        FRIDAY_EVENING,
        prefilter(text),
    )
    assert "item_name_not_in_post" not in g.review_reasons


def test_city_is_only_set_when_stated():
    assert ground(extraction(), POST, FRIDAY_EVENING, prefilter(POST)).city is None
    stated = POST + " Karachi"
    g = ground(extraction(), stated, FRIDAY_EVENING, prefilter(stated))
    assert g.city == "Karachi" and g.city_source == "STATED"


def test_uncertain_uses_one_sided_keywords_or_is_dropped():
    g = ground(extraction(report_type="UNCERTAIN"), POST, FRIDAY_EVENING, prefilter(POST))
    assert g.report_type == "LOST" and "type_from_keywords" in g.review_reasons
    mixed = "Lost or found? wallet near Saddar"
    g2 = ground(extraction(report_type="UNCERTAIN"), mixed, FRIDAY_EVENING, prefilter(mixed))
    assert g2.report_type == "IRRELEVANT"


def test_low_model_confidence_is_flagged():
    g = ground(extraction(confidence=0.1), POST, FRIDAY_EVENING, prefilter(POST))
    # Half model self-report (0.1), half deterministic checks (all 5 pass) = 0.55, below the 0.6 bar.
    assert g.confidence == pytest.approx(0.55)
    assert "low_confidence" in g.review_reasons


def test_reordered_location_counts_as_copied_but_translation_does_not():
    text = "Found a gold ring in the washroom at Millennium Mall, 2nd floor, today."
    g = ground(
        extraction(
            location_text="2nd floor, Millennium Mall",
            date_expression="today",
            colour=None,
            item_name="gold ring",
            item_category="JEWELLERY",
        ),
        text,
        FRIDAY_EVENING,
        prefilter(text),
    )
    assert g.location_text == "2nd floor, Millennium Mall"
    urdu = "کراچی یونیورسٹی کی بس میں میرا بیگ رہ گیا"
    g2 = ground(
        extraction(
            location_text="University of Karachi",
            item_name="bag",
            item_category="BAG",
            colour=None,
            date_expression=None,
        ),
        urdu,
        FRIDAY_EVENING,
        prefilter(urdu),
    )
    assert g2.location_text is None and "location_text" in g2.removed


def test_gazetteer_fallback_uses_a_place_named_in_the_post():
    urdu = "میرا بٹوا گلشن اقبال بلاک 7 میں کہیں گر گیا"
    aliases = {"گلشن اقبال": "Gulshan-e-Iqbal"}

    def find(text):
        return next((label for alias, label in aliases.items() if alias in text), None)

    g = ground(
        extraction(location_text="Balaun Block 7", item_name="wallet", colour=None, date_expression=None),
        urdu,
        FRIDAY_EVENING,
        prefilter(urdu),
        place_finder=find,
    )
    assert g.location_text == "Gulshan-e-Iqbal" and g.removed == {"location_text": "Balaun Block 7"}
    assert "location_replaced_from_gazetteer" in g.review_reasons
    assert "location_text_not_in_post" not in g.review_reasons
