import httpx
import pytest
import respx
from lf_core.enums import LocationPrecision
from lf_core.models import GeocodeCache, Place
from lf_worker.geocoding.geocoder import (
    ChainGeocoder,
    GazetteerGeocoder,
    NominatimGeocoder,
    RateLimiter,
    bbox_radius_m,
    classify_precision,
    normalize_location,
    radius_for,
)
from sqlalchemy import select

NOMINATIM = "https://nominatim.test"


def place(key, name, precision="NEIGHBOURHOOD", lat=24.9, lng=67.1, radius=1500, aliases=()):
    return Place(
        key=key,
        name=name,
        label=name,
        aliases=list(aliases),
        city="Karachi",
        precision=precision,
        latitude=lat,
        longitude=lng,
        radius_m=radius,
        is_area_filter=True,
    )


GAZ = GazetteerGeocoder(
    [
        place("gulshan-e-iqbal", "Gulshan-e-Iqbal", radius=2500),
        place("gulshan-block-10a", "Gulshan-e-Iqbal Block 10-A", lat=24.87, radius=400),
        place("ned-university", "NED University", precision="POI", radius=None),
        place("tariq-road", "Tariq Road", precision="STREET", radius=None),
        place("bahadurabad", "Bahadurabad"),
    ]
)


@pytest.mark.parametrize(
    ("raw", "normalized"),
    [
        ("Gulshan blk 10-A ke paas", "gulshan e iqbal block 10 a"),
        ("near G-e-I", "g e i"),
        ("Defence Ph 6", "dha phase 6"),
        ("Gulshan-e-Hadeed bus stop", "gulshan e hadeed bus stop"),  # not Gulshan-e-Iqbal
        ("NED University main gate", "ned university main gate"),
    ],
)
def test_location_normalization_and_aliases(raw, normalized):
    assert normalize_location(raw) == normalized


def test_gazetteer_prefers_the_most_specific_place():
    assert GAZ.geocode(None, "Gulshan block 10-A near the park", None).place_key == "gulshan-block-10a"
    assert GAZ.geocode(None, "somewhere in Gulshan", None).place_key == "gulshan-e-iqbal"


def test_gazetteer_handles_aliases_and_spelling():
    assert GAZ.geocode(None, "NED main gate ke paas", None).place_key == "ned-university"
    assert GAZ.geocode(None, "Bahadurabaad", None).place_key == "bahadurabad"  # fuzzy
    assert GAZ.geocode(None, "Tariq Road pe", None).precision == LocationPrecision.STREET


def test_gazetteer_does_not_guess():
    assert GAZ.geocode(None, "Gulshan-e-Hadeed bus stop", None) is None
    assert GAZ.geocode(None, "University Road", None) is None


def test_precision_mapping_and_radius():
    assert classify_precision("amenity", "university") == LocationPrecision.POI
    assert classify_precision("highway", "primary") == LocationPrecision.STREET
    assert classify_precision("place", "suburb") == LocationPrecision.NEIGHBOURHOOD
    assert classify_precision("place", "city") == LocationPrecision.CITY
    assert bbox_radius_m(["24.90", "24.91", "67.00", "67.01"]) == 751  # half of hypot(1113 m, 1010 m)
    assert radius_for(LocationPrecision.NEIGHBOURHOOD, ["24.0", "24.5", "67.0", "67.5"]) == 2500  # clamped
    assert radius_for(LocationPrecision.POI, None) == 120


def test_chain_never_maps_city_only_or_other_cities():
    chain = ChainGeocoder(GAZ, None)
    assert chain.geocode(None, None, None).precision == LocationPrecision.UNKNOWN
    karachi = chain.geocode(None, "Karachi", None)
    assert karachi.precision == LocationPrecision.CITY and not karachi.mapped
    lahore = chain.geocode(None, "Liberty Market", "Lahore")
    assert not lahore.mapped and "outside_coverage" in lahore.reasons
    unknown = chain.geocode(None, "a place nobody knows", None)
    assert not unknown.mapped and unknown.needs_review


def nominatim(results):
    return httpx.Response(200, json=results)


def candidate(lat, lon, category="amenity", type_="restaurant", importance=0.3, bbox=None):
    return {
        "lat": str(lat),
        "lon": str(lon),
        "category": category,
        "type": type_,
        "importance": importance,
        "boundingbox": bbox or [str(lat - 0.001), str(lat + 0.001), str(lon - 0.001), str(lon + 0.001)],
        "display_name": "Somewhere, Karachi",
        "osm_type": "node",
        "osm_id": 1,
    }


def make_nominatim():
    return NominatimGeocoder(NOMINATIM, "LostAndFoundFinder-test/0.1", limiter=RateLimiter(0))


@pytest.mark.db
@respx.mock
def test_nominatim_is_called_once_per_phrase_then_cached(session):
    route = respx.get(f"{NOMINATIM}/search").mock(return_value=nominatim([candidate(24.93, 67.11)]))
    geocoder = make_nominatim()
    first = geocoder.geocode(session, "Habib University", None)
    second = geocoder.geocode(session, "habib   university", None)
    assert route.call_count == 1
    assert first.mapped and first.precision == LocationPrecision.POI and second.latitude == first.latitude
    request = route.calls.last.request
    assert request.headers["user-agent"].startswith("LostAndFoundFinder")
    assert request.url.params["bounded"] == "1" and request.url.params["countrycodes"] == "pk"


@pytest.mark.db
@respx.mock
def test_nominatim_negative_results_are_cached_too(session):
    route = respx.get(f"{NOMINATIM}/search").mock(return_value=nominatim([]))
    geocoder = make_nominatim()
    assert geocoder.geocode(session, "Nowhere Plaza", None) is None
    assert geocoder.geocode(session, "Nowhere Plaza", None) is None
    assert route.call_count == 1
    assert session.scalars(select(GeocodeCache)).first().result is None


@pytest.mark.db
@respx.mock
def test_ambiguous_places_are_not_mapped(session):
    respx.get(f"{NOMINATIM}/search").mock(
        return_value=nominatim([candidate(24.80, 67.03, importance=0.30), candidate(24.95, 67.15, importance=0.29)])
    )
    result = make_nominatim().geocode(session, "Madina Masjid", None)
    assert not result.mapped and result.needs_review and "location_ambiguous" in result.reasons


@pytest.mark.db
@respx.mock
def test_results_outside_karachi_are_ignored(session):
    respx.get(f"{NOMINATIM}/search").mock(return_value=nominatim([candidate(31.52, 74.35)]))  # Lahore
    assert make_nominatim().geocode(session, "Liberty", None) is None


def test_rate_limiter_spaces_requests():
    now, slept = [0.0], []

    def sleep(seconds):
        slept.append(seconds)
        now[0] += seconds

    limiter = RateLimiter(1.1, clock=lambda: now[0], sleep=sleep)
    limiter.wait()
    limiter.wait()
    assert slept == [pytest.approx(1.1)]
