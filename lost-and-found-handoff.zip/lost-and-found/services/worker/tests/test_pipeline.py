"""End-to-end pipeline on the real test database, with the AI replaced by a scripted fake."""

from datetime import UTC, datetime, timedelta

import pytest
from lf_core.contracts import NormalizedPost
from lf_core.enums import JobStatus, JobType
from lf_core.ingest import IngestStatus, ingest_post
from lf_core.models import ProcessingJob, Report, ReportMatch, Source, StatusChange
from lf_core.queue import MAX_ATTEMPTS, backoff_seconds, claim, defer, enqueue, fail, recover_stale_locks
from lf_core.settings import Settings
from lf_worker.ai.extraction import ExtractionOutcome, ExtractionResult
from lf_worker.ai.ollama_client import CircuitBreaker, OllamaBadOutput, OllamaUnavailable
from lf_worker.geocoding.geocoder import ChainGeocoder, GazetteerGeocoder
from lf_worker.pipeline import Pipeline
from lf_worker.runner import Runner
from sqlalchemy import func, select

pytestmark = pytest.mark.db
NOW = datetime(2026, 11, 20, 13, 0, tzinfo=UTC)


class FakeExtractor:
    """Returns scripted results by keyword, or raises a scripted error."""

    model = "fake-model"

    def __init__(self, answers=None, error=None):
        self.answers, self.error, self.calls = answers or {}, error, 0
        self.article_calls = 0

    def extract(self, text, *, article=False):
        self.calls += 1
        self.article_calls += article
        if self.error:
            raise self.error
        for key, answer in self.answers.items():
            if key in text:
                return ExtractionOutcome(ExtractionResult(**answer), "{}", self.model, 1)
        return ExtractionOutcome(ExtractionResult(report_type="IRRELEVANT"), "{}", self.model, 1)


LOST_WALLET = {
    "report_type": "LOST",
    "item_name": "black wallet",
    "item_category": "WALLET",
    "description": "Black leather wallet with a CNIC.",
    "colour": "black",
    "location_text": "Gulshan Chowrangi",
    "date_expression": "yesterday",
    "confidence": 0.9,
}
FOUND_WALLET = {
    "report_type": "FOUND",
    "item_name": "black wallet",
    "item_category": "WALLET",
    "description": "Black leather wallet found.",
    "colour": "black",
    "location_text": "Gulshan-e-Iqbal",
    "date_expression": "today",
    "confidence": 0.9,
}


def post(text, n=1, platform="MASTODON", thread=None, when=NOW):
    return NormalizedPost(
        source_platform=platform,
        source_id=f"post-{n}",
        source_url=f"https://social.test/p/{n}",
        text=text,
        published_at=when,
        raw_meta={"thread_id": thread} if thread else {},
    )


def make_runner(sessions, extractor):
    settings = Settings(database_url="postgresql+psycopg://x@127.0.0.1:1/x", _env_file=None)
    pipeline = Pipeline(settings, extractor, ChainGeocoder(GazetteerGeocoder(), None), CircuitBreaker(60))
    return Runner(sessions, pipeline, worker="test-worker")


def drain(runner, n=20):
    return runner.run_batch(max_jobs=n)


def real_reports(session):
    return session.scalars(select(Report).where(Report.is_demo.is_(False))).all()


def test_rss_article_uses_article_prompt_and_creates_a_report(sessions, session):
    text = "A commuter lost a black wallet yesterday near Gulshan Chowrangi in Karachi."
    ingest_post(session, post(text, platform="RSS"))
    ingest_post(session, post("A wallet app lost access to its servers in Karachi.", n=2, platform="RSS"))
    session.commit()
    extractor = FakeExtractor({"commuter": LOST_WALLET, "app": {"report_type": "UNCERTAIN"}})
    counts = drain(make_runner(sessions, extractor))
    assert counts["report_created"] == 1 and counts["irrelevant"] == 1 and extractor.article_calls == 2
    assert real_reports(session)[0].primary_platform == "RSS"


def test_lost_post_becomes_a_mapped_report_and_matches_a_found_post(sessions, session):
    lost_text = "Lost my black leather wallet yesterday near Gulshan Chowrangi, CNIC 42101-1234567-1 inside"
    found_text = "Found a black leather wallet today in Gulshan-e-Iqbal, owner contact me"
    ingest_post(session, post(lost_text, 1))
    ingest_post(session, post(found_text, 2, when=NOW + timedelta(hours=20)))
    session.commit()

    counts = drain(make_runner(sessions, FakeExtractor({"Lost my": LOST_WALLET, "Found a": FOUND_WALLET})))
    assert counts["report_created"] == 2 and counts["geocoded"] == 2 and counts["matched"] == 2

    session.expire_all()
    lost = session.scalars(select(Report).where(Report.report_type == "LOST", Report.is_demo.is_(False))).one()
    assert lost.location_precision == "NEIGHBOURHOOD" and lost.latitude is not None  # via the gazetteer
    assert lost.city == "Karachi" and lost.city_source == "INFERRED_FROM_GAZETTEER"
    assert str(lost.incident_date) == "2026-11-19" and lost.extraction_model == "fake-model"
    assert "1234567" not in lost.search_text and "42101" not in lost.search_text
    assert lost.status == "POTENTIAL_MATCH"
    match = session.scalars(select(ReportMatch).where(ReportMatch.lost_report_id == lost.id)).one()
    assert match.score >= 0.65 and set(match.breakdown) == {"category", "text", "distance", "date", "attributes"}
    actors = session.scalars(select(StatusChange.actor).where(StatusChange.report_id == lost.id)).all()
    assert set(actors) == {"SYSTEM"}


def test_prefilter_rejects_without_calling_the_ai(sessions, session):
    ingest_post(session, post("We lost the match by 3 wickets in Karachi"))
    session.commit()
    fake = FakeExtractor()
    assert drain(make_runner(sessions, fake))["prefilter_rejected"] == 1
    assert fake.calls == 0
    assert (
        session.scalars(select(Source.processing_state).where(Source.external_post_id == "post-1")).one()
        == "PREFILTER_REJECTED"
    )


def test_irrelevant_posts_create_no_report(sessions, session):
    ingest_post(session, post("Found a great new phone shop in Saddar, cheap phones"))
    session.commit()
    assert drain(make_runner(sessions, FakeExtractor()))["irrelevant"] == 1
    assert real_reports(session) == []


def test_when_ollama_is_down_jobs_wait_without_using_attempts(sessions, session):
    ingest_post(session, post("Lost my black wallet near Saddar, please contact"))
    session.commit()
    runner = make_runner(sessions, FakeExtractor(error=OllamaUnavailable("Ollama unreachable")))
    assert drain(runner) == {"deferred": 1}
    session.expire_all()
    job = session.scalars(select(ProcessingJob).where(ProcessingJob.job_type == "EXTRACT")).one()
    assert job.status == "PENDING" and job.attempts == 0 and "unavailable" in job.last_error.lower()
    assert job.available_at > datetime.now(UTC)
    assert runner.pipeline.breaker.is_open
    assert real_reports(session) == []


def test_invalid_model_output_fails_permanently_and_keeps_raw_output(sessions, session):
    ingest_post(session, post("Lost my black wallet near Saddar, please contact"))
    session.commit()
    error = OllamaBadOutput("bad", raw='{"report_type": "MAYBE"}')
    assert drain(make_runner(sessions, FakeExtractor(error=error))) == {"failed": 1}
    session.expire_all()
    job = session.scalars(select(ProcessingJob)).one()
    assert job.status == "FAILED" and "MAYBE" in job.result["raw_output"]
    assert session.scalars(select(Source.processing_state).where(Source.is_demo.is_(False))).one() == "FAILED"


def test_exact_copy_is_attached_not_reprocessed(sessions, session):
    text = "Lost my black leather wallet yesterday near Gulshan Chowrangi, please contact"
    ingest_post(session, post(text, 1))
    session.commit()
    fake = FakeExtractor({"Lost my": LOST_WALLET})
    drain(make_runner(sessions, fake))
    outcome = ingest_post(session, post(text.upper() + "!!", 2, platform="X"))
    session.commit()
    assert outcome.status == IngestStatus.ATTACHED_COPY
    report = real_reports(session)[0]
    session.refresh(report)
    assert report.source_count == 2 and fake.calls == 1


def test_reworded_repost_is_attached_as_near_duplicate(sessions, session):
    ingest_post(session, post("Lost my black leather wallet yesterday near Gulshan Chowrangi, please contact", 1))
    ingest_post(session, post("lost my black leather wallet near Gulshan Chowrangi yesterday. please contact me", 2))
    session.commit()
    counts = drain(make_runner(sessions, FakeExtractor({"ost my": LOST_WALLET})))
    assert counts["report_created"] == 1 and counts["attached_near_duplicate"] == 1
    assert real_reports(session)[0].source_count == 2


def test_resolution_update_in_the_same_thread_resolves_the_report(sessions, session):
    ingest_post(session, post("Lost my black leather wallet yesterday near Gulshan Chowrangi", 1, thread="t-9"))
    session.commit()
    update = {**LOST_WALLET, "is_resolution_update": True, "location_text": None, "date_expression": None}
    runner = make_runner(sessions, FakeExtractor({"UPDATE": update, "Lost my": LOST_WALLET}))
    drain(runner)
    ingest_post(session, post("UPDATE: my lost wallet has been returned, thanks!", 2, thread="t-9"))
    session.commit()
    assert drain(runner)["resolved_by_source"] == 1
    report = real_reports(session)[0]
    session.refresh(report)
    assert report.status == "RESOLVED"
    change = session.scalars(select(StatusChange).where(StatusChange.to_status == "RESOLVED")).one()
    assert change.actor == "SOURCE_EVIDENCE"


def test_resolution_update_without_a_known_original_is_not_listed(sessions, session):
    ingest_post(session, post("UPDATE: my lost wallet has been returned, thanks!", 1, thread="unknown"))
    session.commit()
    update = {**LOST_WALLET, "is_resolution_update": True}
    assert drain(make_runner(sessions, FakeExtractor({"UPDATE": update})))["resolution_update_without_original"] == 1
    assert real_reports(session) == []


def test_hallucinated_fields_make_the_report_unverified(sessions, session):
    ingest_post(session, post("Lost my black wallet somewhere in Karachi, please contact"))
    session.commit()
    invented = {**LOST_WALLET, "location_text": "Dolmen Mall Clifton"}
    drain(make_runner(sessions, FakeExtractor({"Lost my": invented})))
    report = real_reports(session)[0]
    assert report.status == "UNVERIFIED" and report.needs_review and report.location_text is None
    assert report.latitude is None and "location_text_not_in_post" in report.review_reasons


# ---- queue mechanics ----------------------------------------------------------------------------


def _source(session, n=1):
    ingest_post(session, post(f"Lost wallet number {n} near Saddar", n))
    session.flush()
    return session.scalars(select(Source).where(Source.external_post_id == f"post-{n}")).one()


def test_enqueue_is_idempotent_for_open_jobs(session):
    source = _source(session)
    assert enqueue(session, JobType.EXTRACT, source_id=source.id) is False  # ingest already queued it
    assert session.scalar(select(func.count()).select_from(ProcessingJob)) == 1


def test_claim_skips_jobs_locked_by_another_worker(test_engine, session):
    # Two real connections: the second worker must not get the job the first one has locked.
    from sqlalchemy.orm import Session as OrmSession

    with OrmSession(test_engine) as a, OrmSession(test_engine) as b:
        src = _source(a, 77)
        a.commit()
        try:
            job_a = claim(a, "worker-a", [JobType.EXTRACT])  # row locked, transaction still open
            assert job_a is not None
            assert claim(b, "worker-b", [JobType.EXTRACT]) is None
        finally:
            a.rollback()
            b.rollback()
            a.execute(ProcessingJob.__table__.delete().where(ProcessingJob.source_id == src.id))
            a.execute(Source.__table__.delete().where(Source.id == src.id))
            a.commit()


def test_failures_back_off_then_stop(session):
    source = _source(session)
    job = session.scalars(select(ProcessingJob).where(ProcessingJob.source_id == source.id)).one()
    for attempt in range(1, MAX_ATTEMPTS + 1):
        fail(session, job, "timeout", retryable=True)
        assert job.attempts == attempt
    assert job.status == JobStatus.FAILED.value
    assert 24 <= backoff_seconds(1) <= 36 and 48 <= backoff_seconds(2) <= 72


def test_defer_does_not_count_an_attempt_and_stale_locks_recover(session):
    source = _source(session)
    job = session.scalars(select(ProcessingJob).where(ProcessingJob.source_id == source.id)).one()
    defer(session, job, 60, "Ollama down")
    assert job.attempts == 0 and job.status == "PENDING"
    job.status, job.locked_at = "RUNNING", datetime.now(UTC) - timedelta(hours=1)
    session.flush()
    assert recover_stale_locks(session) == 1
    session.refresh(job)
    assert job.status == "PENDING"


def test_posts_outside_karachi_are_not_listed(sessions, session):
    ingest_post(session, post("Someone lost a purple wallet at Truro railway station, I handed it in", 1))
    ingest_post(session, post("Lost my wallet in Lahore near Liberty Market", 2))
    session.commit()
    lost = {**LOST_WALLET, "location_text": None, "date_expression": None}
    counts = drain(make_runner(sessions, FakeExtractor({"lost a purple": lost, "Lost my wallet in Lahore": lost})))
    assert counts["outside_coverage"] == 2 and real_reports(session) == []


def test_karachi_only_sources_count_as_in_coverage(sessions, session):
    p = post("Lost my black wallet, please contact", 1)
    p.raw_meta["scope"] = "karachi"
    ingest_post(session, p)
    session.commit()
    lost = {**LOST_WALLET, "location_text": None, "date_expression": None}
    assert drain(make_runner(sessions, FakeExtractor({"Lost my": lost})))["report_created"] == 1


def test_prefilter_can_be_switched_off_so_every_post_reaches_the_model(sessions, session):
    ingest_post(session, post("Someone left a calculator in the NED corridor, I have it", 1))
    session.commit()
    runner = make_runner(sessions, FakeExtractor())
    runner.pipeline.settings.prefilter_enabled = False
    assert drain(runner)["irrelevant"] == 1  # reached the (fake) model instead of being dropped
    assert runner.pipeline.extractor.calls == 1
