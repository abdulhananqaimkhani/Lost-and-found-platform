"""SQLAlchemy models. The schema itself is created by the hand-written Alembic migrations in
database/migrations, which also add CHECK constraints, generated columns and spatial indexes."""

from __future__ import annotations

import uuid
from datetime import date, datetime

from sqlalchemy import (
    BigInteger,
    Boolean,
    Computed,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, TSVECTOR
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.types import UserDefinedType


class Geography(UserDefinedType):
    """PostGIS geography(Point, 4326). Only used in SQL expressions, never loaded into Python."""

    cache_ok = True

    def get_col_spec(self, **kw: object) -> str:
        return "geography(Point,4326)"


class AnyGeography(UserDefinedType):
    """Plain PostGIS geography (any shape), e.g. for a map envelope polygon."""

    cache_ok = True

    def get_col_spec(self, **kw: object) -> str:
        return "geography"


GEOG_FROM_LATLNG = (
    "CASE WHEN latitude IS NOT NULL AND longitude IS NOT NULL "
    "THEN (ST_SetSRID(ST_MakePoint(longitude, latitude), 4326))::geography END"
)


def new_id() -> str:
    return uuid.uuid4().hex


class Base(DeclarativeBase):
    pass


class Place(Base):
    """Gazetteer entry derived from OpenStreetMap (ODbL). Coordinates are never typed in by hand."""

    __tablename__ = "places"

    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    label: Mapped[str] = mapped_column(String(200))
    aliases: Mapped[list[str]] = mapped_column(ARRAY(Text), default=list)
    city: Mapped[str] = mapped_column(String(80), default="Karachi")
    display_name: Mapped[str | None] = mapped_column(Text)
    osm_type: Mapped[str | None] = mapped_column(String(16))
    osm_id: Mapped[int | None] = mapped_column(BigInteger)
    osm_category: Mapped[str | None] = mapped_column(String(40))
    osm_type_detail: Mapped[str | None] = mapped_column(String(40))
    precision: Mapped[str] = mapped_column(String(16))
    latitude: Mapped[float] = mapped_column(Float)
    longitude: Mapped[float] = mapped_column(Float)
    geog = mapped_column(Geography(), Computed(GEOG_FROM_LATLNG, persisted=True), deferred=True)
    radius_m: Mapped[int | None] = mapped_column(Integer)
    is_area_filter: Mapped[bool] = mapped_column(Boolean, default=True)
    provenance: Mapped[str] = mapped_column(String(40), default="OSM_NOMINATIM")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class Report(Base):
    __tablename__ = "reports"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=new_id)
    report_type: Mapped[str] = mapped_column(String(8))
    item_name: Mapped[str] = mapped_column(String(200))
    item_category: Mapped[str] = mapped_column(String(16))
    description: Mapped[str | None] = mapped_column(Text)
    attributes: Mapped[dict] = mapped_column(JSONB, default=dict)

    location_text: Mapped[str | None] = mapped_column(String(300))
    city: Mapped[str | None] = mapped_column(String(80))
    city_source: Mapped[str | None] = mapped_column(String(32))
    latitude: Mapped[float | None] = mapped_column(Float)
    longitude: Mapped[float | None] = mapped_column(Float)
    geog = mapped_column(Geography(), Computed(GEOG_FROM_LATLNG, persisted=True), deferred=True)
    location_precision: Mapped[str] = mapped_column(String(16), default="UNKNOWN")
    location_radius_m: Mapped[int | None] = mapped_column(Integer)
    place_key: Mapped[str | None] = mapped_column(ForeignKey("places.key", ondelete="SET NULL"))
    geocode_provider: Mapped[str | None] = mapped_column(String(32))

    incident_date: Mapped[date | None] = mapped_column(Date)
    date_expression: Mapped[str | None] = mapped_column(String(120))
    date_precision: Mapped[str] = mapped_column(String(16), default="UNKNOWN")
    reported_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    collected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    status: Mapped[str] = mapped_column(String(16), default="ACTIVE")
    confidence_score: Mapped[float] = mapped_column(Float, default=0.0)
    needs_review: Mapped[bool] = mapped_column(Boolean, default=False)
    review_reasons: Mapped[list[str]] = mapped_column(JSONB, default=list)
    language: Mapped[str] = mapped_column(String(16), default="OTHER")
    extraction_model: Mapped[str | None] = mapped_column(String(80))
    primary_platform: Mapped[str] = mapped_column(String(16))
    source_count: Mapped[int] = mapped_column(Integer, default=1)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)

    search_text: Mapped[str] = mapped_column(Text, default="")
    search_tsv = mapped_column(
        TSVECTOR, Computed("to_tsvector('simple', coalesce(search_text, ''))", persisted=True), deferred=True
    )
    last_activity_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    sources: Mapped[list[Source]] = relationship(
        back_populates="report", order_by="Source.published_at", lazy="selectin"
    )


class CollectionRun(Base):
    __tablename__ = "collection_runs"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    source_key: Mapped[str] = mapped_column(String(80), index=True)
    platform: Mapped[str] = mapped_column(String(16))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(16), default="RUNNING")
    records_fetched: Mapped[int] = mapped_column(Integer, default=0)
    records_new: Mapped[int] = mapped_column(Integer, default=0)
    records_duplicate: Mapped[int] = mapped_column(Integer, default=0)
    errors: Mapped[list] = mapped_column(JSONB, default=list)
    cost_units: Mapped[float] = mapped_column(Float, default=0.0)
    cursor_before: Mapped[dict | None] = mapped_column(JSONB)
    cursor_after: Mapped[dict | None] = mapped_column(JSONB)
    message: Mapped[str | None] = mapped_column(Text)


class SourceStateRow(Base):
    """Per-source incremental cursor and failure tracking."""

    __tablename__ = "source_states"

    source_key: Mapped[str] = mapped_column(String(80), primary_key=True)
    cursor: Mapped[dict] = mapped_column(JSONB, default=dict)
    consecutive_failures: Mapped[int] = mapped_column(Integer, default=0)
    paused_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


class Source(Base):
    """One collected post or article. Publisher bylines are kept for licensed articles."""

    __tablename__ = "sources"

    id: Mapped[str] = mapped_column(String(40), primary_key=True, default=new_id)
    platform: Mapped[str] = mapped_column(String(16))
    source_key: Mapped[str | None] = mapped_column(String(80))
    external_post_id: Mapped[str] = mapped_column(String(200))
    original_url: Mapped[str] = mapped_column(Text)
    canonical_url: Mapped[str | None] = mapped_column(Text, unique=True)
    original_text: Mapped[str] = mapped_column(Text)
    text_hash: Mapped[str] = mapped_column(String(64), index=True)
    published_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    collected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    raw_meta: Mapped[dict] = mapped_column(JSONB, default=dict)
    prefilter_score: Mapped[float | None] = mapped_column(Float)
    processing_state: Mapped[str] = mapped_column(String(24), default="NEW")
    report_id: Mapped[str | None] = mapped_column(ForeignKey("reports.id", ondelete="SET NULL"), index=True)
    collection_run_id: Mapped[int | None] = mapped_column(ForeignKey("collection_runs.id", ondelete="SET NULL"))
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)
    text_purged_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    report: Mapped[Report | None] = relationship(back_populates="sources")


class ProcessingJob(Base):
    __tablename__ = "processing_jobs"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    job_type: Mapped[str] = mapped_column(String(16))
    status: Mapped[str] = mapped_column(String(16), default="PENDING")
    source_id: Mapped[str | None] = mapped_column(ForeignKey("sources.id", ondelete="CASCADE"))
    report_id: Mapped[str | None] = mapped_column(ForeignKey("reports.id", ondelete="CASCADE"))
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    available_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    locked_by: Mapped[str | None] = mapped_column(String(80))
    last_error: Mapped[str | None] = mapped_column(Text)
    result: Mapped[dict | None] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))


class StatusSuggestion(Base):
    __tablename__ = "status_suggestions"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    report_id: Mapped[str] = mapped_column(ForeignKey("reports.id", ondelete="CASCADE"), index=True)
    suggested_status: Mapped[str] = mapped_column(String(16))
    reason: Mapped[str] = mapped_column(String(500), default="")
    fingerprint_hash: Mapped[str] = mapped_column(String(64))
    review_status: Mapped[str] = mapped_column(String(16), default="PENDING")
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class StatusChange(Base):
    """Audit log: every status change, who or what made it, and why."""

    __tablename__ = "status_changes"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    report_id: Mapped[str] = mapped_column(ForeignKey("reports.id", ondelete="CASCADE"), index=True)
    from_status: Mapped[str | None] = mapped_column(String(16))
    to_status: Mapped[str] = mapped_column(String(16))
    reason: Mapped[str] = mapped_column(Text)
    actor: Mapped[str] = mapped_column(String(24))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class ReportMatch(Base):
    __tablename__ = "report_matches"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    lost_report_id: Mapped[str] = mapped_column(ForeignKey("reports.id", ondelete="CASCADE"), index=True)
    found_report_id: Mapped[str] = mapped_column(ForeignKey("reports.id", ondelete="CASCADE"), index=True)
    score: Mapped[float] = mapped_column(Float)
    breakdown: Mapped[dict] = mapped_column(JSONB)
    distance_km: Mapped[float | None] = mapped_column(Float)
    days_apart: Mapped[int | None] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


class GeocodeCache(Base):
    __tablename__ = "geocode_cache"

    query_norm: Mapped[str] = mapped_column(String(300), primary_key=True)
    provider: Mapped[str] = mapped_column(String(32))
    # NULL result = a cached "not found", so the same failing query isn't sent again.
    result: Mapped[dict | None] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class WorkerHeartbeat(Base):
    __tablename__ = "worker_heartbeats"

    worker_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    last_seen: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    info: Mapped[dict] = mapped_column(JSONB, default=dict)
