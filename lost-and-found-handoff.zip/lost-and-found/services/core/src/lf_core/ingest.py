"""Stage 0 of the pipeline: store a collected post once, and queue it for AI extraction.

Duplicates are caught three ways (PROJECT_PLAN.md §4.2): same platform + post id, same canonical
URL, or the same normalized text. An exact text copy is linked to the existing report as an extra
source instead of being processed again.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from sqlalchemy import or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .contracts import NormalizedPost
from .enums import JobType, SourceState
from .models import Report, Source
from .queue import enqueue
from .status import touch_activity
from .text import canonical_url, text_hash


class IngestStatus(StrEnum):
    NEW = "NEW"
    DUPLICATE = "DUPLICATE"
    ATTACHED_COPY = "ATTACHED_COPY"


@dataclass
class IngestOutcome:
    status: IngestStatus
    source_id: str | None = None
    report_id: str | None = None


def attach_source_to_report(session: Session, source: Source, report: Report, state: SourceState) -> None:
    source.report = report  # keeps report.sources in sync within the session
    source.processing_state = state.value
    report.source_count = (report.source_count or 0) + 1
    touch_activity(session, report.id, source.published_at)


def ingest_post(
    session: Session,
    post: NormalizedPost,
    *,
    source_key: str | None = None,
    collection_run_id: int | None = None,
) -> IngestOutcome:
    url = str(post.source_url)
    canon = canonical_url(url)
    existing = session.scalars(
        select(Source).where(
            or_(
                (Source.platform == post.source_platform.value) & (Source.external_post_id == post.source_id),
                Source.canonical_url == canon,
            )
        )
    ).first()
    if existing is not None:
        return IngestOutcome(IngestStatus.DUPLICATE, existing.id, existing.report_id)

    digest = text_hash(post.text)
    source = Source(
        platform=post.source_platform.value,
        source_key=source_key,
        external_post_id=post.source_id,
        original_url=url,
        canonical_url=canon,
        original_text=post.text,
        text_hash=digest,
        published_at=post.published_at,
        collected_at=post.collected_at,
        raw_meta=post.raw_meta,
        collection_run_id=collection_run_id,
        processing_state=SourceState.NEW.value,
    )

    copy_of = session.scalars(
        select(Source).where(Source.text_hash == digest, Source.report_id.is_not(None)).limit(1)
    ).first()
    try:
        with session.begin_nested():
            session.add(source)
            session.flush()
    except IntegrityError:
        # Another worker stored the same post between our check and insert.
        return IngestOutcome(IngestStatus.DUPLICATE)

    if copy_of is not None and copy_of.report is not None:
        attach_source_to_report(session, source, copy_of.report, SourceState.ATTACHED_DUPLICATE)
        return IngestOutcome(IngestStatus.ATTACHED_COPY, source.id, copy_of.report_id)

    enqueue(session, JobType.EXTRACT, source_id=source.id)
    return IngestOutcome(IngestStatus.NEW, source.id)
