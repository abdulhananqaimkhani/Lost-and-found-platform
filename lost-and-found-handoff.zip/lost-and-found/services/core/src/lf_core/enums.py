"""Enumerations shared by the database, API and worker. Values match apps/web/src/lib/types.ts."""

from enum import StrEnum


class ReportType(StrEnum):
    LOST = "LOST"
    FOUND = "FOUND"


class ReportStatus(StrEnum):
    ACTIVE = "ACTIVE"
    POTENTIAL_MATCH = "POTENTIAL_MATCH"
    UNVERIFIED = "UNVERIFIED"
    DISPUTED = "DISPUTED"
    STALE = "STALE"
    RESOLVED = "RESOLVED"


class ItemCategory(StrEnum):
    WALLET = "WALLET"
    PHONE = "PHONE"
    DOCUMENT_ID = "DOCUMENT_ID"
    BAG = "BAG"
    KEYS = "KEYS"
    JEWELLERY = "JEWELLERY"
    ELECTRONICS = "ELECTRONICS"
    PET = "PET"
    VEHICLE = "VEHICLE"
    CLOTHING = "CLOTHING"
    OTHER = "OTHER"


class LocationPrecision(StrEnum):
    POI = "POI"
    STREET = "STREET"
    NEIGHBOURHOOD = "NEIGHBOURHOOD"
    CITY = "CITY"
    UNKNOWN = "UNKNOWN"


MAPPABLE_PRECISIONS = frozenset({LocationPrecision.POI, LocationPrecision.STREET, LocationPrecision.NEIGHBOURHOOD})


class DatePrecision(StrEnum):
    EXACT = "EXACT"
    APPROXIMATE = "APPROXIMATE"
    UNKNOWN = "UNKNOWN"


class Language(StrEnum):
    ENGLISH = "ENGLISH"
    ROMAN_URDU = "ROMAN_URDU"
    URDU = "URDU"
    MIXED = "MIXED"
    OTHER = "OTHER"


class SourcePlatform(StrEnum):
    DEMO = "DEMO"
    RSS = "RSS"
    X = "X"
    REDDIT = "REDDIT"
    BLUESKY = "BLUESKY"
    MASTODON = "MASTODON"
    WEB = "WEB"
    COMMUNITY = "COMMUNITY"


class SourceState(StrEnum):
    """Where a collected post is in the pipeline."""

    NEW = "NEW"
    PREFILTER_REJECTED = "PREFILTER_REJECTED"
    IRRELEVANT = "IRRELEVANT"
    EXTRACTED = "EXTRACTED"
    ATTACHED_DUPLICATE = "ATTACHED_DUPLICATE"
    FAILED = "FAILED"


class JobType(StrEnum):
    EXTRACT = "EXTRACT"
    GEOCODE = "GEOCODE"
    MATCH = "MATCH"


class JobStatus(StrEnum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    DONE = "DONE"
    FAILED = "FAILED"


class SuggestionType(StrEnum):
    RESOLVED = "RESOLVED"
    INACCURATE = "INACCURATE"


class ReviewStatus(StrEnum):
    PENDING = "PENDING"
    ACCEPTED = "ACCEPTED"
    REJECTED = "REJECTED"


class StatusActor(StrEnum):
    SYSTEM = "SYSTEM"
    OPERATOR_CLI = "OPERATOR_CLI"
    SOURCE_EVIDENCE = "SOURCE_EVIDENCE"


class RunStatus(StrEnum):
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"


class CitySource(StrEnum):
    STATED = "STATED"
    INFERRED_FROM_GAZETTEER = "INFERRED_FROM_GAZETTEER"


def values(enum: type[StrEnum]) -> list[str]:
    return [member.value for member in enum]
