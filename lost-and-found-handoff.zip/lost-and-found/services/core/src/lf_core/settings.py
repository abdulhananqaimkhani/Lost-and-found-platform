"""Configuration for every Python service, read from environment variables and the repo-root .env file.

No secret has a default value. Missing required settings fail at start-up with a clear message,
instead of silently running with a guessable password.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Annotated, Literal

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

REPO_ROOT = Path(__file__).resolve().parents[4]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=REPO_ROOT / ".env", env_file_encoding="utf-8", extra="ignore", case_sensitive=False
    )

    database_url: str = Field(description="SQLAlchemy URL, e.g. postgresql+psycopg://user:pass@127.0.0.1/db")
    test_database_url: str | None = None

    # API
    cors_origins: Annotated[list[str], NoDecode] = ["http://localhost:3000", "http://127.0.0.1:3000"]
    fingerprint_secret: SecretStr | None = None
    service_token: SecretStr | None = None
    show_demo_data: bool = True
    read_rate_per_minute: int = 120
    suggestion_rate_per_hour: int = 5
    # Only these peers may set X-Forwarded-For (the Next.js server on the same machine).
    trusted_proxies: Annotated[list[str], NoDecode] = ["127.0.0.1", "::1"]

    # AI credentials are only used by the worker.
    ai_provider: Literal["ollama", "openrouter"] = "ollama"
    openrouter_model: str = "recursive/flint-v1.0:free"
    openrouter_api_key: SecretStr | None = None
    ollama_base_url: str = "https://ollama.com"
    ollama_model: str = "gpt-oss:20b"
    ollama_api_key: SecretStr | None = None
    ollama_timeout_seconds: float = 180.0
    ollama_num_ctx: int = 2048
    ollama_think: bool | Literal["low", "medium", "high"] | None = None
    ai_max_jobs_per_minute: int = 4

    # Geocoding
    geocoder_enabled: bool = True
    nominatim_url: str = "https://nominatim.openstreetmap.org"
    nominatim_user_agent: str = "LostAndFoundFinder-dev/0.1 (university final year project)"

    # Pipeline thresholds
    # The keyword prefilter saves AI calls but can drop real posts (held-out recall 0.89). With low volume,
    # turning it off (every collected post goes to the model) maximises recall.
    prefilter_enabled: bool = True
    min_confidence_active: float = 0.6
    match_threshold: float = 0.65
    stale_after_days: int = 45
    irrelevant_text_retention_days: int = 7

    # Sources
    sources_config: Path = Path("config/sources.yaml")
    x_bearer_token: SecretStr | None = None
    reddit_client_id: str | None = None
    reddit_client_secret: SecretStr | None = None
    reddit_user_agent: str | None = None
    composio_api_key: SecretStr | None = None
    composio_reddit_account_id: str | None = None
    composio_reddit_user_id: str | None = None
    bluesky_handle: str | None = None
    bluesky_app_password: SecretStr | None = None

    @field_validator("cors_origins", "trusted_proxies", mode="before")
    @classmethod
    def _split_csv(cls, value: object) -> object:
        if isinstance(value, str):
            return [part.strip() for part in value.split(",") if part.strip()]
        return value

    @field_validator("ollama_think", mode="before")
    @classmethod
    def _blank_is_none(cls, value: object) -> object:
        return None if value == "" else value

    @field_validator(
        "fingerprint_secret",
        "service_token",
        "ollama_api_key",
        "openrouter_api_key",
        "x_bearer_token",
        "reddit_client_secret",
        "composio_api_key",
        "bluesky_app_password",
        mode="before",
    )
    @classmethod
    def _blank_secret_is_none(cls, value: object) -> object:
        return None if value == "" else value

    def resolve_path(self, path: Path) -> Path:
        return path if path.is_absolute() else REPO_ROOT / path


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
