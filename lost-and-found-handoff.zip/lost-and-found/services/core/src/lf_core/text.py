"""Text utilities shared by the API and the worker.

The normalization and redaction rules mirror apps/web/src/lib/redact.ts and data/query.ts,
so search behaves the same in demo mode and against the real backend. Tests pin both down.
"""

from __future__ import annotations

import hashlib
import re
import unicodedata
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

# --- Redaction (privacy) ------------------------------------------------------------------------

MASK = "•••"
# Pakistani CNIC: 13 digits, usually 12345-1234567-1 (also spaces or no separators).
CNIC_PATTERN = re.compile(r"\b(\d{5})[-\s]?(\d{7})[-\s]?(\d)\b")
# Mobile numbers: 03XX-XXXXXXX, +92 3XX XXXXXXX, 0092...
PHONE_PATTERN = re.compile(r"(?:\+92|0092|\b0)[-\s]?3\d{2}[-\s]?\d{7}\b")
# Landlines such as 021-34567890 or (021) 3456 7890.
LANDLINE_PATTERN = re.compile(r"\(?\b0\d{2}\)?[-\s]?\d{3,4}[-\s]?\d{4}\b")
EMAIL_PATTERN = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
PLACEHOLDER_PATTERN = re.compile(r"\[(?:phone|email) •••\]|\d{2}•••-•••-•••")


def redact_text(text: str) -> str:
    """Mask CNIC numbers, phone numbers and e-mail addresses before text is shown to anyone."""
    text = CNIC_PATTERN.sub(lambda m: f"{m.group(1)[:2]}{MASK}-{MASK}-{MASK}", text)
    text = PHONE_PATTERN.sub(f"[phone {MASK}]", text)
    text = LANDLINE_PATTERN.sub(f"[phone {MASK}]", text)
    return EMAIL_PATTERN.sub(f"[email {MASK}]", text)


def strip_redaction_markers(text: str) -> str:
    """Remove placeholders so a masked phone number doesn't make a post match a search for "phone"."""
    return PLACEHOLDER_PATTERN.sub(" ", text)


# --- Search normalization -----------------------------------------------------------------------

_COMBINING = re.compile(r"[̀-ͯ]")
_NON_WORD = re.compile(r"[\W_]+", re.UNICODE)


def normalize_text(text: str) -> str:
    """Lower-case, strip Latin accents, and keep only letters and digits separated by single spaces."""
    text = unicodedata.normalize("NFKD", text.lower())
    text = _COMBINING.sub("", text)
    # Python's \w also matches Unicode combining marks used in Urdu (e.g. U+064F). JS \p{L}\p{N}
    # does not, so treat marks as separators too, to keep tokens identical to the frontend.
    text = "".join(" " if unicodedata.category(ch).startswith("M") else ch for ch in text)
    return _NON_WORD.sub(" ", text).strip()


# Same groups as apps/web/src/lib/data/query.ts.
SYNONYMS: list[list[str]] = [
    ["wallet", "batwa", "purse"],
    ["phone", "mobile", "cell", "fone"],
    ["keys", "key", "chabi", "chabiyan", "chaabi"],
    ["bag", "backpack", "basta", "handbag"],
    ["cnic", "id", "shanakhti"],
    ["cat", "billi"],
    ["dog", "kutta"],
    ["lost", "gum", "kho", "missing"],
    ["found", "mila", "mili", "mil"],
]


def expand_token(token: str) -> list[str]:
    for group in SYNONYMS:
        if token in group:
            return group
    return [token]


CATEGORY_LABEL = {
    "WALLET": "Wallet",
    "PHONE": "Phone",
    "DOCUMENT_ID": "ID & documents",
    "BAG": "Bag",
    "KEYS": "Keys",
    "JEWELLERY": "Jewellery",
    "ELECTRONICS": "Electronics",
    "PET": "Pet",
    "VEHICLE": "Vehicle",
    "CLOTHING": "Clothing",
    "OTHER": "Other",
}


def build_search_text(
    *,
    item_name: str,
    description: str | None,
    location_text: str | None,
    city: str | None,
    item_category: str,
    source_texts: list[str],
) -> str:
    """The text indexed for search. Source texts are redacted and placeholder-stripped first,
    so search can never be used to probe for a hidden phone number."""
    parts = [item_name, description or "", location_text or "", city or "", CATEGORY_LABEL[item_category]]
    parts += [strip_redaction_markers(redact_text(t)) for t in source_texts]
    return normalize_text(" ".join(parts))


_TSQUERY_SAFE = re.compile(r"^[^\W_]+$", re.UNICODE)


def search_tokens(query: str, max_tokens: int = 8) -> list[list[str]]:
    """Split a visitor's query into tokens, each expanded to its synonym group.

    Every token is made of letters/digits only (guaranteed by normalize_text), so it is safe to
    place inside a tsquery. The tsquery itself is still passed to PostgreSQL as a bound parameter.
    """
    tokens = [t for t in normalize_text(query[:120]).split(" ") if t and _TSQUERY_SAFE.match(t)]
    return [expand_token(t) for t in tokens[:max_tokens]]


def to_prefix_tsquery(query: str) -> str | None:
    """'black batwa' -> '(black:*) & (wallet:* | batwa:* | purse:*)'  (word-prefix match, like the mock)."""
    groups = search_tokens(query)
    if not groups:
        return None
    return " & ".join("(" + " | ".join(f"{alt}:*" for alt in group) + ")" for group in groups)


# --- De-duplication helpers ---------------------------------------------------------------------

_TRACKING_PARAMS = re.compile(r"^(utm_|fbclid$|gclid$|igshid$|si$|s$|ref$|ref_src$)")


def canonical_url(url: str) -> str:
    """Normalize a URL so the same post shared with different tracking parameters dedupes."""
    parts = urlsplit(url.strip())
    query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True) if not _TRACKING_PARAMS.match(k)]
    host = parts.netloc.lower()
    if host.startswith("www."):
        host = host[4:]
    if host in {"twitter.com", "mobile.twitter.com"}:
        host = "x.com"
    path = parts.path.rstrip("/") or "/"
    return urlunsplit((parts.scheme.lower() or "https", host, path, urlencode(sorted(query)), ""))


def text_hash(text: str) -> str:
    """Hash of the normalized text, used to catch the same post copied to several places."""
    return hashlib.sha256(normalize_text(text).encode("utf-8")).hexdigest()
