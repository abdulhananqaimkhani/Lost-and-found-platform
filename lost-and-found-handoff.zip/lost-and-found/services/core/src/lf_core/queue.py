"""A small job queue stored in PostgreSQL (the processing_jobs table).

Workers claim jobs with SELECT ... FOR UPDATE SKIP LOCKED, so two workers never take the same job.
Failures are retried with exponential backoff. When Ollama is down, jobs are *deferred*:
they wait without using up a retry attempt, so nothing is lost while the AI is unavailable.
"""

from __future__ import annotations

import random
from datetime import UTC, datetime, timedelta

from sqlalchemy import select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from .enums import JobStatus, JobType
from .models import ProcessingJob

MAX_ATTEMPTS = 5
BASE_BACKOFF_SECONDS = 30


def now_utc() -> datetime:
    return datetime.now(UTC)


def enqueue(
    session: Session,
    job_type: JobType,
    *,
    source_id: str | None = None,
    report_id: str | None = None,
    delay_seconds: float = 0,
) -> bool:
    """Add a job unless an open (PENDING/RUNNING) one of the same type already exists for the target."""
    stmt = (
        pg_insert(ProcessingJob)
        .values(
            job_type=job_type.value,
            status=JobStatus.PENDING.value,
            source_id=source_id,
            report_id=report_id,
            available_at=now_utc() + timedelta(seconds=delay_seconds),
        )
        .on_conflict_do_nothing()
        .returning(ProcessingJob.id)
    )
    return session.execute(stmt).first() is not None


def claim(session: Session, worker_id: str, job_types: list[JobType]) -> ProcessingJob | None:
    job = session.scalars(
        select(ProcessingJob)
        .where(
            ProcessingJob.status == JobStatus.PENDING.value,
            ProcessingJob.available_at <= now_utc(),
            ProcessingJob.job_type.in_([t.value for t in job_types]),
        )
        .order_by(ProcessingJob.available_at, ProcessingJob.id)
        .limit(1)
        .with_for_update(skip_locked=True)
    ).first()
    if job is None:
        return None
    job.status = JobStatus.RUNNING.value
    job.locked_at = now_utc()
    job.locked_by = worker_id
    session.flush()
    return job


def complete(session: Session, job: ProcessingJob, result: dict | None = None) -> None:
    job.status = JobStatus.DONE.value
    job.result = result
    job.finished_at = now_utc()
    job.locked_at = None
    job.locked_by = None
    job.last_error = None


def backoff_seconds(attempts: int, rng: random.Random | None = None) -> float:
    """30 s, 60 s, 120 s, ... with ±20% jitter so retries from many jobs don't line up."""
    base = BASE_BACKOFF_SECONDS * (2 ** max(0, attempts - 1))
    jitter = (rng or random).uniform(-0.2, 0.2)
    return base * (1 + jitter)


def fail(session: Session, job: ProcessingJob, error: str, *, retryable: bool = True) -> None:
    job.attempts += 1
    job.last_error = error[:2000]
    job.locked_at = None
    job.locked_by = None
    if retryable and job.attempts < MAX_ATTEMPTS:
        job.status = JobStatus.PENDING.value
        job.available_at = now_utc() + timedelta(seconds=backoff_seconds(job.attempts))
    else:
        job.status = JobStatus.FAILED.value
        job.finished_at = now_utc()


def defer(session: Session, job: ProcessingJob, seconds: float, reason: str) -> None:
    """Put a job back without counting an attempt (used when Ollama is unreachable)."""
    job.status = JobStatus.PENDING.value
    job.available_at = now_utc() + timedelta(seconds=seconds)
    job.locked_at = None
    job.locked_by = None
    job.last_error = reason[:2000]


def recover_stale_locks(session: Session, older_than_minutes: int = 20) -> int:
    """Jobs left RUNNING by a crashed worker go back to PENDING."""
    cutoff = now_utc() - timedelta(minutes=older_than_minutes)
    result = session.execute(
        update(ProcessingJob)
        .where(ProcessingJob.status == JobStatus.RUNNING.value, ProcessingJob.locked_at < cutoff)
        .values(status=JobStatus.PENDING.value, locked_at=None, locked_by=None, available_at=now_utc())
    )
    return result.rowcount
