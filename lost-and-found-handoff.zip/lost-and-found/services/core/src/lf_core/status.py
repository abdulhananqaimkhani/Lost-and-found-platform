"""Report status changes. Every change goes through here so it is always written to the audit log."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from .enums import ReportStatus, StatusActor
from .models import Report, StatusChange

# Which actor may move a report into which status. Anonymous visitors are not in this table:
# their suggestions are stored separately and never change a status (PROJECT_PLAN.md §10).
ALLOWED: dict[StatusActor, set[ReportStatus]] = {
    StatusActor.SYSTEM: {
        ReportStatus.ACTIVE,
        ReportStatus.UNVERIFIED,
        ReportStatus.POTENTIAL_MATCH,
        ReportStatus.STALE,
    },
    StatusActor.SOURCE_EVIDENCE: {ReportStatus.RESOLVED},
    StatusActor.OPERATOR_CLI: set(ReportStatus),
}

# Statuses the system must never overwrite automatically.
FINAL_FOR_SYSTEM = {ReportStatus.RESOLVED, ReportStatus.DISPUTED}


class StatusChangeNotAllowed(Exception):
    pass


def change_status(
    session: Session, report: Report, to_status: ReportStatus, *, reason: str, actor: StatusActor
) -> bool:
    """Change a report's status and record it. Returns False if nothing changed."""
    if to_status not in ALLOWED[actor]:
        raise StatusChangeNotAllowed(f"{actor} may not set {to_status}")
    current = ReportStatus(report.status)
    if current == to_status:
        return False
    if actor == StatusActor.SYSTEM and current in FINAL_FOR_SYSTEM:
        return False
    session.add(
        StatusChange(
            report_id=report.id,
            from_status=current.value,
            to_status=to_status.value,
            reason=reason[:1000],
            actor=actor.value,
        )
    )
    report.status = to_status.value
    return True


def mark_stale_reports(session: Session, *, older_than_days: int, now: datetime | None = None) -> int:
    """Reports with no new source activity for N days become STALE (still listed, labelled "Old report")."""
    now = now or datetime.now(UTC)
    cutoff = now - timedelta(days=older_than_days)
    candidates = session.scalars(
        select(Report).where(
            Report.last_activity_at < cutoff,
            Report.status.in_([ReportStatus.ACTIVE, ReportStatus.POTENTIAL_MATCH, ReportStatus.UNVERIFIED]),
            Report.is_demo.is_(False),
        )
    ).all()
    changed = 0
    for report in candidates:
        if change_status(
            session,
            report,
            ReportStatus.STALE,
            reason=f"No new activity for {older_than_days} days",
            actor=StatusActor.SYSTEM,
        ):
            changed += 1
    return changed


def touch_activity(session: Session, report_id: str, when: datetime) -> None:
    session.execute(
        update(Report).where(Report.id == report_id, Report.last_activity_at < when).values(last_activity_at=when)
    )
