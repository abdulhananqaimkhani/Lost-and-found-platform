"""Match scoring between a LOST and a FOUND report (PROJECT_PLAN.md §11).

score = 0.30·category + 0.30·text + 0.20·distance + 0.10·date + 0.10·attributes
Every component is between 0 and 1, and the breakdown is stored so the UI can explain the score.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import UTC, date, datetime

WEIGHTS = {"category": 0.30, "text": 0.30, "distance": 0.20, "date": 0.10, "attributes": 0.10}
MAX_DISTANCE_KM = 5.0
MAX_DAYS_APART = 14
UNKNOWN_DISTANCE_SCORE = 0.3  # Same city but no coordinates: weak evidence, not zero.
UNKNOWN_ATTRIBUTE_SCORE = 0.5  # Neither agrees nor conflicts.

RELATED_CATEGORIES = {
    frozenset({"WALLET", "DOCUMENT_ID"}),
    frozenset({"PHONE", "ELECTRONICS"}),
    frozenset({"BAG", "CLOTHING"}),
}


@dataclass
class ScoredPair:
    score: float
    breakdown: dict[str, float]
    distance_km: float | None
    days_apart: int


def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def _as_datetime(value: date | datetime) -> datetime:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=UTC)
    return datetime(value.year, value.month, value.day, tzinfo=UTC)


def category_score(a: str, b: str) -> float:
    if a == b:
        return 1.0
    return 0.5 if frozenset({a, b}) in RELATED_CATEGORIES else 0.0


# Colour words in English, Roman Urdu and Urdu → one canonical name, so "kaala" and "black" agree.
COLOUR_SYNONYMS = {
    "black": {"black", "kala", "kaala", "kali", "kaali", "کالا", "کالی", "کالے"},
    "white": {"white", "safed", "sufaid", "سفید"},
    "brown": {"brown", "bhoora", "bhura", "بھورا", "بھوری"},
    "green": {"green", "hara", "hari", "ہرا", "ہری"},
    "blue": {"blue", "neela", "neeli", "navy", "نیلا", "نیلی", "نیلے"},
    "red": {"red", "laal", "lal", "maroon", "لال", "سرخ"},
    "grey": {"grey", "gray", "surmai", "سرمئی"},
    "gold": {"gold", "golden", "sona", "sonay", "سونا", "سنہرا"},
    "silver": {"silver", "chandi", "چاندی"},
    "pink": {"pink", "gulabi", "گلابی"},
    "yellow": {"yellow", "peela", "peeli", "پیلا"},
    "orange": {"orange", "narangi", "نارنجی"},
    "purple": {"purple", "jamni", "جامنی"},
}
_COLOUR_INDEX = {word: canon for canon, words in COLOUR_SYNONYMS.items() for word in words}
COLOUR_CONFLICT_FACTOR = 0.85  # added after the first matching evaluation (docs/benchmarks/README.md)


def canonical_colours(colour: str | None) -> set[str]:
    if not colour:
        return set()
    return {_COLOUR_INDEX[w] for w in colour.lower().replace(",", " ").split() if w in _COLOUR_INDEX}


def colour_relation(a: dict, b: dict) -> str:
    """'agree', 'conflict' or 'unknown' (missing, or a colour word we don't recognise)."""
    ca, cb = canonical_colours((a or {}).get("colour")), canonical_colours((b or {}).get("colour"))
    if not ca or not cb:
        return "unknown"
    return "agree" if ca & cb else "conflict"


def attribute_score(a: dict, b: dict) -> float:
    relation = colour_relation(a, b)
    return {"agree": 1.0, "conflict": 0.0}.get(relation, UNKNOWN_ATTRIBUTE_SCORE)


def score_pair(
    *,
    category_a: str,
    category_b: str,
    text_similarity: float,
    coords_a: tuple[float, float] | None,
    coords_b: tuple[float, float] | None,
    when_a: date | datetime,
    when_b: date | datetime,
    attributes_a: dict,
    attributes_b: dict,
) -> ScoredPair:
    distance = haversine_km(*coords_a, *coords_b) if coords_a and coords_b else None
    days = math.floor(abs((_as_datetime(when_a) - _as_datetime(when_b)).total_seconds()) / 86_400 + 0.5)
    breakdown = {
        "category": category_score(category_a, category_b),
        "text": max(0.0, min(1.0, text_similarity)),
        "distance": UNKNOWN_DISTANCE_SCORE if distance is None else max(0.0, 1 - distance / MAX_DISTANCE_KM),
        "date": max(0.0, 1 - days / MAX_DAYS_APART),
        "attributes": attribute_score(attributes_a, attributes_b),
    }
    score = sum(WEIGHTS[k] * v for k, v in breakdown.items())
    if colour_relation(attributes_a, attributes_b) == "conflict":
        # Two stated colours that differ are strong evidence of different items.
        score *= COLOUR_CONFLICT_FACTOR
    return ScoredPair(round(score, 4), {k: round(v, 4) for k, v in breakdown.items()}, distance, days)
