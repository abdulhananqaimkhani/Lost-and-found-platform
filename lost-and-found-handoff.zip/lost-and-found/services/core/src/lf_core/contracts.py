"""The normalized post: the one contract between collection connectors and the AI pipeline."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field, HttpUrl, field_validator

from .enums import SourcePlatform


class NormalizedPost(BaseModel):
    source_platform: SourcePlatform
    source_id: str = Field(min_length=1, max_length=200)
    source_url: HttpUrl
    text: str = Field(min_length=1, max_length=20_000)
    published_at: datetime
    collected_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    # Platform specifics that are not personal data (e.g. thread id, language tag, feed name).
    raw_meta: dict[str, Any] = Field(default_factory=dict)

    @field_validator("published_at", "collected_at")
    @classmethod
    def _aware(cls, value: datetime) -> datetime:
        return value if value.tzinfo else value.replace(tzinfo=UTC)

    @field_validator("raw_meta")
    @classmethod
    def _no_author_fields(cls, value: dict[str, Any]) -> dict[str, Any]:
        """Author identity is not needed to describe a lost item, so it is never stored."""
        banned = {"author", "author_name", "username", "handle", "user", "display_name", "email"}
        return {k: v for k, v in value.items() if k.lower() not in banned}
