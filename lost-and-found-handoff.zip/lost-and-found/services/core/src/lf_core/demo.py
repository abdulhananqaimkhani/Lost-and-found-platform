"""Loads the hand-written demo dataset (database/schema/demo_dataset.json) into the database.

The same records power the frontend's mock mode, so the UI behaves identically in both modes.
Every demo row is flagged is_demo, uses the DEMO platform and .invalid URLs, and can be hidden
with SHOW_DEMO_DATA=false or removed with `python -m lf_worker seed-demo --remove`.
"""

from __future__ import annotations

import json
from datetime import UTC, date, datetime, timedelta
from pathlib import Path

from sqlalchemy import delete, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from .enums import MAPPABLE_PRECISIONS, LocationPrecision
from .models import Place, Report, ReportMatch, Source, StatusSuggestion
from .scoring import score_pair
from .settings import REPO_ROOT
from .text import build_search_text, canonical_url, text_hash

DEFAULT_DATASET = REPO_ROOT / "database" / "schema" / "demo_dataset.json"
MIN_AREA_FILTER_RADIUS_M = 1500


def _parse_ts(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def upsert_places(session: Session, places: list[dict]) -> int:
    for p in places:
        values = {
            "key": p["key"],
            "name": p["name"],
            "label": p.get("label") or p["name"],
            "aliases": p.get("aliases", []),
            "city": p.get("city", "Karachi"),
            "display_name": p.get("display_name"),
            "osm_type": p.get("osm_type"),
            "osm_id": p.get("osm_id"),
            "osm_category": p.get("osm_category"),
            "osm_type_detail": p.get("osm_type_detail"),
            "precision": p["precision"],
            "latitude": p["latitude"],
            "longitude": p["longitude"],
            "radius_m": p.get("radius_m"),
            "is_area_filter": p.get("is_area_filter", True),
            "provenance": p.get("provenance", "OSM_NOMINATIM"),
        }
        stmt = pg_insert(Place).values(**values)
        update_cols = {k: stmt.excluded[k] for k in values if k not in {"key", "aliases"}}
        session.execute(stmt.on_conflict_do_update(index_elements=["key"], set_=update_cols))
    return len(places)


def remove_demo_data(session: Session) -> int:
    ids = session.scalars(select(Report.id).where(Report.is_demo.is_(True))).all()
    session.execute(delete(Source).where(Source.is_demo.is_(True)))
    session.execute(delete(Report).where(Report.is_demo.is_(True)))
    return len(ids)


def load_demo_dataset(session: Session, path: Path = DEFAULT_DATASET) -> dict[str, int]:
    data = json.loads(path.read_text(encoding="utf-8"))
    upsert_places(session, data["places"])
    places = {p["key"]: p for p in data["places"]}
    remove_demo_data(session)
    session.flush()

    reports: dict[str, Report] = {}
    for seed in data["reports"]:
        place = places.get(seed["place"]) if seed.get("place") else None
        precision = place["precision"] if place else seed.get("fallback_precision") or "UNKNOWN"
        mapped = place is not None and LocationPrecision(precision) in MAPPABLE_PRECISIONS
        posts = seed["posts"]
        published = [_parse_ts(p["published_at"]) for p in posts]
        collected = [ts + timedelta(minutes=p["collected_after_min"]) for ts, p in zip(published, posts, strict=True)]

        report = Report(
            id=seed["id"],
            report_type=seed["type"],
            item_name=seed["item"],
            item_category=seed["category"],
            description=seed["description"],
            attributes={"colour": seed.get("colour"), "brand": seed.get("brand")},
            location_text=seed.get("location_text"),
            city=seed.get("city"),
            latitude=place["latitude"] if mapped else None,
            longitude=place["longitude"] if mapped else None,
            location_precision=precision,
            location_radius_m=place["radius_m"] if mapped else None,
            place_key=place["key"] if place else None,
            geocode_provider="DEMO_GAZETTEER" if place else None,
            incident_date=date.fromisoformat(seed["incident_date"]) if seed.get("incident_date") else None,
            date_precision=seed["date_precision"],
            reported_at=published[0],
            collected_at=collected[0],
            status=seed["status"],
            confidence_score=seed["confidence"],
            needs_review=seed.get("needs_review", False),
            language=seed["language"],
            extraction_model=None,
            primary_platform="DEMO",
            source_count=len(posts),
            is_demo=True,
            search_text=build_search_text(
                item_name=seed["item"],
                description=seed["description"],
                location_text=seed.get("location_text"),
                city=seed.get("city"),
                item_category=seed["category"],
                source_texts=[p["text"] for p in posts],
            ),
            last_activity_at=published[-1],
            created_at=collected[0],
            updated_at=collected[-1],
        )
        session.add(report)
        for n, (post, pub, col) in enumerate(zip(posts, published, collected, strict=True), start=1):
            url = f"https://demo.invalid/posts/{seed['id']}/{n}"
            session.add(
                Source(
                    id=f"{seed['id']}-src-{n}",
                    platform="DEMO",
                    source_key="demo",
                    external_post_id=f"{seed['id']}/{n}",
                    original_url=url,
                    canonical_url=canonical_url(url),
                    original_text=post["text"],
                    text_hash=text_hash(post["text"]),
                    published_at=pub,
                    collected_at=col,
                    processing_state="EXTRACTED",
                    report_id=seed["id"],
                    is_demo=True,
                )
            )
        reports[seed["id"]] = report
        counts = seed.get("suggestions") or {}
        session.flush()
        for kind, count in counts.items():
            for i in range(count):
                session.add(
                    StatusSuggestion(
                        report_id=seed["id"],
                        suggested_status=kind,
                        reason="Demo data",
                        fingerprint_hash=f"demo-seed-{seed['id']}-{kind}-{i}",
                    )
                )

    for lost_id, found_id, text_similarity in data["match_pairs"]:
        a, b = reports[lost_id], reports[found_id]
        pair = score_pair(
            category_a=a.item_category,
            category_b=b.item_category,
            text_similarity=text_similarity,
            coords_a=(a.latitude, a.longitude) if a.latitude is not None else None,
            coords_b=(b.latitude, b.longitude) if b.latitude is not None else None,
            when_a=a.incident_date or a.reported_at,
            when_b=b.incident_date or b.reported_at,
            attributes_a=a.attributes,
            attributes_b=b.attributes,
        )
        session.add(
            ReportMatch(
                lost_report_id=lost_id,
                found_report_id=found_id,
                score=pair.score,
                breakdown=pair.breakdown,
                distance_km=pair.distance_km,
                days_apart=pair.days_apart,
            )
        )
    session.flush()
    return {"places": len(places), "reports": len(reports), "matches": len(data["match_pairs"])}
