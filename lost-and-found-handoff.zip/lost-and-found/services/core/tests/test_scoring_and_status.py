from datetime import UTC, date, datetime, timedelta

import pytest
from lf_core.enums import ReportStatus, StatusActor
from lf_core.models import Report, StatusChange
from lf_core.scoring import colour_relation, score_pair
from lf_core.status import StatusChangeNotAllowed, change_status, mark_stale_reports
from sqlalchemy import select


def pair(**overrides):
    base = dict(
        category_a="WALLET",
        category_b="WALLET",
        text_similarity=0.8,
        coords_a=(24.9, 67.1),
        coords_b=(24.9, 67.1),
        when_a=date(2026, 11, 19),
        when_b=date(2026, 11, 20),
        attributes_a={"colour": "black"},
        attributes_b={"colour": "black"},
    )
    return score_pair(**{**base, **overrides})


def test_weights_follow_the_plan():
    p = pair()
    # 0.3·1 + 0.3·0.8 + 0.2·1 + 0.1·(1 - 1/14) + 0.1·1
    assert p.score == pytest.approx(0.3 + 0.24 + 0.2 + 0.1 * (13 / 14) + 0.1, abs=1e-3)
    assert p.days_apart == 1 and p.distance_km == 0


def test_distance_and_date_decay_to_zero():
    far = pair(coords_b=(24.9 + 0.1, 67.1))  # ~11 km
    assert far.breakdown["distance"] == 0
    late = pair(when_b=date(2026, 12, 20))
    assert late.breakdown["date"] == 0


@pytest.mark.parametrize(
    ("a", "b", "relation"),
    [
        ("black", "kaala", "agree"),
        ("golden", "sona", "agree"),
        ("sky blue", "blue", "agree"),
        ("black", "brown", "conflict"),
        ("کالا", "white", "conflict"),
        (None, "black", "unknown"),
        ("turquoise", "black", "unknown"),
    ],
)
def test_colour_synonyms_across_languages(a, b, relation):
    assert colour_relation({"colour": a}, {"colour": b}) == relation


def test_conflicting_colours_are_penalised():
    same, different = pair(), pair(attributes_b={"colour": "brown"})
    assert different.score < same.score * 0.85 + 1e-9


def test_unknown_location_is_weak_evidence_not_zero():
    assert pair(coords_b=None).breakdown["distance"] == 0.3


def report(status="ACTIVE", **kw) -> Report:
    now = datetime.now(UTC)
    return Report(
        id=kw.pop("id", "r-test"),
        report_type="LOST",
        item_name="x",
        item_category="OTHER",
        status=status,
        reported_at=now,
        collected_at=now,
        last_activity_at=now,
        primary_platform="X",
        search_text="",
        **kw,
    )


def test_visitors_have_no_status_powers_and_system_cannot_resolve():
    r = report()
    with pytest.raises(StatusChangeNotAllowed):
        change_status(None, r, ReportStatus.RESOLVED, reason="x", actor=StatusActor.SYSTEM)


@pytest.mark.db
def test_system_never_overwrites_a_resolved_report(session):
    r = report(status="RESOLVED")
    session.add(r)
    session.flush()
    assert change_status(session, r, ReportStatus.STALE, reason="old", actor=StatusActor.SYSTEM) is False
    assert change_status(session, r, ReportStatus.ACTIVE, reason="reopened", actor=StatusActor.OPERATOR_CLI)
    session.flush()
    log = session.scalars(select(StatusChange).where(StatusChange.report_id == r.id)).all()
    assert [(c.from_status, c.to_status, c.actor) for c in log] == [("RESOLVED", "ACTIVE", "OPERATOR_CLI")]


@pytest.mark.db
def test_old_reports_become_stale_but_demo_reports_do_not(session):
    old = report(id="r-old")
    old.last_activity_at = datetime.now(UTC) - timedelta(days=50)
    session.add(old)
    session.flush()
    assert mark_stale_reports(session, older_than_days=45) == 1
    assert old.status == "STALE"
    assert session.get(Report, "demo-023").status == "STALE"  # demo data keeps its own labels
