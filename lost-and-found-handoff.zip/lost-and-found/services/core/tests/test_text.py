from lf_core.text import (
    build_search_text,
    canonical_url,
    normalize_text,
    redact_text,
    strip_redaction_markers,
    text_hash,
    to_prefix_tsquery,
)


def test_redacts_cnic_phone_landline_and_email():
    text = "CNIC 42101-1234567-1, call 0300-1234567 or +92 321 7654321, office (021) 3456 7890, a@b.com"
    out = redact_text(text)
    assert "1234567" not in out and "7654321" not in out and "a@b.com" not in out
    assert "42•••-•••-•••" in out
    assert out.count("[phone •••]") == 3
    assert "[email •••]" in out


def test_redaction_matches_frontend_examples():
    # Same cases as apps/web/src/lib/redact.test.ts, so both sides mask identically.
    assert redact_text("CNIC 42101-1234567-1 mila") == "CNIC 42•••-•••-••• mila"
    assert redact_text("cnic 4210112345671") == "cnic 42•••-•••-•••"
    assert redact_text("42101 1234567 1") == "42•••-•••-•••"
    assert redact_text("office 021-34567890") == "office [phone •••]"
    assert redact_text("mail me at someone@example.com") == "mail me at [email •••]"


def test_strip_markers_removes_placeholders_only():
    assert strip_redaction_markers("wallet [phone •••] black").split() == ["wallet", "black"]


def test_normalize_text_mirrors_frontend():
    assert normalize_text("Gulshan-e-Iqbal, Block 10-A!") == "gulshan e iqbal block 10 a"
    assert normalize_text("Café") == "cafe"
    assert normalize_text("بٹوا   گم") == "بٹوا گم"


def test_prefix_tsquery_expands_synonyms_and_is_safe():
    assert to_prefix_tsquery("black batwa") == "(black:*) & (wallet:* | batwa:* | purse:*)"
    # Operators and quotes cannot reach the tsquery: they are stripped as non-word characters.
    assert to_prefix_tsquery("wallet' | !(x") == "(wallet:* | batwa:* | purse:*) & (x:*)"
    assert to_prefix_tsquery("&&& ||| ...") is None


def test_search_text_never_contains_hidden_numbers():
    text = build_search_text(
        item_name="Wallet",
        description=None,
        location_text=None,
        city="Karachi",
        item_category="WALLET",
        source_texts=["Lost wallet, call 0300-1234567"],
    )
    assert "phone" not in text.split()
    assert "0300" not in text and "1234567" not in text


def test_canonical_url_drops_tracking_and_unifies_hosts():
    assert canonical_url("https://www.twitter.com/a/status/1/?utm_source=x&s=20") == "https://x.com/a/status/1"
    assert canonical_url("HTTPS://Example.com/path/?b=2&a=1") == "https://example.com/path?a=1&b=2"


def test_text_hash_ignores_case_and_punctuation():
    assert text_hash("Lost: black wallet!!") == text_hash("lost black   WALLET")
