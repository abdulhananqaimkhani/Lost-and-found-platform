"""Report search in SQL. Same semantics as apps/web/src/lib/data/query.ts (the demo-mode engine):

* text: every query word (or a synonym) must appear as a word prefix  → tsvector + prefix tsquery
* area: within the area's radius of its centre                       → ST_DWithin (GiST index)
* bbox: inside the visible map                                        → geog && envelope (GiST index)
* distance sort: nearest first, reports without a location last
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal

from lf_core.models import AnyGeography, Geography, Place, Report
from lf_core.text import to_prefix_tsquery
from sqlalchemy import ColumnElement, Select, and_, false, func, literal, select
from sqlalchemy.orm import Session

from .errors import ApiError

MIN_AREA_FILTER_RADIUS_M = 1500
Sort = Literal["newest", "oldest", "distance", "relevance"]


@dataclass
class ReportQuery:
    q: str | None = None
    type: str | None = None
    categories: list[str] = field(default_factory=list)
    statuses: list[str] = field(default_factory=list)
    area: str | None = None
    city: str | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None
    bbox: tuple[float, float, float, float] | None = None
    near: tuple[float, float] | None = None  # (lat, lng)
    radius_km: float | None = None
    has_location: bool | None = None
    sort: Sort = "newest"
    page: int = 1
    page_size: int = 20


def parse_bbox(raw: str | None) -> tuple[float, float, float, float] | None:
    if not raw:
        return None
    try:
        w, s, e, n = (float(v) for v in raw.split(","))
    except ValueError as exc:
        raise ApiError(422, "bbox must be four numbers: west,south,east,north.") from exc
    if not (-180 <= w <= 180 and -180 <= e <= 180 and -90 <= s <= 90 and -90 <= n <= 90) or s > n or w > e:
        raise ApiError(422, "bbox is outside valid coordinates or its corners are swapped.")
    return w, s, e, n


def point(lat: float, lng: float) -> ColumnElement:
    return func.ST_SetSRID(func.ST_MakePoint(lng, lat), 4326).cast(Geography())


def area_info(session: Session, key: str) -> tuple[float, float, int] | None:
    place = session.get(Place, key)
    if place is None or not place.is_area_filter:
        return None
    return place.latitude, place.longitude, max(place.radius_m or 0, MIN_AREA_FILTER_RADIUS_M)


def reference_point(session: Session, query: ReportQuery) -> tuple[float, float] | None:
    if query.near:
        return query.near
    if query.area:
        info = area_info(session, query.area)
        return (info[0], info[1]) if info else None
    return None


def conditions(session: Session, query: ReportQuery, *, show_demo: bool) -> list[ColumnElement]:
    conds: list[ColumnElement] = []
    if not show_demo:
        conds.append(Report.is_demo.is_(False))
    if query.type:
        conds.append(Report.report_type == query.type)
    if query.categories:
        conds.append(Report.item_category.in_(query.categories))
    if query.statuses:
        conds.append(Report.status.in_(query.statuses))
    if query.city:
        conds.append(func.lower(Report.city) == query.city.strip().lower())
    if query.date_from:
        conds.append(Report.reported_at >= query.date_from)
    if query.date_to:
        conds.append(Report.reported_at <= query.date_to)
    if query.has_location is True:
        conds.append(Report.latitude.is_not(None))
    elif query.has_location is False:
        conds.append(Report.latitude.is_(None))
    if query.area:
        info = area_info(session, query.area)
        # An unknown area matches nothing, rather than silently matching everything.
        conds.append(false() if info is None else func.ST_DWithin(Report.geog, point(info[0], info[1]), info[2], False))
    if query.bbox:
        w, s, e, n = query.bbox
        envelope = func.ST_MakeEnvelope(w, s, e, n, 4326).cast(AnyGeography())
        conds.append(
            and_(Report.geog.op("&&")(envelope), Report.latitude.between(s, n), Report.longitude.between(w, e))
        )
    if query.near and query.radius_km:
        conds.append(func.ST_DWithin(Report.geog, point(*query.near), query.radius_km * 1000, False))
    tsquery = to_prefix_tsquery(query.q or "")
    if tsquery:
        conds.append(Report.search_tsv.op("@@")(func.to_tsquery("simple", tsquery)))
    return conds


def build_list(session: Session, query: ReportQuery, *, show_demo: bool) -> tuple[Select, Select, bool]:
    conds = conditions(session, query, show_demo=show_demo)
    ref = reference_point(session, query)
    distance = (
        (func.ST_Distance(Report.geog, point(*ref), False) / 1000.0).label("distance_km")
        if ref
        else literal(None).label("distance_km")
    )
    stmt = select(Report, distance).where(*conds)
    count = select(func.count()).select_from(Report).where(*conds)

    tsquery = to_prefix_tsquery(query.q or "")
    if query.sort == "oldest":
        stmt = stmt.order_by(Report.reported_at.asc(), Report.id)
    elif query.sort == "distance" and ref:
        stmt = stmt.order_by(distance.asc().nulls_last(), Report.reported_at.desc(), Report.id)
    elif query.sort == "relevance" and tsquery:
        rank = func.ts_rank_cd(Report.search_tsv, func.to_tsquery("simple", tsquery))
        stmt = stmt.order_by(rank.desc(), Report.reported_at.desc(), Report.id)
    else:
        stmt = stmt.order_by(Report.reported_at.desc(), Report.id)
    return stmt, count, ref is not None


def list_reports(
    session: Session, query: ReportQuery, *, show_demo: bool
) -> tuple[list[tuple[Report, float | None]], int, bool]:
    stmt, count, has_ref = build_list(session, query, show_demo=show_demo)
    total = session.scalar(count) or 0
    offset = (query.page - 1) * query.page_size
    rows = session.execute(stmt.offset(offset).limit(query.page_size)).all()
    return [(row[0], row[1]) for row in rows], total, has_ref
