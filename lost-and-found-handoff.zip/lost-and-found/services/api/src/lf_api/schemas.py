"""Response and request models. Field names match apps/web/src/lib/types.ts exactly."""

from __future__ import annotations

from datetime import date, datetime
from typing import Literal

from lf_core.enums import (
    DatePrecision,
    ItemCategory,
    Language,
    LocationPrecision,
    ReportStatus,
    ReportType,
    SourcePlatform,
    SuggestionType,
)
from pydantic import BaseModel, ConfigDict, Field


class ReportSummary(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    report_type: ReportType
    item_name: str
    item_category: ItemCategory
    description: str | None
    location_text: str | None
    city: str | None
    latitude: float | None
    longitude: float | None
    location_precision: LocationPrecision
    location_radius_m: int | None
    incident_date: date | None
    date_precision: DatePrecision
    reported_at: datetime
    collected_at: datetime
    status: ReportStatus
    confidence_score: float
    needs_review: bool
    language: Language
    primary_platform: SourcePlatform
    source_count: int
    is_demo: bool
    distance_km: float | None = None


class SourceRef(BaseModel):
    id: str
    platform: SourcePlatform
    original_url: str
    excerpt: str = Field(description="Original text with CNIC numbers, phone numbers and e-mails masked")
    published_at: datetime
    collected_at: datetime
    publisher: str | None = None
    publisher_byline: str | None = None
    license_url: str | None = None


class Attributes(BaseModel):
    colour: str | None = None
    brand: str | None = None


class SuggestionCounts(BaseModel):
    RESOLVED: int = 0
    INACCURATE: int = 0


class ReportDetail(ReportSummary):
    attributes: Attributes
    sources: list[SourceRef]
    suggestion_counts: SuggestionCounts
    created_at: datetime
    updated_at: datetime


class ReportPage(BaseModel):
    items: list[ReportSummary]
    total: int
    page: int
    page_size: int


class MatchBreakdown(BaseModel):
    category: float
    text: float
    distance: float
    date: float
    attributes: float


class MatchSummary(BaseModel):
    report: ReportSummary
    score: float
    breakdown: MatchBreakdown
    distance_km: float | None
    days_apart: int | None


class MapReportProperties(BaseModel):
    id: str
    report_type: ReportType
    item_name: str
    item_category: ItemCategory
    description: str | None
    location_text: str | None
    location_precision: LocationPrecision
    location_radius_m: int | None
    status: ReportStatus
    reported_at: datetime
    primary_platform: SourcePlatform


class PointGeometry(BaseModel):
    type: Literal["Point"] = "Point"
    coordinates: tuple[float, float]


class MapFeature(BaseModel):
    type: Literal["Feature"] = "Feature"
    geometry: PointGeometry
    properties: MapReportProperties


class MapFeatureCollection(BaseModel):
    type: Literal["FeatureCollection"] = "FeatureCollection"
    features: list[MapFeature]


class CategoryCount(BaseModel):
    category: ItemCategory
    count: int


class Area(BaseModel):
    key: str
    label: str
    latitude: float
    longitude: float
    radius_m: int


class Stats(BaseModel):
    total: int
    lost: int
    found: int
    mapped: int
    by_platform: dict[SourcePlatform, int]
    last_collected_at: datetime | None


class SuggestionRequest(BaseModel):
    suggested_status: SuggestionType
    reason: str = Field(default="", max_length=500)
    # Honeypot: hidden in the form, so only bots fill it in.
    website: str | None = Field(default=None, max_length=200)


class SuggestionResult(BaseModel):
    accepted: bool
    message: str


class IngestRequest(BaseModel):
    posts: list[dict] = Field(min_length=1, max_length=100)


class IngestResponse(BaseModel):
    new: int
    duplicate: int
    attached_copy: int
    invalid: int
