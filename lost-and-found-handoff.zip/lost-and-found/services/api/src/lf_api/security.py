"""Client identification for rate limiting and anti-spam, without storing raw IP addresses."""

from __future__ import annotations

import hashlib
import hmac
import secrets
import threading
import time
from collections import deque
from datetime import UTC, datetime

from fastapi import Request


def client_ip(request: Request, trusted_proxies: list[str]) -> str:
    """The visitor's IP. X-Forwarded-For is only believed when the direct peer is our own proxy
    (Next.js on the same machine); otherwise anyone could fake it to dodge rate limits."""
    peer = request.client.host if request.client else "unknown"
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded and peer in trusted_proxies:
        # Our proxy appends the address it saw, so the right-most entry is the trustworthy one.
        return forwarded.split(",")[-1].strip() or peer
    return peer


class Fingerprinter:
    """HMAC of (day, IP, user agent). The day is part of the input, so fingerprints can't be linked
    across days, and the secret means they can't be reversed into IP addresses."""

    def __init__(self, secret: bytes | None):
        self.ephemeral = secret is None
        self._secret = secret or secrets.token_bytes(32)

    def fingerprint(self, ip: str, user_agent: str, now: datetime | None = None) -> str:
        day = (now or datetime.now(UTC)).strftime("%Y-%m-%d")
        message = f"{day}|{ip}|{user_agent[:300]}".encode()
        return hmac.new(self._secret, message, hashlib.sha256).hexdigest()


class SlidingWindowLimiter:
    """In-memory per-client limiter for read requests. Kept in RAM only; nothing is persisted."""

    def __init__(self, limit: int, window_seconds: float, clock=time.monotonic):
        self.limit, self.window, self._clock = limit, window_seconds, clock
        self._hits: dict[str, deque[float]] = {}
        self._lock = threading.Lock()

    def check(self, key: str) -> tuple[bool, int]:
        """Returns (allowed, seconds until a slot frees up)."""
        now = self._clock()
        with self._lock:
            hits = self._hits.setdefault(key, deque())
            while hits and hits[0] <= now - self.window:
                hits.popleft()
            if len(hits) >= self.limit:
                return False, max(1, int(hits[0] + self.window - now) + 1)
            hits.append(now)
            if len(self._hits) > 50_000:  # Bound memory under a flood of distinct clients.
                self._hits = {k: v for k, v in self._hits.items() if v and v[-1] > now - self.window}
            return True, 0
