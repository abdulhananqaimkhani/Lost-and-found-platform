"""Internal service endpoints. They need `Authorization: Bearer <SERVICE_TOKEN>`.
When SERVICE_TOKEN is not set they don't exist at all (404), so nothing is open by accident."""

from __future__ import annotations

import hmac
from typing import Annotated

from fastapi import APIRouter, Depends, Request
from lf_core.contracts import NormalizedPost
from lf_core.ingest import IngestStatus, ingest_post
from pydantic import ValidationError
from sqlalchemy.orm import Session

from .. import schemas
from ..deps import get_session, get_state
from ..errors import ApiError

router = APIRouter(prefix="/internal", include_in_schema=False)


def require_service_token(request: Request) -> None:
    token = get_state(request).settings.service_token
    if token is None:
        raise ApiError(404, "There's nothing at this address.")
    header = request.headers.get("authorization", "")
    scheme, _, supplied = header.partition(" ")
    if scheme.lower() != "bearer" or not hmac.compare_digest(supplied.encode(), token.get_secret_value().encode()):
        raise ApiError(401, "A valid service token is required.")


@router.post("/ingest", response_model=schemas.IngestResponse, dependencies=[Depends(require_service_token)])
def ingest(body: schemas.IngestRequest, session: Annotated[Session, Depends(get_session)]) -> schemas.IngestResponse:
    counts = {"new": 0, "duplicate": 0, "attached_copy": 0, "invalid": 0}
    for raw in body.posts:
        try:
            post = NormalizedPost.model_validate(raw)
        except ValidationError:
            counts["invalid"] += 1
            continue
        outcome = ingest_post(session, post, source_key=f"internal:{post.source_platform.value.lower()}")
        key = {
            IngestStatus.NEW: "new",
            IngestStatus.DUPLICATE: "duplicate",
            IngestStatus.ATTACHED_COPY: "attached_copy",
        }
        counts[key[outcome.status]] += 1
    session.commit()
    return schemas.IngestResponse(**counts)
