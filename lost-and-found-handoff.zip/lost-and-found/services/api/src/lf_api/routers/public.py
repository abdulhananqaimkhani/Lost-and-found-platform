"""Public endpoints: read-only report data plus anonymous status suggestions.

Nothing here can change a report's status. A suggestion is stored for later verification
(PROJECT_PLAN.md §10). The API never calls Ollama or any external platform.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Query, Request, Response
from lf_core.enums import ItemCategory, JobStatus, ReportStatus, ReportType, ReviewStatus
from lf_core.models import (
    Place,
    ProcessingJob,
    Report,
    ReportMatch,
    Source,
    StatusSuggestion,
    WorkerHeartbeat,
)
from lf_core.text import redact_text
from sqlalchemy import func, or_, select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from .. import schemas
from ..deps import get_session, get_state
from ..errors import ApiError
from ..queries import MIN_AREA_FILTER_RADIUS_M, ReportQuery, list_reports, parse_bbox
from ..security import client_ip

router = APIRouter(prefix="/api")

REPORT_ID = re.compile(r"^[A-Za-z0-9_-]{1,40}$")
MAP_FEATURE_CAP = 2000


def _csv(raw: str | None, allowed: type, name: str) -> list[str]:
    if not raw:
        return []
    values = [v.strip().upper() for v in raw.split(",") if v.strip()]
    valid = {m.value for m in allowed}
    bad = [v for v in values if v not in valid]
    if bad:
        raise ApiError(422, f"Unknown {name}: {', '.join(bad[:3])}.", details={"allowed": sorted(valid)})
    return values


def report_query(
    q: Annotated[str | None, Query(max_length=120)] = None,
    type: ReportType | None = None,  # noqa: A002 - name is part of the public API
    category: str | None = None,
    status: str | None = None,
    area: Annotated[str | None, Query(max_length=80)] = None,
    city: Annotated[str | None, Query(max_length=80)] = None,
    date_from: datetime | None = None,
    date_to: datetime | None = None,
    bbox: str | None = None,
    near_lat: Annotated[float | None, Query(ge=-90, le=90)] = None,
    near_lng: Annotated[float | None, Query(ge=-180, le=180)] = None,
    radius_km: Annotated[float | None, Query(gt=0, le=100)] = None,
    has_location: bool | None = None,
    sort: Literal["newest", "oldest", "distance", "relevance"] = "newest",
    page: Annotated[int, Query(ge=1, le=10_000)] = 1,
    page_size: Annotated[int, Query(ge=1, le=100)] = 20,
) -> ReportQuery:
    if (near_lat is None) != (near_lng is None):
        raise ApiError(422, "Send both near_lat and near_lng, or neither.")
    return ReportQuery(
        q=q,
        type=type.value if type else None,
        categories=_csv(category, ItemCategory, "category"),
        statuses=_csv(status, ReportStatus, "status"),
        area=area,
        city=city,
        date_from=date_from,
        date_to=date_to,
        bbox=parse_bbox(bbox),
        near=(near_lat, near_lng) if near_lat is not None else None,
        radius_km=radius_km,
        has_location=has_location,
        sort=sort,
        page=page,
        page_size=page_size,
    )


SessionDep = Annotated[Session, Depends(get_session)]
QueryDep = Annotated[ReportQuery, Depends(report_query)]


def summary(report: Report, distance_km: float | None = None) -> schemas.ReportSummary:
    data = schemas.ReportSummary.model_validate(report)
    data.distance_km = round(distance_km, 4) if distance_km is not None else None
    return data


@router.get("/reports", response_model=schemas.ReportPage)
def get_reports(request: Request, session: SessionDep, query: QueryDep) -> schemas.ReportPage:
    state = get_state(request)
    rows, total, _ = list_reports(session, query, show_demo=state.settings.show_demo_data)
    return schemas.ReportPage(
        items=[summary(r, d) for r, d in rows], total=total, page=query.page, page_size=query.page_size
    )


@router.get("/map/reports", response_model=schemas.MapFeatureCollection)
def get_map_reports(request: Request, session: SessionDep, query: QueryDep) -> schemas.MapFeatureCollection:
    state = get_state(request)
    query.has_location, query.page, query.page_size, query.sort = True, 1, MAP_FEATURE_CAP, "newest"
    rows, _, _ = list_reports(session, query, show_demo=state.settings.show_demo_data)
    return schemas.MapFeatureCollection(
        features=[
            schemas.MapFeature(
                geometry=schemas.PointGeometry(coordinates=(r.longitude, r.latitude)),
                properties=schemas.MapReportProperties.model_validate(r, from_attributes=True),
            )
            for r, _ in rows
        ]
    )


def _load_report(session: Session, report_id: str, show_demo: bool) -> Report:
    if not REPORT_ID.match(report_id):
        raise ApiError(404, "This report doesn't exist.")
    report = session.get(Report, report_id)
    if report is None or (report.is_demo and not show_demo):
        raise ApiError(404, "This report doesn't exist.")
    return report


def _source_ref(source: Source) -> schemas.SourceRef:
    article = source.platform == "RSS"
    metadata = (source.raw_meta or {}) if article else {}
    excerpt = redact_text(source.original_text)
    return schemas.SourceRef(
        id=source.id,
        platform=source.platform,
        original_url=source.original_url,
        excerpt=excerpt[:600] if article else excerpt,
        published_at=source.published_at,
        collected_at=source.collected_at,
        publisher=metadata.get("publisher"),
        publisher_byline=metadata.get("publisher_byline"),
        license_url=metadata.get("license_url"),
    )


@router.get("/reports/{report_id}", response_model=schemas.ReportDetail)
def get_report(report_id: str, request: Request, session: SessionDep) -> schemas.ReportDetail:
    report = _load_report(session, report_id, get_state(request).settings.show_demo_data)
    counts = dict(
        session.execute(
            select(StatusSuggestion.suggested_status, func.count())
            .where(StatusSuggestion.report_id == report.id, StatusSuggestion.review_status != ReviewStatus.REJECTED)
            .group_by(StatusSuggestion.suggested_status)
        ).all()
    )
    base = summary(report).model_dump()
    return schemas.ReportDetail(
        **base,
        attributes=schemas.Attributes(
            **{k: v for k, v in (report.attributes or {}).items() if k in {"colour", "brand"}}
        ),
        sources=[_source_ref(source) for source in report.sources],
        suggestion_counts=schemas.SuggestionCounts(**counts),
        created_at=report.created_at,
        updated_at=report.updated_at,
    )


@router.get("/reports/{report_id}/matches", response_model=list[schemas.MatchSummary])
def get_matches(report_id: str, request: Request, session: SessionDep) -> list[schemas.MatchSummary]:
    show_demo = get_state(request).settings.show_demo_data
    report = _load_report(session, report_id, show_demo)
    matches = session.scalars(
        select(ReportMatch)
        .where(or_(ReportMatch.lost_report_id == report.id, ReportMatch.found_report_id == report.id))
        .order_by(ReportMatch.score.desc())
    ).all()
    results = []
    for m in matches:
        other = session.get(Report, m.found_report_id if m.lost_report_id == report.id else m.lost_report_id)
        if other is None or (other.is_demo and not show_demo):
            continue
        results.append(
            schemas.MatchSummary(
                report=summary(other),
                score=m.score,
                breakdown=schemas.MatchBreakdown(**m.breakdown),
                distance_km=m.distance_km,
                days_apart=m.days_apart,
            )
        )
    return results


@router.post("/reports/{report_id}/resolution-suggestions", response_model=schemas.SuggestionResult, status_code=202)
def post_suggestion(
    report_id: str, body: schemas.SuggestionRequest, request: Request, response: Response, session: SessionDep
) -> schemas.SuggestionResult:
    state = get_state(request)
    report = _load_report(session, report_id, state.settings.show_demo_data)
    if body.website:
        # Honeypot filled in: answer like a success so bots learn nothing, but store nothing.
        return schemas.SuggestionResult(accepted=True, message="Suggestion recorded.")

    ip = client_ip(request, state.settings.trusted_proxies)
    fingerprint = state.fingerprinter.fingerprint(ip, request.headers.get("user-agent", ""))
    hour_ago = datetime.now(UTC) - timedelta(hours=1)
    recent = session.scalar(
        select(func.count())
        .select_from(StatusSuggestion)
        .where(StatusSuggestion.fingerprint_hash == fingerprint, StatusSuggestion.created_at >= hour_ago)
    )
    if (recent or 0) >= state.settings.suggestion_rate_per_hour:
        raise ApiError(429, "You've sent several suggestions in the last hour. Try again later.")

    inserted = session.execute(
        pg_insert(StatusSuggestion)
        .values(
            report_id=report.id,
            suggested_status=body.suggested_status.value,
            reason=body.reason.strip()[:500],
            fingerprint_hash=fingerprint,
        )
        .on_conflict_do_nothing(constraint="uq_suggestion_once")
        .returning(StatusSuggestion.id)
    ).first()
    session.commit()
    if inserted is None:
        response.status_code = 200
        return schemas.SuggestionResult(accepted=False, message="You've already sent this suggestion for this report.")
    return schemas.SuggestionResult(
        accepted=True, message="Suggestion recorded. The listing's status stays the same until it's verified."
    )


@router.get("/categories", response_model=list[schemas.CategoryCount])
def get_categories(request: Request, session: SessionDep) -> list[schemas.CategoryCount]:
    stmt = select(Report.item_category, func.count()).group_by(Report.item_category)
    if not get_state(request).settings.show_demo_data:
        stmt = stmt.where(Report.is_demo.is_(False))
    counts = dict(session.execute(stmt).all())
    return [schemas.CategoryCount(category=c, count=counts.get(c.value, 0)) for c in ItemCategory]


@router.get("/areas", response_model=list[schemas.Area])
def get_areas(session: SessionDep) -> list[schemas.Area]:
    places = session.scalars(select(Place).where(Place.is_area_filter.is_(True)).order_by(Place.label)).all()
    return [
        schemas.Area(
            key=p.key,
            label=p.label,
            latitude=p.latitude,
            longitude=p.longitude,
            radius_m=max(p.radius_m or 0, MIN_AREA_FILTER_RADIUS_M),
        )
        for p in places
    ]


@router.get("/stats", response_model=schemas.Stats)
def get_stats(request: Request, session: SessionDep) -> schemas.Stats:
    show_demo = get_state(request).settings.show_demo_data
    demo_filter = [] if show_demo else [Report.is_demo.is_(False)]
    by_type = dict(
        session.execute(select(Report.report_type, func.count()).where(*demo_filter).group_by(Report.report_type)).all()
    )
    mapped = session.scalar(select(func.count()).select_from(Report).where(Report.latitude.is_not(None), *demo_filter))
    by_platform = dict(
        session.execute(
            select(Report.primary_platform, func.count()).where(*demo_filter).group_by(Report.primary_platform)
        ).all()
    )
    source_filter = [] if show_demo else [Source.is_demo.is_(False)]
    last = session.scalar(select(func.max(Source.collected_at)).where(*source_filter))
    return schemas.Stats(
        total=sum(by_type.values()),
        lost=by_type.get("LOST", 0),
        found=by_type.get("FOUND", 0),
        mapped=mapped or 0,
        by_platform=by_platform,
        last_collected_at=last,
    )


@router.get("/health")
def get_health(session: SessionDep, response: Response) -> dict:
    """Operational status for the person running the system. Never includes configuration or secrets."""
    try:
        worker = session.scalars(select(WorkerHeartbeat).order_by(WorkerHeartbeat.last_seen.desc()).limit(1)).first()
        queue = dict(
            session.execute(
                select(ProcessingJob.status, func.count())
                .where(ProcessingJob.status.in_([JobStatus.PENDING, JobStatus.RUNNING, JobStatus.FAILED]))
                .group_by(ProcessingJob.status)
            ).all()
        )
    except SQLAlchemyError:
        response.status_code = 503
        return {"status": "degraded", "database": "unreachable", "worker": None, "queue": None}
    worker_info = None
    if worker:
        age = (datetime.now(UTC) - worker.last_seen).total_seconds()
        worker_info = {
            "last_seen": worker.last_seen.isoformat(),
            "alive": age < 180,
            "ai_available": bool(worker.info.get("ai_available")),
        }
    return {
        "status": "ok",
        "database": "ok",
        "worker": worker_info,
        "queue": {s.value: queue.get(s.value, 0) for s in (JobStatus.PENDING, JobStatus.RUNNING, JobStatus.FAILED)},
    }
