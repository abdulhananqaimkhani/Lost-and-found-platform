from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass

from fastapi import Request
from lf_core.settings import Settings
from sqlalchemy.orm import Session, sessionmaker

from .security import Fingerprinter, SlidingWindowLimiter


@dataclass
class AppState:
    settings: Settings
    sessions: sessionmaker[Session]
    fingerprinter: Fingerprinter
    read_limiter: SlidingWindowLimiter


def get_state(request: Request) -> AppState:
    return request.app.state.lf


def get_session(request: Request) -> Iterator[Session]:
    session = get_state(request).sessions()
    try:
        yield session
    finally:
        session.close()
