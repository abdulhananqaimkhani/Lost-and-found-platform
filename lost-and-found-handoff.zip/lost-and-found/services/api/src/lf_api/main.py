"""FastAPI application. Run: uv run uvicorn lf_api.main:app --host 127.0.0.1 --port 8000"""

from __future__ import annotations

import logging
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from lf_core.db import get_engine, session_factory
from lf_core.settings import Settings, get_settings
from sqlalchemy import Engine
from sqlalchemy.orm import Session, sessionmaker

from .deps import AppState
from .errors import error_body, install_error_handlers
from .routers import internal, public
from .security import Fingerprinter, SlidingWindowLimiter, client_ip

log = logging.getLogger("lf_api")


def create_app(
    settings: Settings | None = None, engine: Engine | None = None, sessions: sessionmaker[Session] | None = None
) -> FastAPI:
    settings = settings or get_settings()
    app = FastAPI(
        title="Lost & Found Finder API",
        version="0.1.0",
        description="Read-only access to lost and found reports collected from lawful public sources.",
    )
    secret = settings.fingerprint_secret.get_secret_value().encode() if settings.fingerprint_secret else None
    app.state.lf = AppState(
        settings=settings,
        sessions=sessions or session_factory(engine or get_engine()),
        fingerprinter=Fingerprinter(secret),
        read_limiter=SlidingWindowLimiter(settings.read_rate_per_minute, 60),
    )
    if app.state.lf.fingerprinter.ephemeral:
        log.warning("FINGERPRINT_SECRET is not set; using a random one until restart.")

    install_error_handlers(app)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type", "Accept"],
        allow_credentials=False,
    )

    @app.middleware("http")
    async def rate_limit_and_headers(request: Request, call_next):
        started = time.perf_counter()
        request_id = uuid.uuid4().hex[:12]
        state: AppState = request.app.state.lf
        if request.url.path.startswith("/api/") and request.method == "GET":
            allowed, retry_after = state.read_limiter.check(client_ip(request, state.settings.trusted_proxies))
            if not allowed:
                return JSONResponse(
                    error_body("rate_limited", "Too many requests. Wait a moment and try again."),
                    status_code=429,
                    headers={"Retry-After": str(retry_after)},
                )
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-Request-Id"] = request_id
        log.info(
            "%s %s %s %.1fms id=%s",
            request.method,
            request.url.path,
            response.status_code,
            (time.perf_counter() - started) * 1000,
            request_id,
        )
        return response

    app.include_router(public.router)
    app.include_router(internal.router)
    return app


def __getattr__(name: str):
    # `uvicorn lf_api.main:app` builds the app lazily, so importing this module (e.g. in tests)
    # doesn't require a configured database.
    if name == "app":
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
        return create_app()
    raise AttributeError(name)
