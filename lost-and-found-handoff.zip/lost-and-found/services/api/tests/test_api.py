import re

import pytest
from lf_api.deps import get_session
from lf_api.security import client_ip
from lf_core.models import Report, Source, StatusChange, StatusSuggestion
from sqlalchemy import func, select
from sqlalchemy.exc import OperationalError
from starlette.requests import Request

pytestmark = pytest.mark.db


def test_report_list_shape_matches_frontend_contract(client):
    body = client.get("/api/reports?page_size=1").json()
    assert set(body) == {"items", "total", "page", "page_size"}
    expected = {
        "id",
        "report_type",
        "item_name",
        "item_category",
        "description",
        "location_text",
        "city",
        "latitude",
        "longitude",
        "location_precision",
        "location_radius_m",
        "incident_date",
        "date_precision",
        "reported_at",
        "collected_at",
        "status",
        "confidence_score",
        "needs_review",
        "language",
        "primary_platform",
        "source_count",
        "is_demo",
        "distance_km",
    }
    assert set(body["items"][0]) == expected


def test_detail_redacts_numbers_and_counts_suggestions(client):
    body = client.get("/api/reports/demo-001").json()
    excerpts = " ".join(s["excerpt"] for s in body["sources"])
    assert "[phone •••]" in excerpts and "42•••-•••-•••" in excerpts
    assert not re.search(r"\d{7}", excerpts), "no long digit runs (phone/CNIC) may survive redaction"
    assert body["sources"][0]["original_url"].startswith("https://demo.invalid/")
    assert body["attributes"]["colour"] == "black"
    assert set(body["suggestion_counts"]) == {"RESOLVED", "INACCURATE"}


def test_article_attribution_and_excerpt_are_served_together(session, client):
    source = session.get(Source, "demo-001-src-1")
    source.platform = "RSS"
    source.original_url = "https://news.test/wallet"
    source.original_text = "x" * 591 + " 03001234567 " + "y" * 900
    source.raw_meta = {
        "publisher": "Test Newspaper",
        "publisher_byline": "A Reporter",
        "license_url": "https://news.test/license",
    }
    session.commit()

    sources = client.get("/api/reports/demo-001").json()["sources"]
    article = next(item for item in sources if item["platform"] == "RSS")
    assert article["publisher"] == "Test Newspaper" and article["publisher_byline"] == "A Reporter"
    assert article["license_url"] == "https://news.test/license"
    assert len(article["excerpt"]) == 600 and "0300" not in article["excerpt"]


def test_unknown_and_malformed_ids_are_404_in_the_standard_error_shape(client):
    for path in ("/api/reports/nope", "/api/reports/a.b", "/api/reports/" + "x" * 60):
        response = client.get(path)
        assert response.status_code == 404, path
        assert response.json()["error"]["code"] == "not_found"


@pytest.mark.parametrize(
    ("path", "word"),
    [
        ("/api/reports?category=SPACESHIP", "category"),
        ("/api/reports?bbox=1,2,3", "bbox"),
        ("/api/reports?bbox=67.1,24.8,67.0,24.9", "bbox"),
        ("/api/reports?page_size=1000", "page_size"),
        ("/api/reports?near_lat=24.8", "near_lng"),
        ("/api/reports?sort=random", "sort"),
    ],
)
def test_invalid_filters_are_rejected_with_clear_messages(client, path, word):
    response = client.get(path)
    assert response.status_code == 422
    assert word in response.json()["error"]["message"]


def test_map_endpoint_returns_geojson_for_mapped_reports_only(client):
    body = client.get("/api/map/reports").json()
    assert body["type"] == "FeatureCollection"
    assert len(body["features"]) == 28  # 30 demo reports; 2 have no mappable location
    lng, lat = body["features"][0]["geometry"]["coordinates"]
    assert 66.5 < lng < 67.6 and 24.6 < lat < 25.3
    assert all(f["properties"]["location_precision"] in {"POI", "STREET", "NEIGHBOURHOOD"} for f in body["features"])


def test_map_endpoint_applies_bbox_and_filters(client):
    everything = client.get("/api/map/reports?bbox=66.9,24.7,67.3,25.1").json()["features"]
    lost = client.get("/api/map/reports?bbox=66.9,24.7,67.3,25.1&type=LOST").json()["features"]
    assert 0 < len(lost) < len(everything)
    assert all(f["properties"]["report_type"] == "LOST" for f in lost)


def test_matches_have_a_score_breakdown(client):
    matches = client.get("/api/reports/demo-001/matches").json()
    assert [m["report"]["id"] for m in matches] == ["demo-002"]
    m = matches[0]
    assert 0 < m["score"] <= 1
    assert set(m["breakdown"]) == {"category", "text", "distance", "date", "attributes"}


def test_categories_areas_stats(client):
    categories = client.get("/api/categories").json()
    assert len(categories) == 11 and sum(c["count"] for c in categories) == 30
    areas = client.get("/api/areas").json()
    assert any(a["key"] == "gulshan-e-iqbal" for a in areas)
    assert all(a["radius_m"] >= 1500 for a in areas)
    stats = client.get("/api/stats").json()
    assert stats["total"] == 30 and stats["lost"] + stats["found"] == 30 and stats["mapped"] == 28
    assert stats["by_platform"] == {"DEMO": 30}


def test_areas_match_the_frontend_demo_areas(client):
    import json
    from pathlib import Path

    dataset = json.loads(
        (Path(__file__).parents[3] / "database" / "schema" / "demo_dataset.json").read_text(encoding="utf-8")
    )
    expected = sorted(dataset["places"], key=lambda p: p["label"])
    got = client.get("/api/areas").json()
    assert [a["key"] for a in got] == [p["key"] for p in expected]


def test_demo_data_can_be_hidden(make_client):
    c = make_client(show_demo_data=False)
    assert c.get("/api/reports").json()["total"] == 0
    assert c.get("/api/reports/demo-001").status_code == 404
    assert c.get("/api/stats").json()["total"] == 0


def test_health_reports_status_without_secrets(client):
    body = client.get("/api/health").json()
    assert body["database"] == "ok"
    text = str(body).lower()
    assert "password" not in text and "token" not in text and "secret" not in text


def test_health_returns_service_unavailable_when_database_queries_fail(client):
    class UnreachableSession:
        def scalars(self, statement):
            raise OperationalError("SELECT", {}, OSError("connection refused"))

    client.app.dependency_overrides[get_session] = UnreachableSession
    response = client.get("/api/health")
    assert response.status_code == 503
    assert response.json() == {"status": "degraded", "database": "unreachable", "worker": None, "queue": None}


class TestSuggestions:
    url = "/api/reports/demo-003/resolution-suggestions"

    def test_suggestion_is_stored_but_never_changes_status(self, client, session):
        before = session.get(Report, "demo-003").status
        response = client.post(self.url, json={"suggested_status": "RESOLVED", "reason": "Owner got it back"})
        assert response.status_code == 202 and response.json()["accepted"] is True
        session.expire_all()
        assert session.get(Report, "demo-003").status == before
        assert session.scalar(select(func.count()).select_from(StatusChange)) == 0
        stored = session.scalars(select(StatusSuggestion).where(StatusSuggestion.reason == "Owner got it back")).one()
        assert re.fullmatch(r"[0-9a-f]{64}", stored.fingerprint_hash)

    def test_same_visitor_cannot_repeat_a_suggestion(self, client):
        first = client.post(self.url, json={"suggested_status": "RESOLVED"})
        second = client.post(self.url, json={"suggested_status": "RESOLVED"})
        assert first.json()["accepted"] is True
        assert second.status_code == 200 and second.json()["accepted"] is False
        # A different kind of suggestion is still allowed.
        assert client.post(self.url, json={"suggested_status": "INACCURATE"}).json()["accepted"] is True

    def test_hourly_limit_per_visitor(self, client):
        ids = ["demo-004", "demo-005", "demo-006", "demo-007", "demo-008", "demo-009"]
        codes = [
            client.post(f"/api/reports/{i}/resolution-suggestions", json={"suggested_status": "RESOLVED"}).status_code
            for i in ids
        ]
        assert codes == [202] * 5 + [429]

    def test_honeypot_is_silently_dropped(self, client, session):
        response = client.post(self.url, json={"suggested_status": "RESOLVED", "website": "http://spam"})
        assert response.json()["accepted"] is True
        count = session.scalar(
            select(func.count())
            .select_from(StatusSuggestion)
            .where(StatusSuggestion.report_id == "demo-003", ~StatusSuggestion.fingerprint_hash.startswith("demo-seed"))
        )
        assert count == 0

    def test_reason_length_and_type_are_validated(self, client):
        assert client.post(self.url, json={"suggested_status": "RESOLVED", "reason": "x" * 501}).status_code == 422
        assert client.post(self.url, json={"suggested_status": "DELETE"}).status_code == 422
        missing = client.post("/api/reports/nope/resolution-suggestions", json={"suggested_status": "RESOLVED"})
        assert missing.status_code == 404


def test_read_rate_limit(make_client):
    c = make_client(read_rate_per_minute=3)
    codes = [c.get("/api/categories").status_code for _ in range(4)]
    assert codes == [200, 200, 200, 429]


class TestInternal:
    post = {
        "source_platform": "RSS",
        "source_id": "feed-1",
        "source_url": "https://news.example.org/a?utm_source=x",
        "text": "Lost black wallet near Saddar",
        "published_at": "2026-11-20T10:00:00Z",
    }

    def test_disabled_without_token(self, client):
        assert client.post("/internal/ingest", json={"posts": [self.post]}).status_code == 404

    def test_requires_the_right_token_and_dedupes(self, make_client):
        from pydantic import SecretStr

        c = make_client(service_token=SecretStr("s3cret-token"))
        assert c.post("/internal/ingest", json={"posts": [self.post]}).status_code == 401
        wrong = c.post("/internal/ingest", json={"posts": [self.post]}, headers={"Authorization": "Bearer nope"})
        assert wrong.status_code == 401
        auth = {"Authorization": "Bearer s3cret-token"}
        first = c.post("/internal/ingest", json={"posts": [self.post, {"bad": 1}]}, headers=auth).json()
        assert first == {"new": 1, "duplicate": 0, "attached_copy": 0, "invalid": 1}
        same_url = {**self.post, "source_id": "feed-2", "source_url": "https://news.example.org/a"}
        second = c.post("/internal/ingest", json={"posts": [self.post, same_url]}, headers=auth).json()
        assert second["duplicate"] == 2


def _request(peer: str, forwarded: str) -> Request:
    return Request({"type": "http", "headers": [(b"x-forwarded-for", forwarded.encode())], "client": (peer, 1234)})


def test_forwarded_for_is_only_trusted_from_the_local_proxy():
    assert client_ip(_request("127.0.0.1", "1.2.3.4"), ["127.0.0.1"]) == "1.2.3.4"
    assert client_ip(_request("8.8.8.8", "1.2.3.4"), ["127.0.0.1"]) == "8.8.8.8"
    assert client_ip(_request("127.0.0.1", "6.6.6.6, 1.2.3.4"), ["127.0.0.1"]) == "1.2.3.4"
