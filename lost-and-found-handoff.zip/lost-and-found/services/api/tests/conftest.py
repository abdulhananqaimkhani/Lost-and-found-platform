import pytest
from fastapi.testclient import TestClient
from lf_api.main import create_app


@pytest.fixture
def make_client(settings, sessions):
    """Build a client, optionally with changed settings (e.g. a lower rate limit)."""
    clients = []

    def _make(**overrides):
        for key, value in overrides.items():
            setattr(settings, key, value)
        client = TestClient(create_app(settings=settings, sessions=sessions))
        client.__enter__()
        clients.append(client)
        return client

    yield _make
    for client in clients:
        client.__exit__(None, None, None)


@pytest.fixture
def client(make_client):
    return make_client()
