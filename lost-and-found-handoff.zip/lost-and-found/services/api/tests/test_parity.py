"""Frontend demo engine vs. FastAPI: the same filters must give the same reports in the same order.

The cases and their expected results are generated from the TypeScript code itself
(apps/web/scripts/export-query-parity.mts), including the exact query string the browser sends.
"""

import json
from pathlib import Path

import pytest

FIXTURE = Path(__file__).parent / "fixtures" / "parity_cases.json"
CASES = json.loads(FIXTURE.read_text(encoding="utf-8"))["cases"]


@pytest.mark.db
@pytest.mark.parametrize("case", CASES, ids=[c["name"] for c in CASES])
def test_api_matches_frontend_demo_engine(client, case):
    response = client.get(f"/api/reports?{case['query']}")
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["total"] == case["total"]
    assert [r["id"] for r in body["items"]] == case["ids"]
    for got, expected in zip((r["distance_km"] for r in body["items"]), case["distances"], strict=True):
        if expected is None:
            assert got is None
        else:
            assert got == pytest.approx(expected, abs=0.02)
