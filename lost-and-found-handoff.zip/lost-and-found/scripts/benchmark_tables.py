"""Print the benchmark tables (Markdown) from docs/benchmarks/*.json, so no number is copied by hand.

uv run python scripts/benchmark_tables.py
"""

from __future__ import annotations

import json
import sys

from lf_core.settings import REPO_ROOT

OUT = REPO_ROOT / "docs" / "benchmarks"
MODELS = ["qwen2.5:3b", "qwen2.5:1.5b", "llama3.2:3b"]


def load(model: str, tag: str = "") -> dict | None:
    path = OUT / f"{model.replace(':', '-')}{tag}.json"
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None


def row(model: str, s: dict) -> str:
    llm, pipe = s["classification_llm_only"], s["classification_full_pipeline"]
    f = s["field_accuracy"]
    j = s["json"]
    return (
        f"| `{model}` | {llm['macro_f1']:.3f} | {pipe['macro_f1']:.3f} | {f.get('item_category', 0):.2f} | "
        f"{f.get('location_text', 0):.2f} | {f.get('incident_date', 0):.2f} | {f.get('colour', 0):.2f} | "
        f"{j['valid_first_try']}/{j['valid_first_try'] + j['valid_after_repair'] + j['invalid'] + j['errors']} | "
        f"{s['latency_s']['p50']:.1f} / {s['latency_s']['p95']:.1f} | {s['peak_ollama_ram_mb'] / 1000:.1f} GB |"
    )


def table(tag: str, title: str) -> None:
    print(f"\n### {title}\n")
    print(
        "| Model | Macro-F1, AI only | Macro-F1, with prefilter | Category | Location | Date | Colour | "
        "JSON valid 1st try | Latency p50 / p95 (s) | Peak RAM |"
    )
    print("|---|---|---|---|---|---|---|---|---|---|")
    baseline = None
    for model in MODELS:
        s = load(model, tag)
        if s:
            print(row(model, s))
            baseline = baseline or s
    if baseline:
        b = baseline["classification_keyword_baseline"]
        print(f"| keyword rules only (no AI) | {b['macro_f1']:.3f} | — | — | — | — | — | — | <0.01 | — |")
        p = baseline["prefilter"]
        print(
            f"\nPrefilter on this set: recall {p['recall']:.3f}, precision {p['precision']:.3f}, "
            f"{p['llm_calls_saved']} of {baseline['dataset']['rows']} AI calls saved; "
            f"relevant posts it dropped: {', '.join(p['relevant_posts_wrongly_dropped']) or 'none'}."
        )
        print(f"Language detection (deterministic): {baseline['language_detection_accuracy']:.3f}.")


def per_class(model: str, tag: str) -> None:
    s = load(model, tag)
    if not s:
        return
    for key, name in (("classification_llm_only", "AI only"), ("classification_full_pipeline", "with prefilter")):
        c = s[key]
        print(
            f"\n`{model}` {tag or 'dev'}, {name}: "
            + "; ".join(
                f"{k} P {c[k]['precision']:.2f} R {c[k]['recall']:.2f}" for k in ("LOST", "FOUND", "IRRELEVANT")
            )
        )
        print("Confusion (rows = truth): " + json.dumps(c["confusion"]))
    g = s["grounding"]
    print(
        f"Grounding: {g['fields_removed_as_not_in_post']} of {g['fields_claimed']} copied fields removed "
        f"({g['removal_rate']:.1%}); location given when the post has none: {g['location_given_when_post_has_none']}."
    )


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    table("", "Development set (120 posts; deterministic rules were tuned on it → optimistic)")
    table(".heldout", "Held-out set (40 posts written after tuning; nothing was changed after seeing them)")
    for model in MODELS:
        per_class(model, "")
        per_class(model, ".heldout")
    v1 = OUT / "qwen2.5-3b.v1-grounding.json"
    if v1.exists():
        s = json.loads(v1.read_text(encoding="utf-8"))
        print("\nBefore tuning (qwen2.5:3b, dev set, prefilter v1 + grounding v1): " + row("qwen2.5:3b (v1)", s))


if __name__ == "__main__":
    main()
