"""Evaluate a local Ollama model on the labelled dataset (datasets/eval/posts.jsonl).

    uv run python scripts/evaluate_model.py --model qwen2.5:3b
    uv run python scripts/evaluate_model.py --model qwen2.5:3b --limit 10      # quick smoke run

This calls the real model on this computer. It is NOT part of the automated test suite: it is slow
(tens of seconds per post on a 2-core CPU), and its purpose is measurement, not pass/fail.

Results go to docs/benchmarks/<model>.json (all numbers) and are summarised in the console.
Per-post predictions are saved as they are produced (…predictions.jsonl), so an interrupted run
resumes where it stopped.
"""

from __future__ import annotations

import argparse
import json
import platform
import statistics
import sys
import threading
import time
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

import psutil
from lf_core.models import Place
from lf_core.settings import REPO_ROOT, get_settings
from lf_core.text import normalize_text
from lf_worker.ai.extraction import Extractor
from lf_worker.ai.grounding import ground
from lf_worker.ai.language import detect_language
from lf_worker.ai.ollama_client import ConfigurationRefused, OllamaBadOutput, OllamaError, OllamaUnavailable
from lf_worker.ai.prefilter import prefilter
from lf_worker.app import build_client
from lf_worker.geocoding.geocoder import GazetteerGeocoder
from rapidfuzz import fuzz

DATASET = REPO_ROOT / "datasets" / "eval" / "posts.jsonl"
OUT_DIR = REPO_ROOT / "docs" / "benchmarks"
CLASSES = ["LOST", "FOUND", "IRRELEVANT"]
TAG = ""
GAZETTEER_FILE = REPO_ROOT / "database" / "schema" / "karachi_gazetteer.json"


def load_gazetteer() -> GazetteerGeocoder:
    places = json.loads(GAZETTEER_FILE.read_text(encoding="utf-8"))["places"]
    return GazetteerGeocoder(
        [
            Place(
                key=p["key"],
                name=p["name"],
                label=p.get("label") or p["name"],
                aliases=p.get("aliases", []),
                city="Karachi",
                precision=p["precision"],
                latitude=p["latitude"],
                longitude=p["longitude"],
                radius_m=p.get("radius_m"),
                is_area_filter=True,
            )
            for p in places
        ]
    )


GAZETTEER = load_gazetteer()


def place_finder(text: str) -> str | None:
    place = GAZETTEER.find_in_text(None, text)
    return place.label if place else None


def regrade(raw: dict, row: dict):
    """Apply the CURRENT deterministic code (prefilter, grounding, dates) to a stored model answer."""
    from lf_worker.ai.extraction import ExtractionResult

    return ground(
        ExtractionResult.model_validate(raw),
        row["text"],
        datetime.fromisoformat(row["published_at"]),
        prefilter(row["text"]),
        place_finder=place_finder,
    )


def graded_dict(grounded) -> dict:
    return {
        "report_type": grounded.report_type,
        "item_category": grounded.item_category,
        "location_text": grounded.location_text,
        "colour": grounded.colour,
        "incident_date": grounded.incident_date.isoformat() if grounded.incident_date else None,
        "is_resolution_update": grounded.is_resolution_update,
        "removed": grounded.removed,
        "confidence": grounded.confidence,
        "needs_review": grounded.needs_review,
    }


class RamSampler(threading.Thread):
    """Samples the combined resident memory of all Ollama processes once per second."""

    def __init__(self):
        super().__init__(daemon=True)
        self.peak_mb = 0.0
        self._stop = threading.Event()

    def run(self):
        while not self._stop.is_set():
            total = 0
            for proc in psutil.process_iter(["name", "memory_info"]):
                name = (proc.info.get("name") or "").lower()
                if "ollama" in name or "llama" in name:
                    mem = proc.info.get("memory_info")
                    total += mem.rss if mem else 0
            self.peak_mb = max(self.peak_mb, total / 1e6)
            self._stop.wait(1.0)

    def stop(self):
        self._stop.set()


def prf(gold: list[str], pred: list[str]) -> dict:
    out = {}
    for c in CLASSES:
        tp = sum(1 for g, p in zip(gold, pred, strict=True) if g == c and p == c)
        fp = sum(1 for g, p in zip(gold, pred, strict=True) if g != c and p == c)
        fn = sum(1 for g, p in zip(gold, pred, strict=True) if g == c and p != c)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        out[c] = {"precision": round(precision, 3), "recall": round(recall, 3), "f1": round(f1, 3), "support": tp + fn}
    out["macro_f1"] = round(sum(out[c]["f1"] for c in CLASSES) / len(CLASSES), 3)
    out["accuracy"] = round(sum(1 for g, p in zip(gold, pred, strict=True) if g == p) / len(gold), 3)
    out["confusion"] = {
        g: {p: sum(1 for a, b in zip(gold, pred, strict=True) if a == g and b == p) for p in CLASSES} for g in CLASSES
    }
    return out


def same_location(pred: str | None, gold: str | None) -> bool:
    if pred is None or gold is None:
        return pred is None and gold is None
    if fuzz.token_set_ratio(normalize_text(pred), normalize_text(gold)) >= 70:
        return True
    # A gazetteer label (e.g. "Gulshan-e-Iqbal") is right if the gold span names the same place.
    pred_place, gold_place = GAZETTEER.find_in_text(None, pred), GAZETTEER.find_in_text(None, gold)
    return pred_place is not None and gold_place is not None and pred_place.key == gold_place.key


def same_colour(pred: str | None, gold: str | None) -> bool:
    if pred is None or gold is None:
        return pred is None and gold is None
    a, b = normalize_text(pred), normalize_text(gold)
    return a == b or a in b or b in a


def keyword_baseline(text: str) -> str:
    result = prefilter(text)
    if not result.passed:
        return "IRRELEVANT"
    return result.intent or "LOST"


def run(model: str, limit: int | None, timeout: float) -> dict:
    settings = get_settings()
    rows = [json.loads(line) for line in DATASET.read_text(encoding="utf-8").splitlines() if line.strip()]
    rows = rows[:limit] if limit else rows
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    slug = model.replace(":", "-").replace("/", "-")
    pred_path = OUT_DIR / f"{slug}{TAG}.predictions.jsonl"
    done = {}
    if pred_path.exists():
        for line in pred_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                record = json.loads(line)
                done[record["id"]] = record

    try:
        client = build_client(settings, model, timeout_s=timeout)
    except ConfigurationRefused as exc:
        sys.exit(f"Cannot evaluate: {exc}")
    health = client.health()
    if not health.ok:
        sys.exit(f"Cannot evaluate: {health.message}")
    extractor = Extractor(client)
    sampler = RamSampler()
    sampler.start()

    with pred_path.open("a", encoding="utf-8") as sink:
        for i, row in enumerate(rows, start=1):
            if row["id"] in done:
                continue
            published = datetime.fromisoformat(row["published_at"])
            record: dict = {"id": row["id"]}
            try:
                outcome = extractor.extract(row["text"])
                grounded = ground(
                    outcome.result,
                    row["text"],
                    published,
                    prefilter(row["text"]),
                    min_confidence_active=settings.min_confidence_active,
                    place_finder=place_finder,  # same as the worker
                )
                record.update(
                    status="ok",
                    attempts=outcome.attempts,
                    latency_s=round(outcome.latency_s, 2),
                    output_tokens=sum(s.output_tokens or 0 for s in outcome.stats),
                    raw=outcome.result.model_dump(),
                    grounded={
                        "report_type": grounded.report_type,
                        "item_category": grounded.item_category,
                        "location_text": grounded.location_text,
                        "colour": grounded.colour,
                        "incident_date": grounded.incident_date.isoformat() if grounded.incident_date else None,
                        "is_resolution_update": grounded.is_resolution_update,
                        "removed": grounded.removed,
                        "confidence": grounded.confidence,
                        "needs_review": grounded.needs_review,
                    },
                )
            except OllamaBadOutput as exc:
                record.update(status="invalid_json", error=str(exc)[:300])
            except OllamaUnavailable as exc:
                sampler.stop()
                client.close()
                sys.exit(f"Evaluation paused: {exc}")
            except OllamaError as exc:
                record.update(status="error", error=str(exc)[:300])
            sink.write(json.dumps(record, ensure_ascii=False) + "\n")
            sink.flush()
            done[row["id"]] = record
            print(
                f"[{i}/{len(rows)}] {row['id']} {record['status']} {record.get('latency_s', '')}s "
                f"{record.get('grounded', {}).get('report_type', '')} (gold {row['gold']['report_type']})",
                flush=True,
            )
    sampler.stop()
    client.unload()
    client.close()
    return summarise(model, rows, done, sampler.peak_mb)


def summarise(model: str, rows: list[dict], preds: dict, peak_mb: float) -> dict:
    gold = [r["gold"]["report_type"] for r in rows]
    llm_pred, pipeline_pred = [], []
    for r in rows:
        p = preds.get(r["id"], {})
        if p.get("status") == "ok":
            p["grounded"] = graded_dict(regrade(p["raw"], r))
        llm_type = p["grounded"]["report_type"] if p.get("status") == "ok" else "IRRELEVANT"
        llm_pred.append(llm_type)
        pipeline_pred.append(llm_type if prefilter(r["text"]).passed else "IRRELEVANT")
    baseline_pred = [keyword_baseline(r["text"]) for r in rows]

    relevant_gold = [g != "IRRELEVANT" for g in gold]
    passed = [prefilter(r["text"]).passed for r in rows]
    pf_tp = sum(1 for g, p in zip(relevant_gold, passed, strict=True) if g and p)
    prefilter_stats = {
        "recall": round(pf_tp / max(1, sum(relevant_gold)), 3),
        "precision": round(pf_tp / max(1, sum(passed)), 3),
        "llm_calls_saved": sum(1 for p in passed if not p),
        "relevant_posts_wrongly_dropped": [
            r["id"] for r, g, p in zip(rows, relevant_gold, passed, strict=True) if g and not p
        ],
    }

    # Field accuracy: only on relevant posts whose type the model got right (otherwise fields are meaningless).
    fields = Counter()
    totals = Counter()
    for r, pred_type in zip(rows, llm_pred, strict=True):
        g = r["gold"]
        p = preds.get(r["id"], {})
        if g["report_type"] == "IRRELEVANT" or pred_type != g["report_type"] or p.get("status") != "ok":
            continue
        gp = p["grounded"]
        checks = {
            "item_category": gp["item_category"] == g["item_category"],
            "location_text": same_location(gp["location_text"], g["location_text"]),
            "incident_date": gp["incident_date"] == g["incident_date"],
            "colour": same_colour(gp["colour"], g["colour"]),
            "is_resolution_update": gp["is_resolution_update"] == g["is_resolution_update"],
        }
        for name, ok in checks.items():
            totals[name] += 1
            fields[name] += int(ok)
    field_accuracy = {k: round(fields[k] / totals[k], 3) for k in totals}
    field_accuracy["n"] = max(totals.values()) if totals else 0

    language_acc = round(
        sum(1 for r in rows if detect_language(r["text"]).value == r["gold"]["language"]) / len(rows), 3
    )

    ok = [p for p in preds.values() if p.get("status") == "ok"]
    claimed = removed = 0
    for p in ok:
        for name in ("location_text", "date_expression", "colour", "brand"):
            if p["raw"].get(name):
                claimed += 1
                removed += int(name in p["grounded"]["removed"])
    invented_location = sum(
        1
        for r in rows
        if r["gold"]["location_text"] is None
        and preds.get(r["id"], {}).get("status") == "ok"
        and r["gold"]["report_type"] != "IRRELEVANT"
        and preds[r["id"]]["raw"].get("location_text")
    )
    latencies = sorted(p["latency_s"] for p in ok)
    statuses = Counter(p.get("status") for p in preds.values())
    summary = {
        "model": model,
        "measured_at": datetime.now(UTC).isoformat(timespec="seconds"),
        "code_version": "prefilter v2, grounding v2 (word-level match + gazetteer fallback)",
        "dataset": {
            "path": str(DATASET.relative_to(REPO_ROOT)),
            "rows": len(rows),
            "origin": dict(Counter(r["origin"] for r in rows)),
            "classes": dict(Counter(gold)),
            "languages": dict(Counter(r["gold"]["language"] for r in rows)),
        },
        "machine": {
            "cpu": platform.processor(),
            "cores_logical": psutil.cpu_count(),
            "ram_gb": round(psutil.virtual_memory().total / 1e9, 1),
        },
        "classification_llm_only": prf(gold, llm_pred),
        "classification_full_pipeline": prf(gold, pipeline_pred),
        "classification_keyword_baseline": prf(gold, baseline_pred),
        "prefilter": prefilter_stats,
        "field_accuracy": field_accuracy,
        "language_detection_accuracy": language_acc,
        "json": {
            "valid_first_try": sum(1 for p in ok if p["attempts"] == 1),
            "valid_after_repair": sum(1 for p in ok if p["attempts"] == 2),
            "invalid": statuses.get("invalid_json", 0),
            "errors": statuses.get("error", 0),
        },
        "grounding": {
            "fields_claimed": claimed,
            "fields_removed_as_not_in_post": removed,
            "removal_rate": round(removed / claimed, 3) if claimed else 0.0,
            "location_given_when_post_has_none": invented_location,
        },
        "latency_s": {
            "mean": round(statistics.mean(latencies), 1) if latencies else None,
            "p50": latencies[len(latencies) // 2] if latencies else None,
            "p95": latencies[min(len(latencies) - 1, int(len(latencies) * 0.95))] if latencies else None,
        },
        "peak_ollama_ram_mb": round(peak_mb),
    }
    slug = model.replace(":", "-").replace("/", "-")
    (OUT_DIR / f"{slug}{TAG}.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    return summary


def summarise_stored(model: str) -> dict:
    rows = [json.loads(line) for line in DATASET.read_text(encoding="utf-8").splitlines() if line.strip()]
    slug = model.replace(":", "-").replace("/", "-")
    preds = {}
    for line in (OUT_DIR / f"{slug}{TAG}.predictions.jsonl").read_text(encoding="utf-8").splitlines():
        if line.strip():
            record = json.loads(line)
            preds[record["id"]] = record
    previous = OUT_DIR / f"{slug}{TAG}.json"
    peak = json.loads(previous.read_text(encoding="utf-8")).get("peak_ollama_ram_mb", 0) if previous.exists() else 0
    return summarise(model, rows, preds, peak)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--model", default=None, help="Ollama model tag (default: OLLAMA_MODEL)")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--timeout", type=float, default=300.0)
    parser.add_argument("--dataset", default=None, help="JSONL file (default: datasets/eval/posts.jsonl)")
    parser.add_argument("--tag", default="", help="suffix for output files, e.g. heldout")
    parser.add_argument(
        "--summarise-only",
        action="store_true",
        help="re-score stored predictions with the current code; no model calls",
    )
    args = parser.parse_args()
    global DATASET, TAG
    if args.dataset:
        DATASET = Path(args.dataset).resolve()
    TAG = f".{args.tag}" if args.tag else ""
    settings = get_settings()
    model = args.model or (settings.openrouter_model if settings.ai_provider == "openrouter" else settings.ollama_model)
    started = time.time()
    summary = summarise_stored(model) if args.summarise_only else run(model, args.limit, args.timeout)
    s = summary
    print(
        json.dumps(
            {
                k: s[k]
                for k in ("classification_full_pipeline", "field_accuracy", "json", "latency_s", "peak_ollama_ram_mb")
            },
            indent=2,
        )
    )
    print(f"Done in {(time.time() - started) / 60:.1f} min")


if __name__ == "__main__":
    main()
