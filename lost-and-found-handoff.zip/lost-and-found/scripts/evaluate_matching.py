"""Evaluate the match scorer on hand-labelled LOST/FOUND pairs (datasets/eval/match_pairs.jsonl).

    uv run python scripts/evaluate_matching.py

Deterministic: no AI involved. Coordinates come from the OSM gazetteer by place key.
Writes docs/benchmarks/matching.json.
"""

from __future__ import annotations

import json
from datetime import date
from types import SimpleNamespace

from lf_core.settings import REPO_ROOT
from lf_worker.matching import CANDIDATE_DAYS, CANDIDATE_RADIUS_M, related_categories, score

PAIRS = REPO_ROOT / "datasets" / "eval" / "match_pairs.jsonl"
GAZETTEER = REPO_ROOT / "database" / "schema" / "karachi_gazetteer.json"
THRESHOLDS = [0.55, 0.60, 0.65, 0.70, 0.75]


def as_report(side: dict, report_type: str, places: dict) -> SimpleNamespace:
    place = places.get(side["place"]) if side.get("place") else None
    return SimpleNamespace(
        report_type=report_type,
        item_category=side["category"],
        item_name=side["item_name"],
        description=side["description"],
        attributes={"colour": side.get("colour")},
        latitude=place["latitude"] if place else None,
        longitude=place["longitude"] if place else None,
        incident_date=date.fromisoformat(side["date"]),
        reported_at=None,
    )


def main() -> None:
    places = {p["key"]: p for p in json.loads(GAZETTEER.read_text(encoding="utf-8"))["places"]}
    rows = [json.loads(line) for line in PAIRS.read_text(encoding="utf-8").splitlines() if line.strip()]
    scored = []
    for row in rows:
        missing = [s["place"] for s in (row["lost"], row["found"]) if s.get("place") and s["place"] not in places]
        if missing:
            raise SystemExit(f"{row['id']}: unknown place key(s) {missing}")
        lost, found = as_report(row["lost"], "LOST", places), as_report(row["found"], "FOUND", places)
        pair = score(lost, found)
        # Same gate as matching.candidates(): only these pairs are ever scored in the real system.
        candidate = (
            found.item_category in related_categories(lost.item_category)
            and pair.days_apart <= CANDIDATE_DAYS
            and (pair.distance_km is None or pair.distance_km * 1000 <= CANDIDATE_RADIUS_M)
        )
        final = pair.score if candidate else 0.0
        scored.append(
            {
                "id": row["id"],
                "gold": row["gold_match"],
                "score": final,
                "raw_score": pair.score,
                "candidate": candidate,
                "breakdown": pair.breakdown,
                "distance_km": round(pair.distance_km, 2) if pair.distance_km is not None else None,
                "days_apart": pair.days_apart,
                "note": row["note"],
            }
        )

    by_threshold = {}
    for t in THRESHOLDS:
        tp = sum(1 for s in scored if s["gold"] and s["score"] >= t)
        fp = sum(1 for s in scored if not s["gold"] and s["score"] >= t)
        fn = sum(1 for s in scored if s["gold"] and s["score"] < t)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        by_threshold[str(t)] = {
            "precision": round(precision, 3),
            "recall": round(recall, 3),
            "f1": round(f1, 3),
            "tp": tp,
            "fp": fp,
            "fn": fn,
        }
    result = {
        "dataset": {
            "path": str(PAIRS.relative_to(REPO_ROOT)),
            "pairs": len(rows),
            "matches": sum(r["gold_match"] for r in rows),
            "origin": "SYNTHETIC_HANDWRITTEN",
        },
        "by_threshold": by_threshold,
        "pairs": sorted(scored, key=lambda s: -s["score"]),
    }
    out = REPO_ROOT / "docs" / "benchmarks" / "matching.json"
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(by_threshold, indent=2))
    for s in result["pairs"]:
        flag = "ok " if (s["score"] >= 0.65) == s["gold"] else "ERR"
        print(
            f"{flag} {s['id']} gold={'match' if s['gold'] else 'no   '} score={s['score']:.3f} "
            f"{'' if s['candidate'] else '(not a candidate) '}"
            f"d={s['distance_km']}km days={s['days_apart']}  {s['note']}"
        )


if __name__ == "__main__":
    main()
