"""Geocode a list of place names with OpenStreetMap Nominatim.

Used to produce *real* coordinates (with OSM provenance) for the demo dataset and,
later, to seed the Karachi gazetteer. Respects the Nominatim usage policy:
max 1 request/second, identifying User-Agent, results cached in the output file.

Usage:
    python scripts/geocode_places.py --input database/schema/karachi_places_seed.txt \
        --output apps/web/src/lib/mock/places.json

Input format: one query per line: `<key> | <search query>`. Lines starting with # are ignored.
Data © OpenStreetMap contributors, ODbL 1.0.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
USER_AGENT = "LostAndFoundFinder-dev/0.1 (university final year project)"
# Rough Karachi bounding box used to bias and bound results (lon_min, lat_max, lon_max, lat_min).
KARACHI_VIEWBOX = "66.65,25.25,67.55,24.70"

POI_CATEGORIES = {"amenity", "shop", "building", "tourism", "aeroway", "railway", "leisure", "historic", "office"}
NEIGHBOURHOOD_TYPES = {"suburb", "neighbourhood", "quarter", "residential", "administrative", "village", "town"}
RADIUS_BY_PRECISION = {"POI": 120, "STREET": 400}
NEIGHBOURHOOD_RADIUS_RANGE_M = (400, 2500)


def bbox_radius_m(bbox: list[str]) -> int:
    """Half the diagonal of an OSM bounding box [south, north, west, east], in metres."""
    south, north, west, east = (float(v) for v in bbox)
    mid_lat = math.radians((south + north) / 2)
    height_m = (north - south) * 111_320
    width_m = (east - west) * 111_320 * math.cos(mid_lat)
    return round(math.hypot(height_m, width_m) / 2)


def radius_for(precision: str, bbox: list[str] | None) -> int | None:
    if precision == "NEIGHBOURHOOD" and bbox:
        low, high = NEIGHBOURHOOD_RADIUS_RANGE_M
        return max(low, min(high, bbox_radius_m(bbox)))
    return RADIUS_BY_PRECISION.get(precision)


def classify_precision(category: str, place_type: str) -> str:
    """Map an OSM category/type to the application's precision levels."""
    if category in POI_CATEGORIES:
        return "POI"
    if category == "highway":
        return "STREET"
    if place_type in {"city"}:
        return "CITY"
    if place_type in NEIGHBOURHOOD_TYPES or category in {"place", "boundary", "landuse"}:
        return "NEIGHBOURHOOD"
    return "POI"


def geocode(query: str) -> dict | None:
    params = urllib.parse.urlencode(
        {
            "q": query,
            "format": "jsonv2",
            "limit": 1,
            "countrycodes": "pk",
            "viewbox": KARACHI_VIEWBOX,
            "bounded": 1,
            "accept-language": "en",
        }
    )
    request = urllib.request.Request(f"{NOMINATIM_URL}?{params}", headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=20) as response:
        results = json.loads(response.read().decode("utf-8"))
    return results[0] if results else None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    existing: dict[str, dict] = {}
    if args.output.exists():
        existing = {p["key"]: p for p in json.loads(args.output.read_text(encoding="utf-8"))["places"]}

    places: list[dict] = []
    misses: list[str] = []
    # utf-8-sig tolerates the BOM that Windows PowerShell 5.1 adds when saving files.
    for raw in args.input.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "|" not in line:
            print(f"SKIP  malformed line (expected 'key | query'): {line!r}", file=sys.stderr)
            continue
        parts = [part.strip() for part in line.split("|")]
        key, query = parts[0], parts[1]
        # Optional columns: label shown in the UI, and comma-separated aliases (spellings, Urdu script).
        extra = {}
        if len(parts) > 2 and parts[2]:
            extra["label"] = parts[2]
        if len(parts) > 3 and parts[3]:
            extra["aliases"] = [a.strip() for a in parts[3].split(",") if a.strip()]
        if key in existing and existing[key]["query"] == query and "bbox" in existing[key]:
            places.append({**existing[key], **extra})  # cached: no request
            continue
        time.sleep(1.1)  # usage policy: absolute max 1 request per second
        result = geocode(query)
        if result is None:
            misses.append(f"{key} ({query})")
            print(f"MISS  {key}: {query}", file=sys.stderr)
            continue
        precision = classify_precision(result.get("category", ""), result.get("type", ""))
        place = {
            "key": key,
            "query": query,
            "name": result.get("name") or query.split(",")[0],
            "display_name": result["display_name"],
            "latitude": round(float(result["lat"]), 6),
            "longitude": round(float(result["lon"]), 6),
            "osm_type": result["osm_type"],
            "osm_id": result["osm_id"],
            "osm_category": result.get("category"),
            "osm_type_detail": result.get("type"),
            "precision": precision,
            "bbox": [float(v) for v in result.get("boundingbox", [])] or None,
            "radius_m": radius_for(precision, result.get("boundingbox")),
            **extra,
        }
        places.append(place)
        print(f"OK    {key}: {place['name']} [{precision}] {place['latitude']},{place['longitude']}")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "attribution": "Data © OpenStreetMap contributors, ODbL 1.0. https://osm.org/copyright",
        "generated_by": "scripts/geocode_places.py (Nominatim)",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "places": places,
    }
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"\n{len(places)} places written, {len(misses)} not found: {misses}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
