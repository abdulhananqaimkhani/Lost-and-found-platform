/**
 * Records what the demo-mode query engine returns for a set of filter combinations, together
 * with the exact query string the frontend's API client would send for them.
 * The backend test suite (services/api/tests/test_parity.py) replays every case against FastAPI
 * and requires identical results, so the map behaves the same in demo and API mode.
 * Run: npx tsx scripts/export-query-parity.mts
 */
import { writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { DEFAULT_FILTERS, type ReportFilters } from "../src/lib/filters";
import { filtersToQuery } from "../src/lib/data/api-source";
import { mockSource } from "../src/lib/data/mock-source";
import type { ListOptions } from "../src/lib/data/source";

type Case = { name: string; filters: Partial<ReportFilters>; options?: ListOptions };

const cases: Case[] = [
  { name: "default", filters: {} },
  { name: "page 2", filters: { page: 2 } },
  { name: "oldest", filters: { sort: "oldest" } },
  { name: "synonym batwa", filters: { q: "batwa" } },
  { name: "phone ignores masked numbers", filters: { q: "phone" } },
  { name: "chabi", filters: { q: "chabi" } },
  { name: "two words", filters: { q: "black wallet" } },
  { name: "urdu word", filters: { q: "گم" } },
  { name: "lost phones", filters: { type: "LOST", categories: ["PHONE"] } },
  { name: "found wallets", filters: { type: "FOUND", categories: ["WALLET"] } },
  { name: "pets and keys", filters: { categories: ["PET", "KEYS"] } },
  { name: "resolved or disputed", filters: { statuses: ["RESOLVED", "DISPUTED"] } },
  { name: "near gulshan", filters: { area: "gulshan-e-iqbal" } },
  { name: "near saddar by distance", filters: { area: "saddar", sort: "distance" } },
  { name: "unknown area", filters: { area: "atlantis" } },
  { name: "distance from a point", filters: { near: { lat: 24.86, lng: 67.01 }, sort: "distance" } },
  { name: "custom dates", filters: { date: "custom", from: "2026-11-10", to: "2026-11-18" } },
  { name: "bbox located", filters: {}, options: { bbox: [67.0, 24.8, 67.1, 24.9], located: true, pageSize: 30 } },
  { name: "unmapped only", filters: {}, options: { located: false, pageSize: 30 } },
  { name: "page size 5", filters: { type: "LOST" }, options: { pageSize: 5 } },
];

const results = [];
for (const c of cases) {
  const filters: ReportFilters = { ...DEFAULT_FILTERS, ...c.filters };
  const page = await mockSource.listReports(filters, c.options ?? {});
  results.push({
    name: c.name,
    query: filtersToQuery(filters, c.options ?? {}).toString(),
    total: page.total,
    ids: page.items.map((r) => r.id),
    distances: page.items.map((r) => r.distance_km ?? null),
  });
}

const target = resolve(import.meta.dirname, "../../../services/api/tests/fixtures/parity_cases.json");
writeFileSync(target, JSON.stringify({ generated_by: "apps/web/scripts/export-query-parity.mts", cases: results }, null, 2) + "\n");
console.log(`Wrote ${results.length} cases to ${target}`);
