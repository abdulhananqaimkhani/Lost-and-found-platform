/**
 * Writes the hand-written demo dataset to database/schema/demo_dataset.json, so the Python
 * backend can load exactly the same records (`uv run python -m lf_worker seed-demo`).
 * Run: npx tsx scripts/export-demo-data.mts
 * A unit test (src/lib/mock/demo-export.test.ts) fails if the JSON is out of date.
 */
import { writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { buildDemoExport } from "../src/lib/mock/demo-export";

const target = resolve(import.meta.dirname, "../../../database/schema/demo_dataset.json");
writeFileSync(target, JSON.stringify(buildDemoExport(), null, 2) + "\n", "utf8");
console.log(`Wrote ${target}`);
