# Lost & Found Finder — web app

Next.js 16 (App Router, TypeScript), Tailwind CSS 4, shadcn/ui (Radix), Leaflet + OpenStreetMap.

## Run

```powershell
cd apps/web
npm install
copy .env.example .env.local     # optional; defaults to the demo data
npm run dev                      # http://localhost:3000
```

For demos on a low-memory laptop, use a production build. It uses far less RAM than the dev server:

```powershell
npm run build
npm run start
```

## Test

```powershell
npm test                 # unit and component tests (Vitest, jsdom)
npm run typecheck        # route types + TypeScript
npm run lint
npx playwright install chromium   # first time only (~125 MB)
npm run build; npm run test:e2e   # end-to-end tests against the production build
```

No backend, Ollama or paid API is needed for any of these.

## Structure

| Path | What it is |
|---|---|
| `src/app/` | Routes: `/` map explorer, `/reports` explore, `/reports/[id]` details, `/about` |
| `src/components/explorer/` | Map explorer page: list panel, mobile sheet, map ↔ list wiring |
| `src/components/map/` | Leaflet map, marker icons, clustering, preview card, mini map |
| `src/components/reports/` | Report list rows and shared display pieces (type mark, status, precision) |
| `src/lib/data/` | `DataSource` interface with `mock` and `api` implementations, and pure query logic |
| `src/lib/mock/` | **Demo data** (synthetic posts) and OSM-geocoded Karachi places |
| `src/lib/store/selection.ts` | Shared selection state that keeps the map and list in sync |
| `src/lib/filters.ts` | Filters ↔ URL query string |
| `e2e/` | Playwright tests |

## Design notes

- **Marker language:** LOST is hollow (still missing) and FOUND is filled (located). The two types differ in shape as well as colour.
- **Location honesty:** exact places get a pin, approximate areas get a dot with a dashed circle, and city-only or unknown locations aren't mapped.
- **Demo data:** every record is labelled `DEMO`, uses `.invalid` URLs, and takes its coordinates from real OpenStreetMap lookups (`scripts/geocode_places.py`). A test enforces this.
