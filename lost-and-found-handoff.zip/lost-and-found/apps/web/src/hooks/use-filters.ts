"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useCallback, useMemo } from "react";
import { DEFAULT_FILTERS, parseFilters, serializeFilters, type ReportFilters } from "@/lib/filters";

/**
 * Filters backed by the URL query string. Changing any filter except `page` resets to page 1.
 * Must be used inside a <Suspense> boundary (Next.js requirement for useSearchParams).
 */
export function useFilters() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const key = searchParams.toString();

  const filters = useMemo(() => parseFilters(new URLSearchParams(key)), [key]);

  const navigate = useCallback(
    (next: ReportFilters) => {
      const qs = serializeFilters(next).toString();
      router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    },
    [pathname, router],
  );

  const setFilters = useCallback(
    (patch: Partial<ReportFilters>) => {
      const resetsPage = !("page" in patch);
      navigate({ ...filters, ...patch, ...(resetsPage ? { page: 1 } : {}) });
    },
    [filters, navigate],
  );

  /** Clears every filter but keeps the chosen sort order and reference point. */
  const clearFilters = useCallback(() => {
    navigate({ ...DEFAULT_FILTERS, sort: filters.sort, near: filters.near });
  }, [filters.near, filters.sort, navigate]);

  return { filters, setFilters, clearFilters };
}
