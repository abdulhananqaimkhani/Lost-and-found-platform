"use client";

import { useCallback, useSyncExternalStore } from "react";

/** Server snapshot is `fallback`, so markup is stable during hydration. */
export function useMediaQuery(query: string, fallback = false): boolean {
  const subscribe = useCallback(
    (onChange: () => void) => {
      const mql = window.matchMedia(query);
      mql.addEventListener("change", onChange);
      return () => mql.removeEventListener("change", onChange);
    },
    [query],
  );
  return useSyncExternalStore(
    subscribe,
    () => window.matchMedia(query).matches,
    () => fallback,
  );
}

/** Desktop pointer that can hover: show previews on hover. Touch devices preview on tap instead. */
export const useCanHover = () => useMediaQuery("(hover: hover) and (pointer: fine)");
export const useIsDesktop = () => useMediaQuery("(min-width: 1024px)", true);
export const usePrefersReducedMotion = () => useMediaQuery("(prefers-reduced-motion: reduce)");
