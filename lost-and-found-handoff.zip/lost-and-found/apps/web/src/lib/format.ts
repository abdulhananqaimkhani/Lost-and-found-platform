const DAY = 86_400_000;

const dateFormatter = new Intl.DateTimeFormat("en-GB", {
  day: "numeric",
  month: "short",
  year: "numeric",
  timeZone: "Asia/Karachi",
});
const dateTimeFormatter = new Intl.DateTimeFormat("en-GB", {
  day: "numeric",
  month: "short",
  year: "numeric",
  hour: "numeric",
  minute: "2-digit",
  timeZone: "Asia/Karachi",
});

export function formatDate(iso: string): string {
  return dateFormatter.format(new Date(iso));
}

export function formatDateTime(iso: string): string {
  return dateTimeFormatter.format(new Date(iso));
}

/** "Today", "Yesterday", "3 days ago", falling back to a date after two weeks. */
export function formatRelative(iso: string, now: number = Date.now()): string {
  const then = new Date(iso).getTime();
  const days = Math.floor((now - then) / DAY);
  if (days < 0) return formatDate(iso);
  if (days === 0) {
    const hours = Math.floor((now - then) / 3_600_000);
    if (hours < 1) return "Just now";
    return hours === 1 ? "1 hour ago" : `${hours} hours ago`;
  }
  if (days === 1) return "Yesterday";
  if (days < 14) return `${days} days ago`;
  return formatDate(iso);
}

/** "Posted yesterday", "Posted 3 days ago", "Posted 21 Nov 2026". */
export function formatPosted(iso: string, now: number = Date.now()): string {
  const rel = formatRelative(iso, now);
  const isAbsoluteDate = /^\d/.test(rel) && !rel.endsWith("ago");
  return `Posted ${isAbsoluteDate ? rel : rel.charAt(0).toLowerCase() + rel.slice(1)}`;
}

export function formatDistance(km: number): string {
  if (km < 1) return `${Math.round(km * 100) * 10} m`;
  return `${km < 10 ? km.toFixed(1) : Math.round(km)} km`;
}

export function formatPercent(value: number): string {
  return `${Math.round(value * 100)}%`;
}
