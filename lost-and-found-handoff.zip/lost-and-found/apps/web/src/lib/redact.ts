/**
 * Privacy redaction for original post text before it is displayed.
 * Lost-document posts often contain CNIC numbers and phone numbers; the app links to
 * the original post instead of republishing those details.
 */

// Pakistani CNIC: 13 digits, usually written 12345-1234567-1 (also with spaces or no separators).
const CNIC_PATTERN = /\b(\d{5})[-\s]?(\d{7})[-\s]?(\d)\b/g;
// Pakistani mobile numbers: 03XX-XXXXXXX, +92 3XX XXXXXXX, 0092..., with optional separators.
const PHONE_PATTERN = /(?:\+92|0092|\b0)[-\s]?3\d{2}[-\s]?\d{7}\b/g;
// Landlines such as 021-34567890 or (021) 3456 7890.
const LANDLINE_PATTERN = /\(?\b0\d{2}\)?[-\s]?\d{3,4}[-\s]?\d{4}\b/g;
const EMAIL_PATTERN = /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g;

export const MASK = "•••";

const PLACEHOLDER_PATTERN = /\[(?:phone|email) •••\]|\d{2}•••-•••-•••/g;

/**
 * Remove redaction placeholders before indexing text for search, so a hidden phone number
 * doesn't make a wallet post match a search for "phone".
 */
export function stripRedactionMarkers(text: string): string {
  return text.replace(PLACEHOLDER_PATTERN, " ");
}

export function redactText(text: string): string {
  return text
    .replace(CNIC_PATTERN, (_m, first: string) => `${first.slice(0, 2)}${MASK}-${MASK}-${MASK}`)
    .replace(PHONE_PATTERN, `[phone ${MASK}]`)
    .replace(LANDLINE_PATTERN, `[phone ${MASK}]`)
    .replace(EMAIL_PATTERN, `[email ${MASK}]`);
}
