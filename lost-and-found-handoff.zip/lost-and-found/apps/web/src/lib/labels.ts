import type {
  DatePrecision,
  ItemCategory,
  Language,
  LocationPrecision,
  ReportStatus,
  ReportType,
  SourcePlatform,
} from "./types";

export const TYPE_LABEL: Record<ReportType, string> = { LOST: "Lost", FOUND: "Found" };

export const CATEGORY_LABEL: Record<ItemCategory, string> = {
  WALLET: "Wallet",
  PHONE: "Phone",
  DOCUMENT_ID: "ID & documents",
  BAG: "Bag",
  KEYS: "Keys",
  JEWELLERY: "Jewellery",
  ELECTRONICS: "Electronics",
  PET: "Pet",
  VEHICLE: "Vehicle",
  CLOTHING: "Clothing",
  OTHER: "Other",
};

export const STATUS_LABEL: Record<ReportStatus, string> = {
  ACTIVE: "Active",
  POTENTIAL_MATCH: "Possible match",
  UNVERIFIED: "Needs review",
  DISPUTED: "Disputed",
  STALE: "Old report",
  RESOLVED: "Resolved",
};

export const STATUS_DESCRIPTION: Record<ReportStatus, string> = {
  ACTIVE: "Imported from a public post. Not independently verified.",
  POTENTIAL_MATCH: "A report of the opposite kind looks similar. This is a suggestion, not a confirmed match.",
  UNVERIFIED: "The AI was not confident about some details. Check the original post.",
  DISPUTED: "People have reported this listing as inaccurate.",
  STALE: "No new activity for a long time. The item may already be returned.",
  RESOLVED: "The item was reported returned, confirmed from the source.",
};

export const PRECISION_LABEL: Record<LocationPrecision, string> = {
  POI: "Exact place",
  STREET: "Street",
  NEIGHBOURHOOD: "Approximate area",
  CITY: "City only",
  UNKNOWN: "No location",
};

export const PRECISION_DESCRIPTION: Record<LocationPrecision, string> = {
  POI: "The post names a specific place, such as a mall or university.",
  STREET: "The post names a road. The exact spot along it is unknown.",
  NEIGHBOURHOOD: "The post names an area. The shaded circle shows roughly where, not an exact spot.",
  CITY: "The post only names the city, so it isn't shown on the map.",
  UNKNOWN: "The post doesn't say where, so it isn't shown on the map.",
};

export const DATE_PRECISION_LABEL: Record<DatePrecision, string> = {
  EXACT: "",
  APPROXIMATE: "approx.",
  UNKNOWN: "",
};

export const LANGUAGE_LABEL: Record<Language, string> = {
  ENGLISH: "English",
  ROMAN_URDU: "Roman Urdu",
  URDU: "Urdu",
  MIXED: "Mixed",
  OTHER: "Other",
};

export const PLATFORM_LABEL: Record<SourcePlatform, string> = {
  DEMO: "Demo data",
  RSS: "News feed",
  X: "X",
  REDDIT: "Reddit",
  BLUESKY: "Bluesky",
  MASTODON: "Mastodon",
  WEB: "Website",
  COMMUNITY: "Community submission",
};
