"use client";

import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { dataSource, type ListOptions } from "./data";
import type { ReportFilters } from "./filters";
import type { BBox } from "./types";

export function useReports(filters: ReportFilters, options: ListOptions = {}, enabled = true) {
  return useQuery({
    queryKey: ["reports", filters, options],
    queryFn: () => dataSource.listReports(filters, options),
    placeholderData: keepPreviousData,
    enabled,
  });
}

export function useMapReports(filters: ReportFilters, bbox: BBox | null) {
  // Page and sort don't change which markers exist, so they're excluded from the cache key.
  const markerFilters = { ...filters, page: 1, sort: "newest" as const };
  return useQuery({
    queryKey: ["map-reports", markerFilters, bbox],
    queryFn: () => dataSource.mapReports(filters, bbox),
    placeholderData: keepPreviousData,
    enabled: bbox !== null,
  });
}

export function useAreas() {
  return useQuery({ queryKey: ["areas"], queryFn: () => dataSource.getAreas(), staleTime: Infinity });
}

export function useCategories() {
  return useQuery({ queryKey: ["categories"], queryFn: () => dataSource.getCategories(), staleTime: 300_000 });
}

export function useMatches(id: string) {
  return useQuery({ queryKey: ["matches", id], queryFn: () => dataSource.getMatches(id) });
}

export function useStats(enabled = true) {
  return useQuery({ queryKey: ["stats"], queryFn: () => dataSource.getStats(), staleTime: 60_000, enabled });
}
