import { beforeEach, describe, expect, it } from "vitest";
import { DEFAULT_FILTERS } from "../filters";
import placesFile from "../mock/places.json";
import { __demo, mockSource } from "./mock-source";

const details = [...__demo.DETAILS.values()];

describe("demo dataset honesty rules", () => {
  it("marks every record and source as demo data with an unresolvable URL", () => {
    expect(details).toHaveLength(30);
    for (const d of details) {
      expect(d.is_demo).toBe(true);
      expect(d.primary_platform).toBe("DEMO");
      for (const s of d.sources) {
        expect(s.platform).toBe("DEMO");
        expect(new URL(s.original_url).hostname.endsWith(".invalid")).toBe(true);
      }
    }
  });

  it("uses only coordinates that came from an OpenStreetMap lookup", () => {
    const osmPoints = new Set(placesFile.places.map((p) => `${p.latitude},${p.longitude}`));
    for (const d of details.filter((d) => d.latitude !== null)) {
      expect(osmPoints.has(`${d.latitude},${d.longitude}`)).toBe(true);
    }
  });

  it("gives no coordinates to reports whose post has no usable location", () => {
    for (const d of details.filter((d) => d.location_precision === "CITY" || d.location_precision === "UNKNOWN")) {
      expect(d.latitude).toBeNull();
      expect(d.longitude).toBeNull();
      expect(d.location_radius_m).toBeNull();
    }
  });

  it("never exposes CNIC or phone numbers in displayed text", () => {
    for (const s of details.flatMap((d) => d.sources)) {
      expect(s.excerpt).not.toMatch(/\d{5}[-\s]?\d{7}[-\s]?\d/);
      expect(s.excerpt).not.toMatch(/(?:\+92|\b0)[-\s]?3\d{2}[-\s]?\d{7}/);
    }
  });

  it("keeps all source references for a cross-posted report", () => {
    expect(__demo.DETAILS.get("demo-001")!.source_count).toBe(2);
  });
});

describe("mockSource", () => {
  beforeEach(() => localStorage.clear());

  it("returns only mappable reports for the map, as GeoJSON [lng, lat]", async () => {
    const fc = await mockSource.mapReports(DEFAULT_FILTERS);
    expect(fc.type).toBe("FeatureCollection");
    expect(fc.features).toHaveLength(28);
    const f = fc.features.find((x) => x.properties.id === "demo-003")!;
    const d = __demo.DETAILS.get("demo-003")!;
    expect(f.geometry.coordinates).toEqual([d.longitude, d.latitude]);
  });

  it("returns null for an unknown report id", async () => {
    expect(await mockSource.getReport("nope")).toBeNull();
  });

  it("returns a copy so callers can't mutate the store", async () => {
    const r = await mockSource.getReport("demo-001");
    r!.item_name = "changed";
    expect((await mockSource.getReport("demo-001"))!.item_name).toBe("Black leather wallet");
  });

  it("finds matches in both directions with scores between 0 and 1", async () => {
    const fromLost = await mockSource.getMatches("demo-001");
    const fromFound = await mockSource.getMatches("demo-002");
    expect(fromLost.map((m) => m.report.id)).toEqual(["demo-002"]);
    expect(fromFound.map((m) => m.report.id)).toEqual(["demo-001"]);
    expect(fromLost[0].score).toBeGreaterThan(0);
    expect(fromLost[0].score).toBeLessThanOrEqual(1);
    expect(fromLost[0].breakdown.category).toBe(1);
    expect(await mockSource.getMatches("demo-010")).toEqual([]);
  });

  it("accepts one suggestion per report and type, and rejects repeats", async () => {
    const first = await mockSource.suggestStatus("demo-010", "RESOLVED", "Owner got it back");
    const again = await mockSource.suggestStatus("demo-010", "RESOLVED", "");
    const other = await mockSource.suggestStatus("demo-010", "INACCURATE", "");
    expect(first.accepted).toBe(true);
    expect(again.accepted).toBe(false);
    expect(other.accepted).toBe(true);
  });

  it("does not change the report status when a suggestion is accepted", async () => {
    await mockSource.suggestStatus("demo-011", "RESOLVED", "");
    expect((await mockSource.getReport("demo-011"))!.status).toBe("ACTIVE");
  });

  it("rejects over-long reasons", async () => {
    const res = await mockSource.suggestStatus("demo-012", "INACCURATE", "x".repeat(501));
    expect(res.accepted).toBe(false);
  });
});
