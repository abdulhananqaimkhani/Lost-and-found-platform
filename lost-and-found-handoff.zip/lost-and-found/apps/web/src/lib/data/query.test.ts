import { describe, expect, it } from "vitest";
import { DEFAULT_FILTERS, type ReportFilters } from "../filters";
import { distanceKm } from "../geo";
import { DEMO_AREAS } from "../mock/places";
import { __demo } from "./mock-source";
import { matchesText, normalizeText, queryReports } from "./query";

const NOW = Date.parse("2026-11-22T12:00:00Z");
const items = __demo.SEARCHABLE;

function run(patch: Partial<ReportFilters>, options: { bbox?: [number, number, number, number]; located?: boolean } = {}, pageSize = 100) {
  return queryReports(items, { ...DEFAULT_FILTERS, ...patch }, { now: NOW, areas: DEMO_AREAS, ...options }, pageSize);
}
const ids = (page: ReturnType<typeof run>) => page.items.map((r) => r.id).sort();

describe("text search", () => {
  it("normalizes case, hyphens and punctuation", () => {
    expect(normalizeText("Gulshan-e-Iqbal, Block 10-A!")).toBe("gulshan e iqbal block 10 a");
  });

  it("requires every token, matching word prefixes", () => {
    expect(matchesText("black leather wallet", "black wal")).toBe(true);
    expect(matchesText("black leather wallet", "brown wallet")).toBe(false);
    expect(matchesText("black leather wallet", "")).toBe(true);
  });

  it("finds wallets with the Roman Urdu word 'batwa'", () => {
    expect(ids(run({ q: "batwa" }))).toEqual(ids(run({ categories: ["WALLET"] })));
  });

  it("finds every keys report with 'chabi', including posts that mention keys inside a bag", () => {
    const found = run({ q: "chabi" }).items.map((r) => r.id);
    expect(found).toEqual(expect.arrayContaining(ids(run({ categories: ["KEYS"] }))));
    // demo-019 is a handbag post: "andar ATM cards aur ghar ki chabiyan hain".
    expect(found).toContain("demo-019");
  });

  it("finds phones with 'mobile'", () => {
    const page = run({ q: "mobile" });
    expect(ids(page)).toEqual(ids(run({ categories: ["PHONE"] })));
  });

  it("does not match on redaction placeholders (a hidden phone number is not a phone)", () => {
    // demo-001 is a wallet post whose text contained a phone number.
    expect(run({ q: "phone" }).items.map((r) => r.id)).not.toContain("demo-001");
  });

  it("searches the original post text, including Urdu script", () => {
    expect(run({ q: "کنگن" }).items.map((r) => r.id)).toEqual(["demo-009"]);
  });
});

describe("structured filters", () => {
  it("filters by report type", () => {
    const page = run({ type: "FOUND" });
    expect(page.total).toBeGreaterThan(0);
    expect(page.items.every((r) => r.report_type === "FOUND")).toBe(true);
  });

  it("filters by several categories at once", () => {
    const page = run({ categories: ["PET", "KEYS"] });
    expect(new Set(page.items.map((r) => r.item_category))).toEqual(new Set(["PET", "KEYS"]));
  });

  it("filters by status", () => {
    expect(ids(run({ statuses: ["RESOLVED", "DISPUTED"] }))).toEqual(["demo-026", "demo-027"]);
  });

  it("'Near <area>' keeps only located reports within the area radius", () => {
    const area = DEMO_AREAS.find((a) => a.key === "bahadurabad")!;
    const page = run({ area: "bahadurabad" });
    expect(page.items.map((r) => r.id)).toEqual(expect.arrayContaining(["demo-004", "demo-030"]));
    for (const r of page.items) {
      expect(distanceKm(area.latitude, area.longitude, r.latitude!, r.longitude!) * 1000).toBeLessThanOrEqual(area.radius_m);
    }
  });

  it("matches nothing for an unknown area instead of ignoring the filter", () => {
    expect(run({ area: "atlantis" }).total).toBe(0);
  });

  it("filters by posting date window", () => {
    const page = run({ date: "24h" });
    expect(ids(page)).toEqual(["demo-001", "demo-002", "demo-003", "demo-017", "demo-028", "demo-030"]);
  });

  it("filters by custom date range", () => {
    const page = run({ date: "custom", from: "2026-11-01", to: "2026-11-03" });
    expect(ids(page)).toEqual(["demo-024", "demo-026"]);
  });

  it("restricts to a bounding box and excludes unlocated reports", () => {
    const bbox: [number, number, number, number] = [67.0, 24.85, 67.08, 24.9];
    const page = run({}, { bbox });
    expect(page.total).toBeGreaterThan(0);
    for (const r of page.items) {
      expect(r.longitude!).toBeGreaterThanOrEqual(67.0);
      expect(r.latitude!).toBeLessThanOrEqual(24.9);
    }
  });

  it("separates located and unlocated reports", () => {
    expect(ids(run({}, { located: false }))).toEqual(["demo-016", "demo-017"]);
    expect(run({}, { located: true }).items.every((r) => r.latitude !== null)).toBe(true);
  });
});

describe("sorting and pagination", () => {
  it("sorts newest first by default, oldest on request", () => {
    const newest = run({}).items.map((r) => Date.parse(r.reported_at));
    expect(newest).toEqual([...newest].sort((a, b) => b - a));
    const oldest = run({ sort: "oldest" }).items.map((r) => Date.parse(r.reported_at));
    expect(oldest).toEqual([...oldest].sort((a, b) => a - b));
  });

  it("sorts by distance from a point, with unlocated reports last", () => {
    const page = run({ sort: "distance", near: { lat: 24.8606, lng: 67.0104 } });
    const distances = page.items.map((r) => r.distance_km ?? Infinity);
    expect(distances).toEqual([...distances].sort((a, b) => a - b));
    expect(page.items.slice(-2).map((r) => r.distance_km)).toEqual([null, null]);
  });

  it("uses the selected area as the distance reference", () => {
    const page = run({ sort: "distance", area: "saddar" });
    expect(page.items[0].distance_km).not.toBeUndefined();
  });

  it("paginates with a stable total", () => {
    const p1 = run({ page: 1 }, {}, 10);
    const p3 = run({ page: 3 }, {}, 10);
    const p4 = run({ page: 4 }, {}, 10);
    expect(p1.total).toBe(30);
    expect(p1.items).toHaveLength(10);
    expect(p3.items).toHaveLength(10);
    expect(p4.items).toHaveLength(0);
    expect(new Set([...p1.items, ...p3.items].map((r) => r.id)).size).toBe(20);
  });
});
