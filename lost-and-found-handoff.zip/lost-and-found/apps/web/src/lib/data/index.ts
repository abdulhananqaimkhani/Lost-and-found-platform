import { apiSource } from "./api-source";
import { mockSource } from "./mock-source";
import type { DataSource } from "./source";

export const dataSource: DataSource = process.env.NEXT_PUBLIC_DATA_SOURCE === "api" ? apiSource : mockSource;

export type { DataSource, ListOptions } from "./source";
export { DataSourceError } from "./source";
