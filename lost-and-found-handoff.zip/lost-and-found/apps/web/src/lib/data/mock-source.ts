/**
 * Mock data source backed by the clearly-labelled demo dataset.
 * Used in Phase 1 and in frontend tests. Same interface as the FastAPI source.
 */
import { DEFAULT_FILTERS, type ReportFilters } from "../filters";
import { distanceKm, isMappable } from "../geo";
import { DEMO_MATCH_PAIRS, DEMO_SEEDS, type DemoSeed } from "../mock/demo-reports";
import { DEMO_AREAS, PLACES } from "../mock/places";
import { redactText, stripRedactionMarkers } from "../redact";
import {
  ITEM_CATEGORIES,
  type BBox,
  type MapFeatureCollection,
  type MatchSummary,
  type ReportDetail,
  type SuggestionType,
} from "../types";
import { buildHaystack, queryReports, type Searchable } from "./query";
import type { DataSource, ListOptions } from "./source";

const MINUTE = 60_000;

function toDetail(seed: DemoSeed): ReportDetail {
  const place = seed.place ? PLACES[seed.place] : null;
  const precision = place ? place.precision : (seed.fallback_precision ?? "UNKNOWN");
  const mapped = place !== null && isMappable(precision);
  const sources = seed.posts.map((post, i) => ({
    id: `${seed.id}-src-${i + 1}`,
    platform: "DEMO" as const,
    original_url: `https://demo.invalid/posts/${seed.id}/${i + 1}`,
    excerpt: redactText(post.text),
    published_at: post.published_at,
    collected_at: new Date(Date.parse(post.published_at) + post.collected_after_min * MINUTE).toISOString(),
  }));
  const first = sources[0];
  const last = sources[sources.length - 1];

  return {
    id: seed.id,
    report_type: seed.type,
    item_name: seed.item,
    item_category: seed.category,
    description: seed.description,
    location_text: seed.location_text,
    city: seed.city,
    latitude: mapped ? place.latitude : null,
    longitude: mapped ? place.longitude : null,
    location_precision: precision,
    location_radius_m: mapped ? place.radius_m : null,
    incident_date: seed.incident_date,
    date_precision: seed.date_precision,
    reported_at: first.published_at,
    collected_at: first.collected_at,
    status: seed.status,
    confidence_score: seed.confidence,
    needs_review: seed.needs_review ?? false,
    language: seed.language,
    primary_platform: "DEMO",
    source_count: sources.length,
    is_demo: true,
    attributes: { colour: seed.colour ?? null, brand: seed.brand ?? null },
    sources,
    suggestion_counts: { ...(seed.suggestions ?? { RESOLVED: 0, INACCURATE: 0 }) },
    created_at: first.collected_at,
    updated_at: last.collected_at,
  };
}

function summaryOf(detail: ReportDetail) {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { attributes, sources, suggestion_counts, created_at, updated_at, ...summary } = detail;
  return summary;
}

const DETAILS = new Map(DEMO_SEEDS.map((s) => [s.id, toDetail(s)]));
const SEARCHABLE: Searchable[] = [...DETAILS.values()].map((d) => ({
  summary: summaryOf(d),
  haystack: buildHaystack(
    summaryOf(d),
    d.sources.map((s) => stripRedactionMarkers(s.excerpt)),
  ),
}));

const SUGGESTION_STORAGE_KEY = "lf-demo-suggestions";

function readSentSuggestions(): string[] {
  try {
    return JSON.parse(globalThis.localStorage?.getItem(SUGGESTION_STORAGE_KEY) ?? "[]");
  } catch {
    return [];
  }
}

function rememberSuggestion(key: string) {
  try {
    const sent = readSentSuggestions();
    globalThis.localStorage?.setItem(SUGGESTION_STORAGE_KEY, JSON.stringify([...sent, key]));
  } catch {
    // Storage unavailable (private mode): the in-memory guard below still applies for this session.
  }
}

const sentThisSession = new Set<string>();

/** Demo-only match scoring: same weights as the planned backend engine (PROJECT_PLAN.md §11). */
function scorePair(a: ReportDetail, b: ReportDetail, textSimilarity: number) {
  const distance =
    a.latitude !== null && b.latitude !== null
      ? distanceKm(a.latitude, a.longitude!, b.latitude, b.longitude!)
      : null;
  const dayA = Date.parse(a.incident_date ?? a.reported_at);
  const dayB = Date.parse(b.incident_date ?? b.reported_at);
  const daysApart = Math.round(Math.abs(dayA - dayB) / 86_400_000);
  const colourA = a.attributes.colour;
  const colourB = b.attributes.colour;
  const breakdown = {
    category: a.item_category === b.item_category ? 1 : 0,
    text: textSimilarity,
    distance: distance === null ? 0.3 : Math.max(0, 1 - distance / 5),
    date: Math.max(0, 1 - daysApart / 14),
    attributes: colourA && colourB ? (colourA === colourB ? 1 : 0) : 0.5,
  };
  const score =
    0.3 * breakdown.category +
    0.3 * breakdown.text +
    0.2 * breakdown.distance +
    0.1 * breakdown.date +
    0.1 * breakdown.attributes;
  return { score, breakdown, distance_km: distance, days_apart: daysApart };
}

export const mockSource: DataSource = {
  kind: "mock",

  async listReports(filters: ReportFilters, options: ListOptions = {}) {
    return queryReports(
      SEARCHABLE,
      filters,
      { now: Date.now(), areas: DEMO_AREAS, bbox: options.bbox, located: options.located },
      options.pageSize ?? 20,
    );
  },

  async mapReports(filters: ReportFilters, bbox?: BBox | null): Promise<MapFeatureCollection> {
    const page = queryReports(
      SEARCHABLE,
      { ...filters, page: 1, sort: "newest" },
      { now: Date.now(), areas: DEMO_AREAS, bbox, located: true },
      2000,
    );
    return {
      type: "FeatureCollection",
      features: page.items.map((r) => ({
        type: "Feature",
        geometry: { type: "Point", coordinates: [r.longitude!, r.latitude!] },
        properties: {
          id: r.id,
          report_type: r.report_type,
          item_name: r.item_name,
          item_category: r.item_category,
          description: r.description,
          location_text: r.location_text,
          location_precision: r.location_precision,
          location_radius_m: r.location_radius_m,
          status: r.status,
          reported_at: r.reported_at,
          primary_platform: r.primary_platform,
        },
      })),
    };
  },

  async getReport(id: string) {
    const detail = DETAILS.get(id);
    return detail ? structuredClone(detail) : null;
  },

  async getMatches(id: string): Promise<MatchSummary[]> {
    const results: MatchSummary[] = [];
    for (const [lostId, foundId, text] of DEMO_MATCH_PAIRS) {
      if (id !== lostId && id !== foundId) continue;
      const self = DETAILS.get(id)!;
      const other = DETAILS.get(id === lostId ? foundId : lostId)!;
      results.push({ report: summaryOf(other), ...scorePair(self, other, text) });
    }
    return results.sort((a, b) => b.score - a.score);
  },

  async getCategories() {
    return ITEM_CATEGORIES.map((category) => ({
      category,
      count: SEARCHABLE.filter((s) => s.summary.item_category === category).length,
    }));
  },

  async getAreas() {
    return DEMO_AREAS;
  },

  async getStats() {
    const all = SEARCHABLE.map((s) => s.summary);
    return {
      total: all.length,
      lost: all.filter((r) => r.report_type === "LOST").length,
      found: all.filter((r) => r.report_type === "FOUND").length,
      mapped: all.filter((r) => r.latitude !== null).length,
      by_platform: { DEMO: all.length },
      last_collected_at: all.map((r) => r.collected_at).sort().at(-1) ?? null,
    };
  },

  async suggestStatus(id: string, type: SuggestionType, reason: string) {
    const detail = DETAILS.get(id);
    if (!detail) return { accepted: false, message: "This report no longer exists." };
    const key = `${id}:${type}`;
    if (sentThisSession.has(key) || readSentSuggestions().includes(key)) {
      return { accepted: false, message: "You've already sent this suggestion for this report." };
    }
    if (reason.length > 500) return { accepted: false, message: "Keep the reason under 500 characters." };
    sentThisSession.add(key);
    rememberSuggestion(key);
    detail.suggestion_counts[type] += 1;
    return {
      accepted: true,
      message: "Suggestion recorded. The listing's status stays the same until it's verified.",
    };
  },
};

/** Exposed for tests. */
export const __demo = { DETAILS, SEARCHABLE, DEFAULT_FILTERS };
