/**
 * Pure, in-memory implementation of the report query semantics.
 * The mock data source uses it directly; the FastAPI backend implements the same semantics in SQL
 * (PostGIS for bbox/distance, tsvector + pg_trgm for text). Unit tests pin the behaviour down.
 */
import { dateWindow, type ReportFilters } from "../filters";
import { bboxContains, distanceKm } from "../geo";
import { CATEGORY_LABEL } from "../labels";
import type { Area, BBox, Page, ReportSummary } from "../types";

export interface Searchable {
  summary: ReportSummary;
  /** Lower-cased, normalized text of the report plus its source posts. */
  haystack: string;
}

export interface QueryOptions {
  now: number;
  areas: Area[];
  bbox?: BBox | null;
  /** true → only reports with coordinates; false → only reports without. */
  located?: boolean | null;
}

/**
 * Common English ↔ Roman Urdu item words, so "batwa" finds wallets and "chabi" finds keys.
 * Deliberately small: the AI pipeline (Phase 3) normalizes categories; this only helps free-text search.
 */
const SYNONYMS: string[][] = [
  ["wallet", "batwa", "purse"],
  ["phone", "mobile", "cell", "fone"],
  ["keys", "key", "chabi", "chabiyan", "chaabi"],
  ["bag", "backpack", "basta", "handbag"],
  ["cnic", "id", "shanakhti"],
  ["cat", "billi"],
  ["dog", "kutta"],
  ["lost", "gum", "kho", "missing"],
  ["found", "mila", "mili", "mil"],
];

export function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

function expandToken(token: string): string[] {
  const group = SYNONYMS.find((g) => g.includes(token));
  return group ?? [token];
}

export function buildHaystack(summary: ReportSummary, sourceTexts: string[]): string {
  return normalizeText(
    [
      summary.item_name,
      summary.description ?? "",
      summary.location_text ?? "",
      summary.city ?? "",
      CATEGORY_LABEL[summary.item_category],
      ...sourceTexts,
    ].join(" "),
  );
}

/** Every query token (or one of its synonyms) must appear as a word prefix in the haystack. */
export function matchesText(haystack: string, query: string): boolean {
  const tokens = normalizeText(query).split(" ").filter(Boolean);
  if (!tokens.length) return true;
  const words = ` ${haystack}`;
  return tokens.every((t) => expandToken(t).some((alt) => words.includes(` ${alt}`)));
}

export function referencePoint(
  filters: ReportFilters,
  areas: Area[],
): { lat: number; lng: number } | null {
  if (filters.near) return filters.near;
  const area = filters.area ? areas.find((a) => a.key === filters.area) : undefined;
  return area ? { lat: area.latitude, lng: area.longitude } : null;
}

export function matchesFilters(item: Searchable, filters: ReportFilters, options: QueryOptions): boolean {
  const r = item.summary;
  if (filters.type && r.report_type !== filters.type) return false;
  if (filters.categories.length && !filters.categories.includes(r.item_category)) return false;
  if (filters.statuses.length && !filters.statuses.includes(r.status)) return false;

  const window = dateWindow(filters, options.now);
  if (window) {
    const t = Date.parse(r.reported_at);
    if (t < window[0] || t > window[1]) return false;
  }

  const hasCoords = r.latitude !== null && r.longitude !== null;
  if (options.located === true && !hasCoords) return false;
  if (options.located === false && hasCoords) return false;

  if (filters.area) {
    const area = options.areas.find((a) => a.key === filters.area);
    // An unknown area key matches nothing rather than silently matching everything.
    if (!area || !hasCoords) return false;
    if (distanceKm(area.latitude, area.longitude, r.latitude!, r.longitude!) * 1000 > area.radius_m) return false;
  }

  if (options.bbox && (!hasCoords || !bboxContains(options.bbox, r.latitude!, r.longitude!))) return false;

  return matchesText(item.haystack, filters.q);
}

export function queryReports(
  items: Searchable[],
  filters: ReportFilters,
  options: QueryOptions,
  pageSize = 20,
): Page<ReportSummary> {
  const ref = referencePoint(filters, options.areas);
  const matched = items
    .filter((item) => matchesFilters(item, filters, options))
    .map((item) => {
      const r = item.summary;
      const distance =
        ref && r.latitude !== null && r.longitude !== null
          ? distanceKm(ref.lat, ref.lng, r.latitude, r.longitude)
          : null;
      return ref ? { ...r, distance_km: distance } : r;
    });

  const byTime = (a: ReportSummary, b: ReportSummary) => Date.parse(b.reported_at) - Date.parse(a.reported_at);
  if (filters.sort === "oldest") matched.sort((a, b) => -byTime(a, b));
  else if (filters.sort === "distance" && ref) {
    // Reports without a location go last; ties fall back to newest first.
    matched.sort((a, b) => {
      const da = a.distance_km ?? Number.POSITIVE_INFINITY;
      const db = b.distance_km ?? Number.POSITIVE_INFINITY;
      return da === db ? byTime(a, b) : da - db;
    });
  } else matched.sort(byTime);

  const page = Math.max(1, filters.page);
  const start = (page - 1) * pageSize;
  return { items: matched.slice(start, start + pageSize), total: matched.length, page, page_size: pageSize };
}
