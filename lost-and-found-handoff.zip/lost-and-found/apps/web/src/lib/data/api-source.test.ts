import { afterEach, describe, expect, it, vi } from "vitest";
import { DEFAULT_FILTERS } from "../filters";
import { apiSource, filtersToQuery } from "./api-source";
import { DataSourceError } from "./source";

describe("filtersToQuery", () => {
  it("maps UI filters to the backend's query parameters", () => {
    const now = Date.parse("2026-11-22T12:00:00Z");
    const qs = filtersToQuery(
      {
        ...DEFAULT_FILTERS,
        q: " wallet ",
        type: "LOST",
        categories: ["WALLET", "BAG"],
        date: "24h",
        sort: "distance",
        near: { lat: 24.9, lng: 67.1 },
        page: 2,
      },
      { bbox: [67, 24.8, 67.2, 25], located: true, pageSize: 50 },
      now,
    );
    expect(Object.fromEntries(qs)).toEqual({
      q: "wallet",
      type: "LOST",
      category: "WALLET,BAG",
      date_from: "2026-11-21T12:00:00.000Z",
      date_to: "2026-11-22T12:00:00.000Z",
      near_lat: "24.9",
      near_lng: "67.1",
      sort: "distance",
      page: "2",
      page_size: "50",
      bbox: "67.00000,24.80000,67.20000,25.00000",
      has_location: "true",
    });
  });

  it("omits open-ended custom date bounds", () => {
    const qs = filtersToQuery({ ...DEFAULT_FILTERS, date: "custom", from: "2026-11-01" });
    expect(qs.get("date_from")).toBe("2026-11-01T00:00:00.000Z");
    expect(qs.has("date_to")).toBe(false);
  });
});

describe("apiSource error handling", () => {
  afterEach(() => vi.unstubAllGlobals());

  it("surfaces the backend's error message", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        new Response(JSON.stringify({ error: { code: "rate_limited", message: "Too many suggestions. Try again later." } }), {
          status: 429,
        }),
      ),
    );
    await expect(apiSource.suggestStatus("x", "RESOLVED", "")).rejects.toMatchObject({
      status: 429,
      code: "rate_limited",
      message: "Too many suggestions. Try again later.",
    });
  });

  it("maps 404 to null for report details", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response("{}", { status: 404 })));
    expect(await apiSource.getReport("missing")).toBeNull();
  });

  it("explains network failures in plain language", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new TypeError("fetch failed")));
    const error = await apiSource.getStats().catch((e) => e);
    expect(error).toBeInstanceOf(DataSourceError);
    expect(error.message).toMatch(/Can't reach the Lost & Found server/);
  });
});
