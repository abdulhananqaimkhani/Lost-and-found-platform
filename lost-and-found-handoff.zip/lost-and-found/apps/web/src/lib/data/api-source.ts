/**
 * FastAPI-backed data source (activated in Phase 2 with NEXT_PUBLIC_DATA_SOURCE=api).
 * In the browser, requests go to same-origin /api/* which Next.js rewrites to the backend.
 * On the server, they go straight to API_INTERNAL_URL.
 */
import { dateWindow, type ReportFilters } from "../filters";
import type {
  Area,
  BBox,
  CategoryCount,
  MapFeatureCollection,
  MatchSummary,
  Page,
  ReportDetail,
  ReportSummary,
  Stats,
  SuggestionResult,
  SuggestionType,
} from "../types";
import { DataSourceError, type DataSource, type ListOptions } from "./source";

const REQUEST_TIMEOUT_MS = 10_000;

function baseUrl(): string {
  if (typeof window !== "undefined") return "";
  return process.env.API_INTERNAL_URL ?? "http://127.0.0.1:8000";
}

export function filtersToQuery(filters: ReportFilters, options: ListOptions = {}, now = Date.now()) {
  const params = new URLSearchParams();
  if (filters.q.trim()) params.set("q", filters.q.trim());
  if (filters.type) params.set("type", filters.type);
  if (filters.categories.length) params.set("category", filters.categories.join(","));
  if (filters.statuses.length) params.set("status", filters.statuses.join(","));
  if (filters.area) params.set("area", filters.area);
  const window = dateWindow(filters, now);
  if (window) {
    if (Number.isFinite(window[0])) params.set("date_from", new Date(window[0]).toISOString());
    if (Number.isFinite(window[1])) params.set("date_to", new Date(window[1]).toISOString());
  }
  if (filters.near) {
    params.set("near_lat", String(filters.near.lat));
    params.set("near_lng", String(filters.near.lng));
  }
  params.set("sort", filters.sort);
  params.set("page", String(filters.page));
  if (options.pageSize) params.set("page_size", String(options.pageSize));
  if (options.bbox) params.set("bbox", options.bbox.map((v) => v.toFixed(5)).join(","));
  if (options.located !== undefined && options.located !== null) params.set("has_location", String(options.located));
  return params;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${baseUrl()}${path}`, {
      ...init,
      headers: { Accept: "application/json", ...(init?.body ? { "Content-Type": "application/json" } : {}) },
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
  } catch {
    throw new DataSourceError("Can't reach the Lost & Found server. Check that the backend is running.", 0, "network");
  }
  if (!response.ok) {
    let message = `Request failed (${response.status}).`;
    let code = "error";
    try {
      const body = await response.json();
      message = body?.error?.message ?? message;
      code = body?.error?.code ?? code;
    } catch {
      // Non-JSON error body: keep the generic message.
    }
    throw new DataSourceError(message, response.status, code);
  }
  return response.json() as Promise<T>;
}

export const apiSource: DataSource = {
  kind: "api",
  listReports: (filters, options) =>
    request<Page<ReportSummary>>(`/api/reports?${filtersToQuery(filters, options)}`),
  mapReports: (filters, bbox?: BBox | null) =>
    request<MapFeatureCollection>(`/api/map/reports?${filtersToQuery(filters, { bbox })}`),
  async getReport(id) {
    try {
      return await request<ReportDetail>(`/api/reports/${encodeURIComponent(id)}`);
    } catch (error) {
      if (error instanceof DataSourceError && error.status === 404) return null;
      throw error;
    }
  },
  getMatches: (id) => request<MatchSummary[]>(`/api/reports/${encodeURIComponent(id)}/matches`),
  getCategories: () => request<CategoryCount[]>("/api/categories"),
  getAreas: () => request<Area[]>("/api/areas"),
  getStats: () => request<Stats>("/api/stats"),
  suggestStatus: (id, type: SuggestionType, reason) =>
    request<SuggestionResult>(`/api/reports/${encodeURIComponent(id)}/resolution-suggestions`, {
      method: "POST",
      body: JSON.stringify({ suggested_status: type, reason }),
    }),
};
