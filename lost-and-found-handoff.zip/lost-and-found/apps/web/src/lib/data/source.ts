import type { ReportFilters } from "../filters";
import type {
  Area,
  BBox,
  CategoryCount,
  MapFeatureCollection,
  MatchSummary,
  Page,
  ReportDetail,
  ReportSummary,
  Stats,
  SuggestionResult,
  SuggestionType,
} from "../types";

export interface ListOptions {
  bbox?: BBox | null;
  /** true → only reports with map coordinates; false → only reports without. */
  located?: boolean | null;
  pageSize?: number;
}

/**
 * The single seam between the UI and its data. Phase 1 uses the mock implementation;
 * Phase 2 switches to the FastAPI implementation by setting NEXT_PUBLIC_DATA_SOURCE=api.
 */
export interface DataSource {
  readonly kind: "mock" | "api";
  listReports(filters: ReportFilters, options?: ListOptions): Promise<Page<ReportSummary>>;
  mapReports(filters: ReportFilters, bbox?: BBox | null): Promise<MapFeatureCollection>;
  getReport(id: string): Promise<ReportDetail | null>;
  getMatches(id: string): Promise<MatchSummary[]>;
  getCategories(): Promise<CategoryCount[]>;
  getAreas(): Promise<Area[]>;
  getStats(): Promise<Stats>;
  suggestStatus(id: string, type: SuggestionType, reason: string): Promise<SuggestionResult>;
}

export class DataSourceError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code: string = "error",
  ) {
    super(message);
    this.name = "DataSourceError";
  }
}
