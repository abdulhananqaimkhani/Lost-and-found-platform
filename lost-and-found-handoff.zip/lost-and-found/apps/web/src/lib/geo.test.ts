import { describe, expect, it } from "vitest";
import { bboxContains, distanceKm, focusZoom, isAreaPrecision, isMappable, padBBox } from "./geo";

describe("distanceKm", () => {
  it("is zero for the same point", () => {
    expect(distanceKm(24.86, 67.0, 24.86, 67.0)).toBe(0);
  });

  it("matches a known distance: one degree of latitude ≈ 111.2 km", () => {
    expect(distanceKm(24, 67, 25, 67)).toBeCloseTo(111.2, 0);
  });

  it("is symmetric", () => {
    expect(distanceKm(24.8, 67.0, 24.9, 67.1)).toBeCloseTo(distanceKm(24.9, 67.1, 24.8, 67.0), 10);
  });
});

describe("bbox helpers", () => {
  const box: [number, number, number, number] = [67.0, 24.8, 67.2, 25.0];

  it("checks containment, including edges", () => {
    expect(bboxContains(box, 24.9, 67.1)).toBe(true);
    expect(bboxContains(box, 24.8, 67.0)).toBe(true);
    expect(bboxContains(box, 25.1, 67.1)).toBe(false);
  });

  it("pads proportionally on every side", () => {
    const [w, s, e, n] = padBBox(box, 0.5);
    expect(w).toBeCloseTo(66.9);
    expect(s).toBeCloseTo(24.7);
    expect(e).toBeCloseTo(67.3);
    expect(n).toBeCloseTo(25.1);
  });
});

describe("precision rules", () => {
  it("only maps POI, street and neighbourhood precision", () => {
    expect(isMappable("POI")).toBe(true);
    expect(isMappable("STREET")).toBe(true);
    expect(isMappable("NEIGHBOURHOOD")).toBe(true);
    expect(isMappable("CITY")).toBe(false);
    expect(isMappable("UNKNOWN")).toBe(false);
  });

  it("draws neighbourhoods as areas, never pins", () => {
    expect(isAreaPrecision("NEIGHBOURHOOD")).toBe(true);
    expect(isAreaPrecision("POI")).toBe(false);
  });

  it("zooms out further for larger, less precise areas", () => {
    expect(focusZoom("POI", 120)).toBeGreaterThan(focusZoom("NEIGHBOURHOOD", 400));
    expect(focusZoom("NEIGHBOURHOOD", 400)).toBeGreaterThan(focusZoom("NEIGHBOURHOOD", 2500));
  });
});
