/** The demo dataset in the shape the backend seeder reads (see scripts/export-demo-data.mts). */
import { DEMO_MATCH_PAIRS, DEMO_SEEDS } from "./demo-reports";
import { DEMO_AREAS, OSM_ATTRIBUTION, PLACES } from "./places";

export function buildDemoExport() {
  const labels = new Map(DEMO_AREAS.map((a) => [a.key, a.label]));
  return {
    notice:
      "DEMO DATA: synthetic, hand-written posts for development and the FYP demo. None of these posts exist. " +
      "Place coordinates come from OpenStreetMap lookups.",
    attribution: OSM_ATTRIBUTION,
    places: Object.values(PLACES).map((p) => ({ ...p, label: labels.get(p.key) ?? p.name })),
    reports: DEMO_SEEDS,
    match_pairs: DEMO_MATCH_PAIRS,
  };
}
