import placesFile from "./places.json";
import type { Area, LocationPrecision } from "../types";

export interface Place {
  key: string;
  name: string;
  display_name: string;
  latitude: number;
  longitude: number;
  osm_type: string;
  osm_id: number;
  precision: LocationPrecision;
  radius_m: number | null;
}

export type PlaceKey = (typeof placesFile.places)[number]["key"];

export const PLACES: Record<string, Place> = Object.fromEntries(
  placesFile.places.map((p) => [p.key, p as Place]),
);

export const OSM_ATTRIBUTION = placesFile.attribution;

/**
 * Human-friendly labels for the "Near" filter. OSM names are kept as provenance but
 * some are administrative ("Gulshan-e-Iqbal Town") or name a shop inside a mall.
 */
const AREA_LABELS: Record<string, string> = {
  "gulshan-block-10a": "Gulshan-e-Iqbal Block 10-A",
  "gulshan-e-iqbal": "Gulshan-e-Iqbal",
  bahadurabad: "Bahadurabad",
  "lucky-one-mall": "Lucky One Mall",
  "ned-university": "NED University",
  "dha-phase-6": "DHA Phase 6",
  saddar: "Saddar",
  "tariq-road": "Tariq Road",
  clifton: "Clifton",
  "dolmen-mall-clifton": "Dolmen Mall Clifton",
  "university-of-karachi": "University of Karachi",
  "jinnah-airport": "Jinnah International Airport",
  "north-nazimabad": "North Nazimabad",
  pechs: "PECHS",
  korangi: "Korangi",
  malir: "Malir",
  "gulistan-e-jauhar": "Gulistan-e-Jauhar",
  nazimabad: "Nazimabad",
  "empress-market": "Empress Market",
  "frere-hall": "Frere Hall",
  zamzama: "Zamzama",
  "port-grand": "Port Grand",
  "aga-khan-hospital": "Aga Khan University Hospital",
  "millennium-mall": "Millennium Mall",
  "sea-view": "Sea View",
  "cantt-station": "Karachi Cantonment Station",
};

/** "Near X" means within this distance of the place's centre (or its own radius if larger). */
export const MIN_AREA_FILTER_RADIUS_M = 1500;

export const DEMO_AREAS: Area[] = Object.values(PLACES)
  .map((p) => ({
    key: p.key,
    label: AREA_LABELS[p.key] ?? p.name,
    latitude: p.latitude,
    longitude: p.longitude,
    radius_m: Math.max(p.radius_m ?? 0, MIN_AREA_FILTER_RADIUS_M),
  }))
  .sort((a, b) => a.label.localeCompare(b.label));
