import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { buildDemoExport } from "./demo-export";

describe("demo dataset export", () => {
  it("database/schema/demo_dataset.json matches the TypeScript demo data", () => {
    const file = resolve(__dirname, "../../../../../database/schema/demo_dataset.json");
    const exported = JSON.parse(readFileSync(file, "utf8"));
    // If this fails, run: npx tsx scripts/export-demo-data.mts
    expect(exported).toEqual(JSON.parse(JSON.stringify(buildDemoExport())));
  });
});
