import { describe, expect, it } from "vitest";
import { DEFAULT_FILTERS, countActiveFilters, dateWindow, parseFilters, serializeFilters } from "./filters";

const parse = (qs: string) => parseFilters(new URLSearchParams(qs));

describe("parseFilters", () => {
  it("returns defaults for an empty query string", () => {
    expect(parse("")).toEqual(DEFAULT_FILTERS);
  });

  it("parses every supported parameter", () => {
    const f = parse(
      "q=black+wallet&type=found&cat=WALLET,phone&status=ACTIVE&area=bahadurabad&date=custom&from=2026-11-01&to=2026-11-20&sort=distance&near=24.88,67.06&page=3",
    );
    expect(f).toEqual({
      q: "black wallet",
      type: "FOUND",
      categories: ["WALLET", "PHONE"],
      statuses: ["ACTIVE"],
      area: "bahadurabad",
      date: "custom",
      from: "2026-11-01",
      to: "2026-11-20",
      sort: "distance",
      near: { lat: 24.88, lng: 67.06 },
      page: 3,
    });
  });

  it("ignores invalid values instead of throwing", () => {
    const f = parse("type=MAYBE&cat=SPACESHIP&date=yesterday&from=22-11-2026&sort=random&near=abc&page=-4");
    expect(f.type).toBeNull();
    expect(f.categories).toEqual([]);
    expect(f.date).toBe("any");
    expect(f.from).toBeNull();
    expect(f.sort).toBe("newest");
    expect(f.near).toBeNull();
    expect(f.page).toBe(1);
  });

  it("rejects out-of-range coordinates and caps query length", () => {
    expect(parse("near=95,67").near).toBeNull();
    expect(parse(`q=${"a".repeat(500)}`).q).toHaveLength(120);
  });
});

describe("serializeFilters", () => {
  it("omits defaults so URLs stay short", () => {
    expect(serializeFilters(DEFAULT_FILTERS).toString()).toBe("");
  });

  it("round-trips through parseFilters", () => {
    const original = parse("q=mobile&type=LOST&cat=PHONE&area=saddar&date=7d&sort=oldest&page=2");
    expect(parse(serializeFilters(original).toString())).toEqual(original);
  });

  it("drops custom dates unless the custom preset is selected", () => {
    const qs = serializeFilters({ ...DEFAULT_FILTERS, date: "7d", from: "2026-11-01" }).toString();
    expect(qs).toBe("date=7d");
  });
});

describe("countActiveFilters", () => {
  it("counts user-facing filters but not sort or page", () => {
    expect(countActiveFilters({ ...DEFAULT_FILTERS, sort: "oldest", page: 4 })).toBe(0);
    expect(countActiveFilters({ ...DEFAULT_FILTERS, q: "cnic", type: "LOST", categories: ["WALLET", "BAG"] })).toBe(3);
  });
});

describe("dateWindow", () => {
  const now = Date.parse("2026-11-22T12:00:00Z");

  it("returns null for any time", () => {
    expect(dateWindow({ date: "any", from: null, to: null }, now)).toBeNull();
  });

  it("computes rolling windows", () => {
    expect(dateWindow({ date: "24h", from: null, to: null }, now)).toEqual([now - 86_400_000, now]);
    expect(dateWindow({ date: "7d", from: null, to: null }, now)![0]).toBe(now - 7 * 86_400_000);
  });

  it("makes custom ranges inclusive of the whole end day, and open-ended when a bound is missing", () => {
    const [start, end] = dateWindow({ date: "custom", from: "2026-11-01", to: "2026-11-02" }, now)!;
    expect(new Date(start).toISOString()).toBe("2026-11-01T00:00:00.000Z");
    expect(new Date(end).toISOString()).toBe("2026-11-02T23:59:59.000Z");
    expect(dateWindow({ date: "custom", from: null, to: null }, now)).toEqual([-Infinity, Infinity]);
  });
});
