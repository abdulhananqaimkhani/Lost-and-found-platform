/**
 * Report filters and their URL representation.
 * Filters live in the URL so views are shareable and browser back/forward works.
 */
import {
  ITEM_CATEGORIES,
  REPORT_STATUSES,
  REPORT_TYPES,
  type ItemCategory,
  type ReportStatus,
  type ReportType,
} from "./types";

export const DATE_PRESETS = ["any", "24h", "7d", "30d", "custom"] as const;
export type DatePreset = (typeof DATE_PRESETS)[number];

export const SORT_OPTIONS = ["newest", "oldest", "distance"] as const;
export type SortOption = (typeof SORT_OPTIONS)[number];

export interface ReportFilters {
  q: string;
  type: ReportType | null;
  categories: ItemCategory[];
  statuses: ReportStatus[];
  /** Area key; restricts results to reports near that area. */
  area: string | null;
  date: DatePreset;
  /** ISO dates (YYYY-MM-DD), used when date === "custom". */
  from: string | null;
  to: string | null;
  sort: SortOption;
  /** Reference point for distance sorting ("lat,lng"), e.g. from "Use my location". */
  near: { lat: number; lng: number } | null;
  page: number;
}

export const DEFAULT_FILTERS: ReportFilters = {
  q: "",
  type: null,
  categories: [],
  statuses: [],
  area: null,
  date: "any",
  from: null,
  to: null,
  sort: "newest",
  near: null,
  page: 1,
};

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const MAX_QUERY_LENGTH = 120;

function pickList<T extends string>(raw: string | null, allowed: readonly T[]): T[] {
  if (!raw) return [];
  const values = raw.split(",").map((v) => v.trim().toUpperCase());
  return allowed.filter((a) => values.includes(a));
}

function parseNear(raw: string | null): ReportFilters["near"] {
  if (!raw) return null;
  const [lat, lng] = raw.split(",").map(Number);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  return { lat, lng };
}

/** Parse URL search params into filters. Unknown or invalid values are ignored, never thrown. */
export function parseFilters(params: URLSearchParams): ReportFilters {
  const type = params.get("type")?.toUpperCase();
  const date = params.get("date") as DatePreset | null;
  const sort = params.get("sort") as SortOption | null;
  const page = Number.parseInt(params.get("page") ?? "1", 10);
  const from = params.get("from");
  const to = params.get("to");

  return {
    q: (params.get("q") ?? "").slice(0, MAX_QUERY_LENGTH),
    type: REPORT_TYPES.includes(type as ReportType) ? (type as ReportType) : null,
    categories: pickList(params.get("cat"), ITEM_CATEGORIES),
    statuses: pickList(params.get("status"), REPORT_STATUSES),
    area: params.get("area") || null,
    date: date && DATE_PRESETS.includes(date) ? date : "any",
    from: from && ISO_DATE.test(from) ? from : null,
    to: to && ISO_DATE.test(to) ? to : null,
    sort: sort && SORT_OPTIONS.includes(sort) ? sort : "newest",
    near: parseNear(params.get("near")),
    page: Number.isFinite(page) && page > 0 ? page : 1,
  };
}

/** Serialize filters to URL search params, omitting defaults to keep URLs short. */
export function serializeFilters(filters: ReportFilters): URLSearchParams {
  const params = new URLSearchParams();
  const q = filters.q.trim();
  if (q) params.set("q", q);
  if (filters.type) params.set("type", filters.type);
  if (filters.categories.length) params.set("cat", filters.categories.join(","));
  if (filters.statuses.length) params.set("status", filters.statuses.join(","));
  if (filters.area) params.set("area", filters.area);
  if (filters.date !== "any") params.set("date", filters.date);
  if (filters.date === "custom") {
    if (filters.from) params.set("from", filters.from);
    if (filters.to) params.set("to", filters.to);
  }
  if (filters.sort !== "newest") params.set("sort", filters.sort);
  if (filters.near) params.set("near", `${filters.near.lat.toFixed(5)},${filters.near.lng.toFixed(5)}`);
  if (filters.page > 1) params.set("page", String(filters.page));
  return params;
}

/** Number of user-facing filters that differ from the defaults (sort and page excluded). */
export function countActiveFilters(filters: ReportFilters): number {
  let count = 0;
  if (filters.q.trim()) count++;
  if (filters.type) count++;
  if (filters.categories.length) count++;
  if (filters.statuses.length) count++;
  if (filters.area) count++;
  if (filters.date !== "any") count++;
  return count;
}

/** Inclusive [start, end] timestamp window (ms) for a date preset, or null for "any". */
export function dateWindow(
  filters: Pick<ReportFilters, "date" | "from" | "to">,
  now: number,
): [number, number] | null {
  const DAY = 86_400_000;
  switch (filters.date) {
    case "24h":
      return [now - DAY, now];
    case "7d":
      return [now - 7 * DAY, now];
    case "30d":
      return [now - 30 * DAY, now];
    case "custom": {
      const start = filters.from ? Date.parse(`${filters.from}T00:00:00Z`) : Number.NEGATIVE_INFINITY;
      const end = filters.to ? Date.parse(`${filters.to}T23:59:59Z`) : Number.POSITIVE_INFINITY;
      return [start, end];
    }
    default:
      return null;
  }
}
