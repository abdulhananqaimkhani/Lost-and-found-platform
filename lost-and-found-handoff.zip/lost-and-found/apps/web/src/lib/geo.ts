import type { BBox, LocationPrecision } from "./types";

const EARTH_RADIUS_KM = 6371.0088;

/** Great-circle distance in kilometres (haversine). */
export function distanceKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(a)));
}

export function bboxContains([west, south, east, north]: BBox, lat: number, lng: number): boolean {
  return lat >= south && lat <= north && lng >= west && lng <= east;
}

/** Expand a bbox by a fraction of its size on every side (used to prefetch markers just off-screen). */
export function padBBox([west, south, east, north]: BBox, ratio: number): BBox {
  const dx = (east - west) * ratio;
  const dy = (north - south) * ratio;
  return [west - dx, south - dy, east + dx, north + dy];
}

/** Whether a report with this precision is placed on the map at all. */
export function isMappable(precision: LocationPrecision): boolean {
  return precision === "POI" || precision === "STREET" || precision === "NEIGHBOURHOOD";
}

/** Approximate locations are drawn as areas, never as exact pins. */
export function isAreaPrecision(precision: LocationPrecision): boolean {
  return precision === "NEIGHBOURHOOD";
}

/** Zoom level to use when focusing a report, so the user sees an honest amount of context. */
export function focusZoom(precision: LocationPrecision, radiusM: number | null): number {
  if (precision === "POI") return 16;
  if (precision === "STREET") return 15;
  if (radiusM && radiusM > 1500) return 13;
  return 14;
}

/** Initial map view: central Karachi. */
export const KARACHI_CENTER: [number, number] = [24.8915, 67.0711];
export const KARACHI_ZOOM = 11;
/** Loose bounds so users can't pan the map far away from the covered city. */
export const KARACHI_MAX_BOUNDS: [[number, number], [number, number]] = [
  [24.55, 66.6],
  [25.3, 67.6],
];
