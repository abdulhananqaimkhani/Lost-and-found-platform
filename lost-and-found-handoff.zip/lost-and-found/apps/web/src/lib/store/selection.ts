/**
 * Shared selection state that keeps the map and the list synchronized.
 *
 * - `origin` records where a selection came from, so each side reacts appropriately:
 *   a list click makes the map fly to the report; a marker click makes the list scroll to it.
 * - `nonce` increments on every selection, so re-clicking the same list item re-centres the map.
 */
import { create } from "zustand";

export type SelectionOrigin = "list" | "map" | "url";

interface SelectionState {
  selectedId: string | null;
  origin: SelectionOrigin | null;
  nonce: number;
  hoveredId: string | null;
  hoverOrigin: SelectionOrigin | null;
  select: (id: string, origin: SelectionOrigin) => void;
  clearSelection: () => void;
  hover: (id: string | null, origin: SelectionOrigin) => void;
}

export const useSelection = create<SelectionState>((set) => ({
  selectedId: null,
  origin: null,
  nonce: 0,
  hoveredId: null,
  hoverOrigin: null,
  select: (id, origin) => set((s) => ({ selectedId: id, origin, nonce: s.nonce + 1 })),
  clearSelection: () => set({ selectedId: null, origin: null }),
  hover: (id, origin) => set({ hoveredId: id, hoverOrigin: id ? origin : null }),
}));
