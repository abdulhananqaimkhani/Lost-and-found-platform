/**
 * Domain types shared by the UI and both data sources (mock + FastAPI).
 * These mirror the API contract described in PROJECT_PLAN.md §8; the backend's
 * Pydantic response models will use the same field names.
 */

export const REPORT_TYPES = ["LOST", "FOUND"] as const;
export type ReportType = (typeof REPORT_TYPES)[number];

export const REPORT_STATUSES = [
  "ACTIVE",
  "POTENTIAL_MATCH",
  "UNVERIFIED",
  "DISPUTED",
  "STALE",
  "RESOLVED",
] as const;
export type ReportStatus = (typeof REPORT_STATUSES)[number];

export const ITEM_CATEGORIES = [
  "WALLET",
  "PHONE",
  "DOCUMENT_ID",
  "BAG",
  "KEYS",
  "JEWELLERY",
  "ELECTRONICS",
  "PET",
  "VEHICLE",
  "CLOTHING",
  "OTHER",
] as const;
export type ItemCategory = (typeof ITEM_CATEGORIES)[number];

/** How precisely a report's location is known. Drives map display (pin vs area vs none). */
export type LocationPrecision = "POI" | "STREET" | "NEIGHBOURHOOD" | "CITY" | "UNKNOWN";
export type DatePrecision = "EXACT" | "APPROXIMATE" | "UNKNOWN";
export type Language = "ENGLISH" | "ROMAN_URDU" | "URDU" | "MIXED" | "OTHER";
export type SourcePlatform =
  | "DEMO"
  | "RSS"
  | "X"
  | "REDDIT"
  | "BLUESKY"
  | "MASTODON"
  | "WEB"
  | "COMMUNITY";

export interface SourceRef {
  id: string;
  platform: SourcePlatform;
  original_url: string;
  /** Original post text with CNIC numbers and phone numbers masked. */
  excerpt: string;
  published_at: string;
  collected_at: string;
  publisher?: string | null;
  publisher_byline?: string | null;
  license_url?: string | null;
}

export interface ReportSummary {
  id: string;
  report_type: ReportType;
  item_name: string;
  item_category: ItemCategory;
  description: string | null;
  location_text: string | null;
  city: string | null;
  latitude: number | null;
  longitude: number | null;
  location_precision: LocationPrecision;
  location_radius_m: number | null;
  incident_date: string | null;
  date_precision: DatePrecision;
  reported_at: string;
  collected_at: string;
  status: ReportStatus;
  confidence_score: number;
  needs_review: boolean;
  language: Language;
  primary_platform: SourcePlatform;
  source_count: number;
  is_demo: boolean;
  /** Present only when the request supplied a reference point. */
  distance_km?: number | null;
}

export interface ReportDetail extends ReportSummary {
  attributes: { colour?: string | null; brand?: string | null };
  sources: SourceRef[];
  suggestion_counts: { RESOLVED: number; INACCURATE: number };
  created_at: string;
  updated_at: string;
}

export interface MatchBreakdown {
  category: number;
  text: number;
  distance: number;
  date: number;
  attributes: number;
}

export interface MatchSummary {
  report: ReportSummary;
  score: number;
  breakdown: MatchBreakdown;
  distance_km: number | null;
  days_apart: number | null;
}

export interface Page<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
}

/** [west, south, east, north] in degrees (WGS84). */
export type BBox = [number, number, number, number];

export interface MapReportProperties {
  id: string;
  report_type: ReportType;
  item_name: string;
  item_category: ItemCategory;
  description: string | null;
  location_text: string | null;
  location_precision: LocationPrecision;
  location_radius_m: number | null;
  status: ReportStatus;
  reported_at: string;
  primary_platform: SourcePlatform;
}

export interface MapFeature {
  type: "Feature";
  geometry: { type: "Point"; coordinates: [number, number] };
  properties: MapReportProperties;
}

export interface MapFeatureCollection {
  type: "FeatureCollection";
  features: MapFeature[];
}

export interface CategoryCount {
  category: ItemCategory;
  count: number;
}

export interface Stats {
  total: number;
  lost: number;
  found: number;
  mapped: number;
  by_platform: Partial<Record<SourcePlatform, number>>;
  last_collected_at: string | null;
}

export type SuggestionType = "RESOLVED" | "INACCURATE";

export interface SuggestionResult {
  accepted: boolean;
  message: string;
}

/** A named area used for the "Near" filter and as a distance reference point. */
export interface Area {
  key: string;
  label: string;
  latitude: number;
  longitude: number;
  radius_m: number;
}
