import { describe, expect, it } from "vitest";
import { redactText } from "./redact";

describe("redactText", () => {
  it("masks CNIC numbers in all common formats", () => {
    expect(redactText("CNIC 42101-1234567-1 mila")).toBe("CNIC 42•••-•••-••• mila");
    expect(redactText("cnic 4210112345671")).toBe("cnic 42•••-•••-•••");
    expect(redactText("42101 1234567 1")).toBe("42•••-•••-•••");
  });

  it("masks Pakistani mobile numbers", () => {
    for (const phone of ["0300-1234567", "0321 7654321", "03001234567", "+92 300 1234567", "+923001234567"]) {
      expect(redactText(`call ${phone} please`)).toBe("call [phone •••] please");
    }
  });

  it("masks landlines and email addresses", () => {
    expect(redactText("office 021-34567890")).toBe("office [phone •••]");
    expect(redactText("mail me at someone@example.com")).toBe("mail me at [email •••]");
  });

  it("leaves ordinary text, years and short numbers alone", () => {
    const text = "Lost on 10 November 2026 near Block 13, Sector 33";
    expect(redactText(text)).toBe(text);
  });
});
