import {
  Backpack,
  Bike,
  CircleDashed,
  Gem,
  IdCard,
  KeyRound,
  Laptop,
  MapPin,
  MapPinOff,
  Milestone,
  Package,
  PawPrint,
  Shirt,
  Smartphone,
  Wallet,
  type LucideIcon,
} from "lucide-react";
import { CATEGORY_LABEL, PLATFORM_LABEL, PRECISION_LABEL, STATUS_LABEL, TYPE_LABEL } from "@/lib/labels";
import type { ItemCategory, LocationPrecision, ReportStatus, ReportType, SourcePlatform } from "@/lib/types";
import { cn } from "@/lib/utils";

/** Hollow ring = still missing (LOST); filled dot = located (FOUND). Same language as the map markers. */
export function TypeGlyph({ type, className }: { type: ReportType; className?: string }) {
  return type === "LOST" ? (
    <span aria-hidden className={cn("inline-block size-2.5 shrink-0 rounded-full border-[2.5px] border-lost", className)} />
  ) : (
    <span aria-hidden className={cn("inline-block size-2.5 shrink-0 rounded-full bg-found", className)} />
  );
}

export function TypeMark({ type, className }: { type: ReportType; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 text-[13px] font-semibold",
        type === "LOST" ? "text-lost-ink" : "text-found-ink",
        className,
      )}
    >
      <TypeGlyph type={type} />
      {TYPE_LABEL[type]}
    </span>
  );
}

const STATUS_STYLE: Record<ReportStatus, string> = {
  ACTIVE: "border-line bg-surface text-ink-muted",
  POTENTIAL_MATCH: "border-found/30 bg-found-soft text-found-ink",
  UNVERIFIED: "border-caution/30 bg-caution-soft text-caution",
  DISPUTED: "border-caution/30 bg-caution-soft text-caution",
  STALE: "border-line bg-hover text-ink-muted",
  RESOLVED: "border-ink/15 bg-ink text-white",
};

/** In lists, ACTIVE is the default and isn't shown, so the badges that do appear mean something. */
export function StatusBadge({
  status,
  showActive = false,
  className,
}: {
  status: ReportStatus;
  showActive?: boolean;
  className?: string;
}) {
  if (status === "ACTIVE" && !showActive) return null;
  return (
    <span
      className={cn(
        "inline-flex h-5 items-center rounded-full border px-2 text-[11.5px] font-medium whitespace-nowrap",
        STATUS_STYLE[status],
        className,
      )}
    >
      {STATUS_LABEL[status]}
    </span>
  );
}

const PRECISION_ICON: Record<LocationPrecision, LucideIcon> = {
  POI: MapPin,
  STREET: Milestone,
  NEIGHBOURHOOD: CircleDashed,
  CITY: MapPinOff,
  UNKNOWN: MapPinOff,
};

export function PrecisionIcon({ precision, className }: { precision: LocationPrecision; className?: string }) {
  const Icon = PRECISION_ICON[precision];
  return <Icon aria-hidden className={cn("size-3.5 shrink-0", className)} />;
}

/** Location line: what the post said, plus an icon that encodes how precise it is. */
export function LocationLine({
  locationText,
  precision,
  className,
}: {
  locationText: string | null;
  precision: LocationPrecision;
  className?: string;
}) {
  const text = locationText ?? "No location in the post";
  const urdu = locationText !== null && /[؀-ۿ]/.test(locationText);
  return (
    <span className={cn("inline-flex min-w-0 items-center gap-1.5", className)} title={PRECISION_LABEL[precision]}>
      <PrecisionIcon precision={precision} className={precision === "NEIGHBOURHOOD" ? "text-ink-muted" : undefined} />
      <span className="truncate" lang={urdu ? "ur" : undefined} dir={urdu ? "rtl" : undefined}>
        {text}
      </span>
      <span className="sr-only">({PRECISION_LABEL[precision]})</span>
    </span>
  );
}

const CATEGORY_ICON: Record<ItemCategory, LucideIcon> = {
  WALLET: Wallet,
  PHONE: Smartphone,
  DOCUMENT_ID: IdCard,
  BAG: Backpack,
  KEYS: KeyRound,
  JEWELLERY: Gem,
  ELECTRONICS: Laptop,
  PET: PawPrint,
  VEHICLE: Bike,
  CLOTHING: Shirt,
  OTHER: Package,
};

export function CategoryIcon({ category, className }: { category: ItemCategory; className?: string }) {
  const Icon = CATEGORY_ICON[category];
  return <Icon aria-label={CATEGORY_LABEL[category]} className={cn("size-4 shrink-0", className)} />;
}

export function PlatformLabel({ platform, className }: { platform: SourcePlatform; className?: string }) {
  return <span className={cn("text-ink-muted", className)}>{PLATFORM_LABEL[platform]}</span>;
}

/** Five-segment meter for the extraction confidence score. */
export function ConfidenceMeter({ value, className }: { value: number; className?: string }) {
  const filled = Math.round(Math.min(1, Math.max(0, value)) * 5);
  const low = value < 0.75;
  return (
    <span
      className={cn("inline-flex items-center gap-1.5", className)}
      title={`AI extraction confidence ${Math.round(value * 100)}%`}
    >
      <span aria-hidden className="flex gap-[2px]">
        {Array.from({ length: 5 }, (_, i) => (
          <span
            key={i}
            className={cn(
              "h-2.5 w-1 rounded-[1px]",
              i < filled ? (low ? "bg-caution" : "bg-ink-muted") : "bg-line",
            )}
          />
        ))}
      </span>
      <span className="sr-only">AI extraction confidence</span>
      <span data-numeric className={cn("text-xs", low ? "text-caution" : "text-ink-muted")}>
        {Math.round(value * 100)}%
      </span>
    </span>
  );
}
