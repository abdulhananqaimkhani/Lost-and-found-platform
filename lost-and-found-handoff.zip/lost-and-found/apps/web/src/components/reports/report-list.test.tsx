import { act, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { __demo } from "@/lib/data/mock-source";
import { useSelection } from "@/lib/store/selection";
import { ReportList } from "./report-list";

vi.mock("next/link", () => ({
  default: ({ href, children, ...rest }: { href: string; children?: React.ReactNode }) => (
    <a href={href} {...rest}>
      {children}
    </a>
  ),
}));

const pick = (...ids: string[]) => ids.map((id) => __demo.DETAILS.get(id)!);

describe("ReportList ↔ selection store", () => {
  beforeEach(() => {
    useSelection.setState({ selectedId: null, origin: null, nonce: 0, hoveredId: null, hoverOrigin: null });
  });

  it("selects a report with origin 'list' when its row is clicked", async () => {
    const onSelected = vi.fn();
    render(<ReportList items={pick("demo-001", "demo-003")} ariaLabel="Reports" onSelected={onSelected} />);
    const row = screen.getByRole("button", { name: /Samsung Galaxy A54.*Show on map/ });

    await userEvent.click(row);

    const state = useSelection.getState();
    expect(state.selectedId).toBe("demo-003");
    expect(state.origin).toBe("list");
    expect(row).toHaveAttribute("aria-pressed", "true");
    expect(onSelected).toHaveBeenCalledWith("demo-003");
  });

  it("re-clicking the same row bumps the nonce so the map re-centres", async () => {
    render(<ReportList items={pick("demo-003")} ariaLabel="Reports" />);
    const row = screen.getByRole("button", { name: /Show on map/ });
    await userEvent.click(row);
    await userEvent.click(row);
    expect(useSelection.getState().nonce).toBe(2);
  });

  it("scrolls the row into view when a marker selects it", () => {
    const scroll = vi.spyOn(Element.prototype, "scrollIntoView");
    const { container } = render(<ReportList items={pick("demo-001", "demo-003", "demo-005")} ariaLabel="Reports" />);

    act(() => useSelection.getState().select("demo-005", "map"));

    const row = container.querySelector('[data-report-id="demo-005"]')!;
    expect(row).toHaveAttribute("data-selected", "true");
    expect(scroll).toHaveBeenCalledTimes(1);
    expect(scroll.mock.contexts[0]).toBe(row);
  });

  it("does not scroll the list when the selection came from the list itself", async () => {
    const scroll = vi.spyOn(Element.prototype, "scrollIntoView");
    render(<ReportList items={pick("demo-001")} ariaLabel="Reports" />);
    await userEvent.click(screen.getByRole("button", { name: /Show on map/ }));
    expect(scroll).not.toHaveBeenCalled();
  });

  it("shares hover state with the map", async () => {
    render(<ReportList items={pick("demo-001")} ariaLabel="Reports" />);
    await userEvent.hover(screen.getByRole("button", { name: /Show on map/ }));
    expect(useSelection.getState()).toMatchObject({ hoveredId: "demo-001", hoverOrigin: "list" });
  });

  it("links unmapped reports to their details instead of the map", () => {
    render(<ReportList items={pick("demo-016")} ariaLabel="Reports" />);
    expect(screen.queryByRole("button", { name: /Show on map/ })).toBeNull();
    expect(screen.getByRole("link", { name: /Not on the map/ })).toHaveAttribute("href", "/reports/demo-016");
  });
});
