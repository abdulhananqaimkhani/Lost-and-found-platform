"use client";

import { ChevronRight } from "lucide-react";
import Link from "next/link";
import { useEffect, useRef } from "react";
import { usePrefersReducedMotion } from "@/hooks/use-media-query";
import { formatRelative } from "@/lib/format";
import { isMappable } from "@/lib/geo";
import { useSelection } from "@/lib/store/selection";
import type { ReportSummary } from "@/lib/types";
import { cn } from "@/lib/utils";
import { CategoryIcon, LocationLine, StatusBadge, TypeMark } from "./report-bits";

export function ReportList({
  items,
  onSelected,
  ariaLabel,
}: {
  items: ReportSummary[];
  /** Called after a row selects a report (e.g. to collapse the mobile sheet). */
  onSelected?: (id: string) => void;
  ariaLabel: string;
}) {
  const selectedId = useSelection((s) => s.selectedId);
  const origin = useSelection((s) => s.origin);
  const nonce = useSelection((s) => s.nonce);
  const hoveredId = useSelection((s) => s.hoveredId);
  const select = useSelection((s) => s.select);
  const hover = useSelection((s) => s.hover);
  const reducedMotion = usePrefersReducedMotion();
  const listRef = useRef<HTMLUListElement>(null);

  // A marker click selects a report: bring its row into view.
  useEffect(() => {
    if (origin !== "map" || !selectedId) return;
    const row = listRef.current?.querySelector(`[data-report-id="${CSS.escape(selectedId)}"]`);
    row?.scrollIntoView({ block: "nearest", behavior: reducedMotion ? "auto" : "smooth" });
  }, [nonce, origin, selectedId, reducedMotion]);

  return (
    <ul ref={listRef} aria-label={ariaLabel} className="divide-y divide-line">
      {items.map((r) => (
        <ReportRow
          key={r.id}
          report={r}
          selected={r.id === selectedId}
          hovered={r.id === hoveredId}
          onSelect={() => {
            select(r.id, "list");
            onSelected?.(r.id);
          }}
          onHover={(on) => hover(on ? r.id : null, "list")}
        />
      ))}
    </ul>
  );
}

function ReportRow({
  report: r,
  selected,
  hovered,
  onSelect,
  onHover,
}: {
  report: ReportSummary;
  selected: boolean;
  hovered: boolean;
  onSelect: () => void;
  onHover: (on: boolean) => void;
}) {
  const mapped = r.latitude !== null && isMappable(r.location_precision);
  return (
    <li
      data-report-id={r.id}
      data-selected={selected || undefined}
      className={cn(
        "relative transition-colors",
        selected ? "bg-[#f6f8f7]" : hovered ? "bg-hover/60" : "bg-surface",
      )}
      onMouseEnter={() => onHover(true)}
      onMouseLeave={() => onHover(false)}
    >
      {selected && (
        <span aria-hidden className={cn("absolute inset-y-0 left-0 w-[3px]", r.report_type === "LOST" ? "bg-lost" : "bg-found")} />
      )}
      {mapped ? (
        <button
          type="button"
          onClick={onSelect}
          onFocus={() => onHover(true)}
          onBlur={() => onHover(false)}
          aria-pressed={selected}
          aria-label={`${r.item_name}, ${r.report_type === "LOST" ? "lost" : "found"}. Show on map`}
          className="absolute inset-0 z-0 focus-visible:outline-offset-[-2px]"
        />
      ) : (
        <Link
          href={`/reports/${r.id}`}
          aria-label={`${r.item_name}. Not on the map. Open details`}
          className="absolute inset-0 z-0 focus-visible:outline-offset-[-2px]"
        />
      )}
      <div className="pointer-events-none relative flex gap-3 py-3 pr-2 pl-4">
        <span className="mt-0.5 grid size-9 shrink-0 place-items-center rounded-lg bg-canvas text-ink-muted">
          <CategoryIcon category={r.item_category} />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline justify-between gap-3">
            <p className="truncate text-[14.5px] font-medium text-ink">{r.item_name}</p>
            <time dateTime={r.reported_at} className="shrink-0 text-xs text-ink-faint">
              {formatRelative(r.reported_at)}
            </time>
          </div>
          <div className="mt-0.5 flex min-w-0 items-center gap-2.5 text-[13px] text-ink-muted">
            <TypeMark type={r.report_type} className="shrink-0 text-[12.5px]" />
            <LocationLine locationText={r.location_text} precision={r.location_precision} />
          </div>
          {(r.status !== "ACTIVE" || r.source_count > 1 || !mapped) && (
            <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-ink-muted">
              <StatusBadge status={r.status} />
              {!mapped && <span>Not on the map</span>}
              {r.source_count > 1 && <span>Posted in {r.source_count} places</span>}
            </div>
          )}
        </div>
        <Link
          href={`/reports/${r.id}`}
          aria-label={`Open details for ${r.item_name}`}
          className="pointer-events-auto relative z-10 grid size-8 shrink-0 place-items-center self-center rounded-md text-ink-faint hover:bg-hover hover:text-ink"
        >
          <ChevronRight className="size-4" />
        </Link>
      </div>
    </li>
  );
}

export function ReportListSkeleton({ rows = 6 }: { rows?: number }) {
  return (
    <ul aria-hidden className="divide-y divide-line">
      {Array.from({ length: rows }, (_, i) => (
        <li key={i} className="flex gap-3 px-4 py-3">
          <span className="size-9 animate-pulse rounded-lg bg-hover" />
          <span className="flex-1 space-y-2 pt-1">
            <span className="block h-3.5 w-2/3 animate-pulse rounded bg-hover" />
            <span className="block h-3 w-1/2 animate-pulse rounded bg-hover" />
          </span>
        </li>
      ))}
    </ul>
  );
}
