"use client";

import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { countActiveFilters, type ReportFilters } from "@/lib/filters";
import { cn } from "@/lib/utils";
import { AreaFilter, CategoryFilter, DateFilter, SearchField, TypeToggle } from "./filter-controls";

export function FilterBar({
  filters,
  setFilters,
  clearFilters,
  className,
}: {
  filters: ReportFilters;
  setFilters: (patch: Partial<ReportFilters>) => void;
  clearFilters: () => void;
  className?: string;
}) {
  const active = countActiveFilters(filters);
  return (
    <div className={cn("flex flex-col gap-2 lg:flex-row lg:items-center", className)}>
      <SearchField value={filters.q} onChange={(q) => setFilters({ q })} className="w-full lg:w-80" />
      {/* On narrow screens the controls scroll sideways instead of wrapping into a tall block. */}
      <div className="-mx-3 flex items-center gap-2 overflow-x-auto px-3 pb-0.5 [scrollbar-width:none] lg:mx-0 lg:overflow-visible lg:px-0 lg:pb-0">
        <TypeToggle value={filters.type} onChange={(type) => setFilters({ type })} />
        <CategoryFilter value={filters.categories} onChange={(categories) => setFilters({ categories })} />
        <AreaFilter value={filters.area} onChange={(area) => setFilters({ area })} />
        <DateFilter date={filters.date} from={filters.from} to={filters.to} onChange={(patch) => setFilters(patch)} />
        {active > 0 && (
          <Button variant="ghost" onClick={clearFilters} className="h-9 shrink-0 text-ink-muted">
            <RotateCcw aria-hidden />
            Clear filters
          </Button>
        )}
      </div>
    </div>
  );
}
