"use client";

import { CalendarDays, ChevronDown, LocateFixed, MapPin, Search, Shapes, X } from "lucide-react";
import { useEffect, useId, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import type { DatePreset, ReportFilters, SortOption } from "@/lib/filters";
import { CATEGORY_LABEL, STATUS_LABEL } from "@/lib/labels";
import { useAreas, useCategories } from "@/lib/queries";
import { ITEM_CATEGORIES, REPORT_STATUSES, type ItemCategory, type ReportStatus, type ReportType } from "@/lib/types";
import { cn } from "@/lib/utils";
import { TypeGlyph } from "../reports/report-bits";

type SetFilters = (patch: Partial<ReportFilters>) => void;

const triggerClass =
  "h-9 gap-1.5 rounded-lg border-line-strong bg-surface px-3 text-sm font-normal text-ink hover:bg-hover data-[active=true]:border-ink data-[active=true]:font-medium";

/* ───────────── Search ───────────── */

export function SearchField({
  value,
  onChange,
  className,
  placeholder = "Search items, e.g. black wallet, batwa, CNIC",
}: {
  value: string;
  onChange: (q: string) => void;
  className?: string;
  placeholder?: string;
}) {
  const [draft, setDraft] = useState(value);
  const debounced = useDebouncedValue(draft, 300);
  const lastSent = useRef(value);

  // Push debounced typing into the URL.
  useEffect(() => {
    if (debounced !== lastSent.current) {
      lastSent.current = debounced;
      onChange(debounced);
    }
  }, [debounced, onChange]);

  // Follow external changes (e.g. "Clear filters").
  useEffect(() => {
    if (value !== lastSent.current) {
      lastSent.current = value;
      setDraft(value);
    }
  }, [value]);

  return (
    <div className={cn("relative", className)}>
      <Search aria-hidden className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-ink-faint" />
      <Input
        type="search"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        placeholder={placeholder}
        aria-label="Search reports"
        maxLength={120}
        className="h-9 rounded-lg border-line-strong bg-surface pr-8 pl-9 text-sm placeholder:text-ink-faint"
      />
      {draft && (
        <button
          type="button"
          onClick={() => setDraft("")}
          aria-label="Clear search"
          className="absolute top-1/2 right-2 grid size-6 -translate-y-1/2 place-items-center rounded-md text-ink-faint hover:bg-hover hover:text-ink"
        >
          <X className="size-3.5" />
        </button>
      )}
    </div>
  );
}

/* ───────────── Lost / Found ───────────── */

export function TypeToggle({ value, onChange }: { value: ReportType | null; onChange: (t: ReportType | null) => void }) {
  return (
    <ToggleGroup
      type="single"
      value={value ?? "ALL"}
      onValueChange={(v) => v && onChange(v === "ALL" ? null : (v as ReportType))}
      aria-label="Report type"
      spacing={0}
      className="h-9 rounded-lg border border-line-strong bg-surface p-0.5"
    >
      {(["ALL", "LOST", "FOUND"] as const).map((v) => (
        <ToggleGroupItem
          key={v}
          value={v}
          aria-label={v === "ALL" ? "Lost and found" : v === "LOST" ? "Lost only" : "Found only"}
          className="h-7.5 gap-1.5 rounded-md px-3 text-sm text-ink-muted data-[state=on]:bg-ink data-[state=on]:text-white"
        >
          {v !== "ALL" && <TypeGlyph type={v} />}
          {v === "ALL" ? "All" : v === "LOST" ? "Lost" : "Found"}
        </ToggleGroupItem>
      ))}
    </ToggleGroup>
  );
}

/* ───────────── Category ───────────── */

export function CategoryFilter({ value, onChange }: { value: ItemCategory[]; onChange: (c: ItemCategory[]) => void }) {
  const { data: counts } = useCategories();
  const label =
    value.length === 0
      ? "Category"
      : value.length === 1
        ? CATEGORY_LABEL[value[0]]
        : `${CATEGORY_LABEL[value[0]]} +${value.length - 1}`;

  const toggle = (c: ItemCategory, checked: boolean) =>
    onChange(checked ? [...value, c] : value.filter((v) => v !== c));

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className={triggerClass} data-active={value.length > 0}>
          <Shapes aria-hidden className="size-4 text-ink-muted" />
          {label}
          <ChevronDown aria-hidden className="size-3.5 text-ink-faint" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-64 p-1.5">
        <fieldset>
          <legend className="sr-only">Item category</legend>
          {ITEM_CATEGORIES.map((c) => {
            const count = counts?.find((x) => x.category === c)?.count;
            return (
              <label
                key={c}
                className="flex cursor-pointer items-center gap-2.5 rounded-md px-2 py-1.5 text-sm hover:bg-hover"
              >
                <Checkbox checked={value.includes(c)} onCheckedChange={(v) => toggle(c, v === true)} />
                <span className="flex-1">{CATEGORY_LABEL[c]}</span>
                {count !== undefined && <span className="text-xs text-ink-faint">{count}</span>}
              </label>
            );
          })}
        </fieldset>
        {value.length > 0 && (
          <Button variant="ghost" size="sm" className="mt-1 w-full text-ink-muted" onClick={() => onChange([])}>
            Clear categories
          </Button>
        )}
      </PopoverContent>
    </Popover>
  );
}

/* ───────────── Area ───────────── */

const ANYWHERE = "__anywhere";

export function AreaFilter({ value, onChange }: { value: string | null; onChange: (area: string | null) => void }) {
  const { data: areas } = useAreas();
  return (
    <Select value={value ?? ANYWHERE} onValueChange={(v) => onChange(v === ANYWHERE ? null : v)}>
      <SelectTrigger aria-label="Area" className={cn(triggerClass, "min-w-0")} data-active={value !== null}>
        <MapPin aria-hidden className="size-4 text-ink-muted" />
        <SelectValue placeholder="Anywhere" />
      </SelectTrigger>
      <SelectContent position="popper" align="start" className="max-h-80">
        <SelectItem value={ANYWHERE}>Anywhere in Karachi</SelectItem>
        {areas?.map((a) => (
          <SelectItem key={a.key} value={a.key}>
            Near {a.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

/* ───────────── Date ───────────── */

const DATE_LABEL: Record<DatePreset, string> = {
  any: "Any time",
  "24h": "Last 24 hours",
  "7d": "Last 7 days",
  "30d": "Last 30 days",
  custom: "Custom dates",
};

export function DateFilter({
  date,
  from,
  to,
  onChange,
}: Pick<ReportFilters, "date" | "from" | "to"> & {
  onChange: (patch: Pick<ReportFilters, "date" | "from" | "to">) => void;
}) {
  const id = useId();
  const label = date === "custom" && (from || to) ? `${from ?? "…"} – ${to ?? "…"}` : DATE_LABEL[date];
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className={triggerClass} data-active={date !== "any"}>
          <CalendarDays aria-hidden className="size-4 text-ink-muted" />
          {label}
          <ChevronDown aria-hidden className="size-3.5 text-ink-faint" />
        </Button>
      </PopoverTrigger>
      <PopoverContent align="start" className="w-64">
        <p className="mb-2 text-xs text-ink-muted">When the report was posted</p>
        <RadioGroup
          value={date}
          onValueChange={(v) => onChange({ date: v as DatePreset, from: v === "custom" ? from : null, to: v === "custom" ? to : null })}
          className="gap-1"
        >
          {(Object.keys(DATE_LABEL) as DatePreset[]).map((p) => (
            <Label key={p} htmlFor={`${id}-${p}`} className="flex cursor-pointer items-center gap-2.5 rounded-md px-1 py-1.5 font-normal">
              <RadioGroupItem id={`${id}-${p}`} value={p} />
              {DATE_LABEL[p]}
            </Label>
          ))}
        </RadioGroup>
        {date === "custom" && (
          <div className="mt-2 grid grid-cols-2 gap-2">
            <Label className="flex flex-col items-start gap-1 text-xs font-normal text-ink-muted">
              From
              <Input type="date" value={from ?? ""} max={to ?? undefined} onChange={(e) => onChange({ date, from: e.target.value || null, to })} className="h-8 text-sm" />
            </Label>
            <Label className="flex flex-col items-start gap-1 text-xs font-normal text-ink-muted">
              To
              <Input type="date" value={to ?? ""} min={from ?? undefined} onChange={(e) => onChange({ date, from, to: e.target.value || null })} className="h-8 text-sm" />
            </Label>
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}

/* ───────────── Status (Explore page) ───────────── */

export function StatusFilter({ value, onChange }: { value: ReportStatus[]; onChange: (s: ReportStatus[]) => void }) {
  return (
    <fieldset className="space-y-0.5">
      <legend className="mb-1.5 text-sm font-medium text-ink">Status</legend>
      {REPORT_STATUSES.map((s) => (
        <label key={s} className="flex cursor-pointer items-center gap-2.5 rounded-md py-1 text-sm text-ink">
          <Checkbox
            checked={value.includes(s)}
            onCheckedChange={(v) => onChange(v === true ? [...value, s] : value.filter((x) => x !== s))}
          />
          {STATUS_LABEL[s]}
        </label>
      ))}
    </fieldset>
  );
}

/* ───────────── Sort (Explore page) ───────────── */

export function SortControl({
  filters,
  setFilters,
  areaLabel,
}: {
  filters: ReportFilters;
  setFilters: SetFilters;
  areaLabel: string | null;
}) {
  const [locating, setLocating] = useState(false);
  const hasReference = filters.near !== null || filters.area !== null;

  const requestLocation = () => {
    if (!("geolocation" in navigator)) {
      toast.error("This browser can't share your location. Choose an area instead.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false);
        setFilters({ near: { lat: pos.coords.latitude, lng: pos.coords.longitude }, sort: "distance" });
      },
      () => {
        setLocating(false);
        toast.error("Location permission was denied. Choose an area to sort by distance instead.");
      },
      { enableHighAccuracy: false, timeout: 10_000, maximumAge: 300_000 },
    );
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Select
        value={filters.sort}
        onValueChange={(v) => {
          if (v === "distance" && !hasReference) requestLocation();
          else setFilters({ sort: v as SortOption });
        }}
      >
        <SelectTrigger aria-label="Sort order" className={cn(triggerClass, "w-auto")}>
          <SelectValue />
        </SelectTrigger>
        <SelectContent position="popper" align="end">
          <SelectItem value="newest">Newest first</SelectItem>
          <SelectItem value="oldest">Oldest first</SelectItem>
          <SelectItem value="distance">Nearest first</SelectItem>
        </SelectContent>
      </Select>
      {filters.sort === "distance" && (
        <span className="text-xs text-ink-muted">
          {filters.near ? "from your location" : areaLabel ? `from ${areaLabel}` : null}
        </span>
      )}
      {!filters.near && (
        <Button variant="ghost" size="sm" onClick={requestLocation} disabled={locating} className="text-ink-muted">
          <LocateFixed aria-hidden />
          {locating ? "Locating…" : "Use my location"}
        </Button>
      )}
      {filters.near && (
        <Button variant="ghost" size="sm" onClick={() => setFilters({ near: null, sort: filters.area ? filters.sort : "newest" })} className="text-ink-muted">
          <X aria-hidden />
          Forget my location
        </Button>
      )}
    </div>
  );
}
