"use client";

import "leaflet/dist/leaflet.css";
import { createLeafletContext, LeafletContext, type LeafletContextInterface } from "@react-leaflet/core";
import L from "leaflet";
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Circle, Marker, Popup, TileLayer, ZoomControl, useMap, useMapEvents } from "react-leaflet";
import Supercluster from "supercluster";
import { useCanHover, usePrefersReducedMotion } from "@/hooks/use-media-query";
import {
  KARACHI_CENTER,
  KARACHI_MAX_BOUNDS,
  KARACHI_ZOOM,
  focusZoom,
  isAreaPrecision,
  padBBox,
} from "@/lib/geo";
import { TYPE_LABEL } from "@/lib/labels";
import { useSelection } from "@/lib/store/selection";
import type { Area, BBox, MapReportProperties } from "@/lib/types";
import { OSM_TILE_ATTRIBUTION, OSM_TILE_URL, areaCircleStyle } from "./map-config";
import { clusterIcon, reportIcon, type MarkerState } from "./marker-icons";
import { PreviewCard } from "./preview-card";
import { TypeGlyph } from "../reports/report-bits";

export interface ReportPoint extends MapReportProperties {
  latitude: number;
  longitude: number;
}

export interface ReportMapProps {
  points: ReportPoint[];
  /** Resolved by the parent so it can come from the list even when outside the loaded markers. */
  selected: ReportPoint | null;
  focusArea: Area | null;
  onViewChange: (bbox: BBox, zoom: number) => void;
}

const HOVER_CLEAR_DELAY_MS = 220;
/** Above this zoom, clusters stop splitting; remaining clusters are reports at (almost) the same spot. */
const CLUSTER_MAX_ZOOM = 15;

interface StackState {
  key: number;
  lat: number;
  lng: number;
  reports: ReportPoint[];
}

function toBBox(bounds: L.LatLngBounds): BBox {
  return [bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()];
}

export default function ReportMap(props: ReportMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const removalObserver = useRef<MutationObserver | null>(null);
  const [context, setContext] = useState<LeafletContextInterface | null>(null);
  const attachMap = useCallback((container: HTMLDivElement | null) => {
    if (!container) return;
    removalObserver.current?.disconnect();
    removalObserver.current = null;
    if (!mapRef.current) {
      const map = L.map(container, {
        minZoom: 10,
        maxZoom: 18,
        maxBounds: KARACHI_MAX_BOUNDS,
        maxBoundsViscosity: 0.8,
        zoomControl: false,
      }).setView(KARACHI_CENTER, KARACHI_ZOOM);
      mapRef.current = map;
      setContext(createLeafletContext(map));
    }
    const map = mapRef.current;
    return () => {
      // Next.js hides cached routes while keeping their DOM connected. Leaflet's
      // panes must survive hiding, including until a hidden route is evicted.
      const disposeIfRemoved = () => {
        if (container.isConnected) return;
        observer.disconnect();
        removalObserver.current = null;
        map.remove();
        mapRef.current = null;
      };
      const observer = new MutationObserver(disposeIfRemoved);
      removalObserver.current = observer;
      observer.observe(container.ownerDocument, { childList: true, subtree: true });
      disposeIfRemoved();
    };
  }, []);

  return (
    <div ref={attachMap} className="lf-map h-full w-full" aria-label="Map of lost and found reports">
      {context && (
        <LeafletContext.Provider value={context}>
          <TileLayer url={OSM_TILE_URL} attribution={OSM_TILE_ATTRIBUTION} />
          <ZoomControl position="bottomright" />
          <ReportLayer {...props} />
        </LeafletContext.Provider>
      )}
    </div>
  );
}

type ClusterProps = { lost: number };

function ReportLayer({ points, selected, focusArea, onViewChange }: ReportMapProps) {
  const map = useMap();
  const canHover = useCanHover();
  const reducedMotion = usePrefersReducedMotion();
  const { selectedId, origin, nonce, hoveredId, hoverOrigin, select, clearSelection, hover } = useSelection();
  const [view, setView] = useState(() => ({ bbox: toBBox(map.getBounds()), zoom: map.getZoom() }));

  /* ── View tracking ── */
  const reportView = useCallback(() => {
    const next = { bbox: toBBox(map.getBounds()), zoom: map.getZoom() };
    setView(next);
    onViewChange(next.bbox, next.zoom);
  }, [map, onViewChange]);

  useMapEvents({ moveend: reportView });

  const reportedInitialView = useRef(false);
  useEffect(() => {
    if (reportedInitialView.current) return;
    reportedInitialView.current = true;
    reportView();
  }, [reportView]);

  // Keep Leaflet's size in sync when the layout around the map changes (panels, mobile sheet).
  useEffect(() => {
    const observer = new ResizeObserver(() => map.invalidateSize());
    observer.observe(map.getContainer());
    return () => observer.disconnect();
  }, [map]);

  /* ── Clustering (the selected report is excluded so it is always visible) ── */
  const index = useMemo(() => {
    const idx = new Supercluster<ReportPoint, ClusterProps>({
      radius: 56,
      maxZoom: CLUSTER_MAX_ZOOM,
      map: (p) => ({ lost: p.report_type === "LOST" ? 1 : 0 }),
      reduce: (acc, p) => {
        acc.lost += p.lost;
      },
    });
    idx.load(
      points
        .filter((p) => p.id !== selected?.id)
        .map((p) => ({
          type: "Feature" as const,
          geometry: { type: "Point" as const, coordinates: [p.longitude, p.latitude] },
          properties: p,
        })),
    );
    return idx;
  }, [points, selected?.id]);

  const features = useMemo(
    () => index.getClusters(padBBox(view.bbox, 0.25), Math.round(view.zoom)),
    [index, view],
  );

  /*
   * Reports that share a location (e.g. several posts that only say "Gulshan-e-Iqbal" are all placed at
   * that area's centre) never separate by zooming. Clicking such a cluster lists them instead.
   */
  const [stack, setStack] = useState<StackState | null>(null);
  const stackPosition = useMemo<L.LatLngTuple | null>(() => (stack ? [stack.lat, stack.lng] : null), [stack]);

  /* ── Hover preview (desktop) with a short grace period so the cursor can reach the card ── */
  const hoverTimer = useRef<number | undefined>(undefined);
  const cancelHoverClear = useCallback(() => window.clearTimeout(hoverTimer.current), []);
  const scheduleHoverClear = useCallback(() => {
    window.clearTimeout(hoverTimer.current);
    hoverTimer.current = window.setTimeout(() => hover(null, "map"), HOVER_CLEAR_DELAY_MS);
  }, [hover]);
  useEffect(() => () => window.clearTimeout(hoverTimer.current), []);

  const onHoverStart = useCallback(
    (id: string) => {
      cancelHoverClear();
      hover(id, "map");
    },
    [cancelHoverClear, hover],
  );

  /* ── Fly to a report selected from the list ── */
  const flownNonce = useRef(-1);
  useEffect(() => {
    if (origin !== "list" || !selected || flownNonce.current === nonce) return;
    flownNonce.current = nonce;
    const target = L.latLng(selected.latitude, selected.longitude);
    const zoom = Math.max(map.getZoom(), focusZoom(selected.location_precision, selected.location_radius_m));
    if (reducedMotion) map.setView(target, zoom);
    else map.flyTo(target, zoom, { duration: 0.6 });
  }, [nonce, origin, selected, map, reducedMotion]);

  /* ── Fit an area chosen in the "Near" filter ── */
  const fittedArea = useRef<string | null>(null);
  useEffect(() => {
    if (!focusArea || fittedArea.current === focusArea.key) return;
    fittedArea.current = focusArea.key;
    const bounds = L.latLng(focusArea.latitude, focusArea.longitude).toBounds(focusArea.radius_m * 2);
    map.flyToBounds(bounds, { padding: [32, 32], animate: !reducedMotion, duration: 0.6 });
  }, [focusArea, map, reducedMotion]);

  /* ── Escape closes the preview ── */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        clearSelection();
        hover(null, "map");
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [clearSelection, hover]);

  /* ── Preview popup: hover preview wins over the pinned selection while hovering ── */
  const previewId = (hoverOrigin === "map" && hoveredId) || selectedId;
  const preview = useMemo(
    () => (previewId ? (selected?.id === previewId ? selected : points.find((p) => p.id === previewId)) ?? null : null),
    [previewId, points, selected],
  );
  const previewPosition = useMemo<L.LatLngTuple | null>(
    () => (preview ? [preview.latitude, preview.longitude] : null),
    // Depend on coordinates, not object identity, so the popup isn't reopened on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [preview?.latitude, preview?.longitude],
  );

  // Updated before the old popup's cleanup runs, so a programmatic swap isn't mistaken for a user close.
  const previewIdRef = useRef<string | null>(null);
  useLayoutEffect(() => {
    previewIdRef.current = previewId;
  }, [previewId]);

  const stateFor = (id: string): MarkerState =>
    id === selectedId ? "selected" : id === hoveredId ? "hovered" : "default";

  const unclusteredAreas: ReportPoint[] = [];

  const markers = features.map((f) => {
    const [lng, lat] = f.geometry.coordinates;
    if ("cluster" in f.properties && f.properties.cluster) {
      const clusterId = f.properties.cluster_id;
      const count = f.properties.point_count;
      return (
        <Marker
          key={`cluster-${clusterId}`}
          position={[lat, lng]}
          icon={clusterIcon(count, f.properties.lost)}
          eventHandlers={{
            add: (e) => e.target.getElement()?.setAttribute("aria-label", `${count} reports here`),
            click: () => {
              const expansion = index.getClusterExpansionZoom(clusterId);
              if (expansion > CLUSTER_MAX_ZOOM || map.getZoom() >= CLUSTER_MAX_ZOOM) {
                const reports = index.getLeaves(clusterId, 50).map((leaf) => leaf.properties as ReportPoint);
                setStack({ key: clusterId, lat, lng, reports });
                return;
              }
              if (reducedMotion) map.setView([lat, lng], expansion);
              else map.flyTo([lat, lng], expansion, { duration: 0.5 });
            },
          }}
        />
      );
    }
    const point = f.properties as ReportPoint;
    if (isAreaPrecision(point.location_precision)) unclusteredAreas.push(point);
    return (
      <ReportMarker
        key={point.id}
        point={point}
        state={stateFor(point.id)}
        onHoverStart={canHover ? onHoverStart : undefined}
        onHoverEnd={canHover ? scheduleHoverClear : undefined}
        onSelect={(id) => select(id, "map")}
      />
    );
  });

  return (
    <>
      {unclusteredAreas.map((p) => (
        <Circle
          key={`area-${p.id}`}
          center={[p.latitude, p.longitude]}
          radius={p.location_radius_m ?? 800}
          pathOptions={areaCircleStyle(p.report_type, p.id === hoveredId)}
          interactive={false}
        />
      ))}
      {selected && isAreaPrecision(selected.location_precision) && (
        <Circle
          key={`area-selected-${selected.id}`}
          center={[selected.latitude, selected.longitude]}
          radius={selected.location_radius_m ?? 800}
          pathOptions={areaCircleStyle(selected.report_type, true)}
          interactive={false}
        />
      )}
      {markers}
      {selected && (
        <ReportMarker
          key={`selected-${selected.id}`}
          point={selected}
          state="selected"
          onHoverStart={canHover ? onHoverStart : undefined}
          onHoverEnd={canHover ? scheduleHoverClear : undefined}
          onSelect={(id) => select(id, "map")}
        />
      )}
      {preview && previewPosition && (
        <Popup
          key={preview.id}
          position={previewPosition}
          className="lf-popup"
          offset={isAreaPrecision(preview.location_precision) ? [0, -6] : [0, -30]}
          autoPan={!canHover}
          autoPanPadding={[16, 16]}
          maxWidth={300}
          eventHandlers={{
            add: (e) => {
              const el = (e.target as L.Popup).getElement();
              el?.addEventListener("mouseenter", cancelHoverClear);
              el?.addEventListener("mouseleave", scheduleHoverClear);
            },
            remove: () => {
              // Closed by the user (close button, click on the map), not by a programmatic swap.
              if (previewIdRef.current === preview.id) {
                clearSelection();
                hover(null, "map");
              }
            },
          }}
        >
          <PreviewCard report={preview} />
        </Popup>
      )}
      {stack && stackPosition && (
        <Popup
          key={`stack-${stack.key}`}
          position={stackPosition}
          className="lf-popup"
          offset={[0, -16]}
          maxWidth={300}
          eventHandlers={{ remove: () => setStack((s) => (s?.key === stack.key ? null : s)) }}
        >
          <StackList
            reports={stack.reports}
            onPick={(id) => {
              setStack(null);
              // Select after this click finishes. Otherwise Leaflet sees the same click once the list has
              // been removed from the DOM, treats it as a click on the empty map, and closes the new preview.
              window.setTimeout(() => select(id, "map"), 0);
            }}
          />
        </Popup>
      )}
    </>
  );
}

function StackList({ reports, onPick }: { reports: ReportPoint[]; onPick: (id: string) => void }) {
  return (
    <div className="py-2" data-testid="map-stack">
      <p className="px-3.5 pt-1 pb-2 pr-8 text-[12.5px] text-ink-muted">
        {reports.length} reports at this spot. The posts name the same place.
      </p>
      <ul className="max-h-64 overflow-y-auto">
        {reports.map((r) => (
          <li key={r.id}>
            <button
              type="button"
              onClick={() => onPick(r.id)}
              className="flex w-full items-center gap-2.5 px-3.5 py-2 text-left hover:bg-hover"
            >
              <TypeGlyph type={r.report_type} />
              <span className="min-w-0 flex-1">
                <span className="block truncate font-medium text-ink">{r.item_name}</span>
                <span className="block truncate text-xs text-ink-muted">{r.location_text}</span>
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ReportMarker({
  point,
  state,
  onHoverStart,
  onHoverEnd,
  onSelect,
}: {
  point: ReportPoint;
  state: MarkerState;
  onHoverStart?: (id: string) => void;
  onHoverEnd?: () => void;
  onSelect: (id: string) => void;
}) {
  const kind = isAreaPrecision(point.location_precision) ? "area" : "pin";
  return (
    <Marker
      position={[point.latitude, point.longitude]}
      icon={reportIcon(point.id, point.report_type, kind, state)}
      zIndexOffset={state === "selected" ? 1000 : state === "hovered" ? 500 : 0}
      eventHandlers={{
        add: (e) => {
          const label = `${TYPE_LABEL[point.report_type]}: ${point.item_name}${kind === "area" ? " (approximate area)" : ""}`;
          e.target.getElement()?.setAttribute("aria-label", label);
        },
        mouseover: () => onHoverStart?.(point.id),
        mouseout: () => onHoverEnd?.(),
        click: () => onSelect(point.id),
      }}
    />
  );
}
