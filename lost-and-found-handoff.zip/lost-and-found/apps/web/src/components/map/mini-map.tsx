"use client";

import "leaflet/dist/leaflet.css";
import { Circle, MapContainer, Marker, TileLayer } from "react-leaflet";
import { focusZoom, isAreaPrecision } from "@/lib/geo";
import type { LocationPrecision, ReportType } from "@/lib/types";
import { reportIcon } from "./marker-icons";
import { OSM_TILE_ATTRIBUTION, OSM_TILE_URL, areaCircleStyle } from "./map-config";

export interface MiniMapProps {
  id: string;
  type: ReportType;
  latitude: number;
  longitude: number;
  precision: LocationPrecision;
  radiusM: number | null;
}

/** Small, static-feeling map for the report detail page. Scroll-zoom is off so the page scrolls normally. */
export default function MiniMap({ id, type, latitude, longitude, precision, radiusM }: MiniMapProps) {
  const area = isAreaPrecision(precision);
  return (
    <MapContainer
      center={[latitude, longitude]}
      zoom={focusZoom(precision, radiusM)}
      minZoom={10}
      maxZoom={18}
      scrollWheelZoom={false}
      className="lf-map h-full w-full"
      aria-label="Report location"
    >
      <TileLayer url={OSM_TILE_URL} attribution={OSM_TILE_ATTRIBUTION} />
      {area && (
        <Circle center={[latitude, longitude]} radius={radiusM ?? 800} pathOptions={areaCircleStyle(type, true)} interactive={false} />
      )}
      <Marker
        position={[latitude, longitude]}
        icon={reportIcon(id, type, area ? "area" : "pin", "default")}
        interactive={false}
        keyboard={false}
      />
    </MapContainer>
  );
}
