import type L from "leaflet";
import type { ReportType } from "@/lib/types";

/** Standard OSM tiles: fine for development and demo traffic; see PROJECT_PLAN.md §15 for public deployment. */
export const OSM_TILE_URL = "https://tile.openstreetmap.org/{z}/{x}/{y}.png";
export const OSM_TILE_ATTRIBUTION =
  '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

/** Dashed circle for approximate (neighbourhood-level) locations. */
export function areaCircleStyle(type: ReportType, emphasised: boolean): L.PathOptions {
  const color = type === "LOST" ? "var(--lost)" : "var(--found)";
  return {
    color,
    fillColor: color,
    weight: emphasised ? 2 : 1.25,
    dashArray: "5 5",
    fillOpacity: emphasised ? 0.14 : 0.06,
    opacity: emphasised ? 0.9 : 0.55,
  };
}
