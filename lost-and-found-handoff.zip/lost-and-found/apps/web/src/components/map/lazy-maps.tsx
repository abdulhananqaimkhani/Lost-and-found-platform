"use client";

import dynamic from "next/dynamic";

function MapPlaceholder() {
  return (
    <div className="grid h-full w-full place-items-center bg-[#e4e8e6] text-sm text-ink-muted" role="status">
      Loading map…
    </div>
  );
}

/** Leaflet touches `window`, so maps are client-only and split into their own chunks. */
export const LazyReportMap = dynamic(() => import("./report-map"), { ssr: false, loading: MapPlaceholder });
export const LazyMiniMap = dynamic(() => import("./mini-map"), { ssr: false, loading: MapPlaceholder });
