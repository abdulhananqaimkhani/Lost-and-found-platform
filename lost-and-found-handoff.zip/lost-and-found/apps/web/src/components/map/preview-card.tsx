import Link from "next/link";
import { formatPosted } from "@/lib/format";
import { PRECISION_LABEL } from "@/lib/labels";
import type { MapReportProperties } from "@/lib/types";
import { LocationLine, PlatformLabel, StatusBadge, TypeMark } from "../reports/report-bits";

/** Compact report card shown in the map popup (hover on desktop, tap on touch devices). */
export function PreviewCard({ report }: { report: MapReportProperties }) {
  return (
    <div className="p-3.5" data-testid="map-preview" data-report-id={report.id}>
      <div className="flex items-center gap-2 pr-5">
        <TypeMark type={report.report_type} />
        <StatusBadge status={report.status} />
      </div>
      <p className="mt-1.5 text-[15px] leading-snug font-semibold text-ink">{report.item_name}</p>
      {report.description && <p className="mt-1 line-clamp-2 text-ink-muted">{report.description}</p>}
      <div className="mt-2.5 space-y-1 text-[12.5px] text-ink-muted">
        <LocationLine locationText={report.location_text} precision={report.location_precision} className="max-w-full text-ink" />
        {report.location_precision === "NEIGHBOURHOOD" && (
          <p className="pl-5 text-ink-faint">{PRECISION_LABEL.NEIGHBOURHOOD}: the circle shows roughly where</p>
        )}
        <p className="flex justify-between gap-3 pl-5">
          <span>{formatPosted(report.reported_at)}</span>
          <PlatformLabel platform={report.primary_platform} />
        </p>
      </div>
      <Link
        href={`/reports/${report.id}`}
        className="mt-3 flex h-8 items-center justify-center rounded-lg bg-ink text-[13px] font-medium !text-white hover:bg-ink/85"
      >
        View details
      </Link>
    </div>
  );
}
