/**
 * Leaflet divIcons for report markers. Visual language:
 *  - LOST  = hollow (white body, crimson outline + ring): the item is still missing.
 *  - FOUND = filled (teal body, white dot): the item has been located.
 *  - Exact places (POI/street) get a pin; approximate areas get a round dot (no pin tip),
 *    and the map also draws a dashed circle for the area, so an approximate location is never
 *    presented as an exact spot.
 * Shape differs as well as colour, so the two types stay distinguishable for colour-blind users.
 */
import L from "leaflet";
import type { ReportType } from "@/lib/types";

export type MarkerState = "default" | "hovered" | "selected";
export type MarkerKind = "pin" | "area";

const cache = new Map<string, L.DivIcon>();

function pinSvg(type: ReportType): string {
  const body =
    type === "LOST"
      ? `<path d="M14 34.5S3.5 23.6 3.5 14.6a10.5 10.5 0 0 1 21 0C24.5 23.6 14 34.5 14 34.5Z" fill="#fff" stroke="var(--lost)" stroke-width="2.5"/>
         <circle cx="14" cy="14.5" r="4.4" fill="none" stroke="var(--lost)" stroke-width="2.6"/>`
      : `<path d="M14 34.5S3.5 23.6 3.5 14.6a10.5 10.5 0 0 1 21 0C24.5 23.6 14 34.5 14 34.5Z" fill="var(--found)" stroke="#fff" stroke-width="1.5"/>
         <circle cx="14" cy="14.5" r="4.4" fill="#fff"/>`;
  return `<svg width="28" height="36" viewBox="0 0 28 36" style="filter: drop-shadow(0 1px 1.5px rgb(24 32 44 / .35))">${body}</svg>`;
}

function areaSvg(type: ReportType): string {
  const dot =
    type === "LOST"
      ? `<circle cx="11" cy="11" r="7" fill="#fff" stroke="var(--lost)" stroke-width="3.2"/>`
      : `<circle cx="11" cy="11" r="8" fill="var(--found)" stroke="#fff" stroke-width="2"/>`;
  return `<svg class="lf-dot" width="22" height="22" viewBox="0 0 22 22" style="filter: drop-shadow(0 1px 1.5px rgb(24 32 44 / .35))">${dot}</svg>`;
}

export function reportIcon(id: string, type: ReportType, kind: MarkerKind, state: MarkerState): L.DivIcon {
  const key = `${id}|${type}|${kind}|${state}`;
  const cached = cache.get(key);
  if (cached) return cached;
  const isPin = kind === "pin";
  const icon = L.divIcon({
    className: "lf-marker",
    html: `<div data-report-id="${id}" data-type="${type}" data-kind="${kind}" data-state="${state}">${
      isPin ? pinSvg(type) : areaSvg(type)
    }</div>`,
    iconSize: isPin ? [28, 36] : [22, 22],
    iconAnchor: isPin ? [14, 35] : [11, 11],
    popupAnchor: isPin ? [0, -34] : [0, -10],
  });
  cache.set(key, icon);
  return icon;
}

/** Cluster bubble: count in the middle, outer ring split by the share of LOST vs FOUND reports. */
export function clusterIcon(count: number, lost: number): L.DivIcon {
  const size = count < 10 ? 34 : count < 50 ? 40 : 46;
  const key = `cluster|${count}|${lost}|${size}`;
  const cached = cache.get(key);
  if (cached) return cached;
  const r = size / 2 - 2.5;
  const c = 2 * Math.PI * r;
  const lostLen = (lost / count) * c;
  const ring = `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="position:absolute;inset:0;transform:rotate(-90deg)">
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="var(--found)" stroke-width="4"/>
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="var(--lost)" stroke-width="4" stroke-dasharray="${lostLen} ${c}"/>
    </svg>`;
  const icon = L.divIcon({
    className: "lf-cluster",
    html: `<div data-cluster-count="${count}" style="position:relative">${ring}<span style="position:relative">${count}</span></div>`,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
  cache.set(key, icon);
  return icon;
}
