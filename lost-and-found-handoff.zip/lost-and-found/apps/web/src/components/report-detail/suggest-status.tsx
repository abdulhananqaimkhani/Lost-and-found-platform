"use client";

import { CircleCheck, Flag } from "lucide-react";
import { useId, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Textarea } from "@/components/ui/textarea";
import { dataSource } from "@/lib/data";
import type { SuggestionType } from "@/lib/types";

const MAX_REASON = 500;

const OPTION_TEXT: Record<SuggestionType, { title: string; hint: string }> = {
  RESOLVED: { title: "The item has been returned", hint: "For example, the original post was updated to say it was found." },
  INACCURATE: { title: "Something in this listing is wrong", hint: "Wrong place, wrong item, or not a lost-and-found post." },
};

/**
 * Anonymous status suggestions. A suggestion never changes the public status by itself;
 * the backend stores it, rate-limits it, and the status changes only after verification.
 */
export function SuggestStatus({
  reportId,
  initialCounts,
}: {
  reportId: string;
  initialCounts: { RESOLVED: number; INACCURATE: number };
}) {
  const id = useId();
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<SuggestionType>("RESOLVED");
  const [reason, setReason] = useState("");
  const [honeypot, setHoneypot] = useState("");
  const [sending, setSending] = useState(false);
  const [counts, setCounts] = useState(initialCounts);

  const openWith = (t: SuggestionType) => {
    setType(t);
    setOpen(true);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Bots fill hidden fields; people don't. Pretend success without sending anything.
    if (honeypot) {
      setOpen(false);
      return;
    }
    setSending(true);
    try {
      const result = await dataSource.suggestStatus(reportId, type, reason.trim());
      if (result.accepted) {
        setCounts((c) => ({ ...c, [type]: c[type] + 1 }));
        toast.success(result.message);
        setOpen(false);
        setReason("");
      } else {
        toast.error(result.message);
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The suggestion wasn't sent. Try again.");
    } finally {
      setSending(false);
    }
  };

  return (
    <section aria-labelledby={`${id}-title`} className="rounded-xl border border-line bg-surface p-5">
      <h2 id={`${id}-title`} className="text-base font-semibold text-ink">
        Is this listing out of date or wrong?
      </h2>
      <p className="mt-1 max-w-[62ch] text-sm text-ink-muted">
        Let us know. Suggestions are checked before the listing changes, so one anonymous report can&apos;t close it.
      </p>
      {(counts.RESOLVED > 0 || counts.INACCURATE > 0) && (
        <ul className="mt-3 space-y-1 text-sm text-ink" data-testid="suggestion-counts">
          {counts.RESOLVED > 0 && (
            <li>
              {counts.RESOLVED} {counts.RESOLVED === 1 ? "person says" : "people say"} the item has been returned
            </li>
          )}
          {counts.INACCURATE > 0 && (
            <li>
              {counts.INACCURATE} {counts.INACCURATE === 1 ? "person says" : "people say"} something here is wrong
            </li>
          )}
        </ul>
      )}
      <div className="mt-4 flex flex-wrap gap-2">
        <Button variant="outline" onClick={() => openWith("RESOLVED")}>
          <CircleCheck aria-hidden />
          Suggest as resolved
        </Button>
        <Button variant="ghost" onClick={() => openWith("INACCURATE")} className="text-ink-muted">
          <Flag aria-hidden />
          Report a problem
        </Button>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <form onSubmit={submit}>
            <DialogHeader>
              <DialogTitle>Send a suggestion</DialogTitle>
              <DialogDescription>
                The listing keeps its current status until the suggestion is verified.
              </DialogDescription>
            </DialogHeader>
            <RadioGroup value={type} onValueChange={(v) => setType(v as SuggestionType)} className="mt-4 gap-2">
              {(Object.keys(OPTION_TEXT) as SuggestionType[]).map((t) => (
                <Label
                  key={t}
                  htmlFor={`${id}-${t}`}
                  className="flex cursor-pointer items-start gap-3 rounded-lg border border-line p-3 font-normal has-[[data-state=checked]]:border-ink"
                >
                  <RadioGroupItem id={`${id}-${t}`} value={t} className="mt-0.5" />
                  <span>
                    <span className="block text-sm font-medium text-ink">{OPTION_TEXT[t].title}</span>
                    <span className="mt-0.5 block text-xs text-ink-muted">{OPTION_TEXT[t].hint}</span>
                  </span>
                </Label>
              ))}
            </RadioGroup>
            <Label htmlFor={`${id}-reason`} className="mt-4 block text-sm font-medium">
              How do you know? <span className="font-normal text-ink-muted">(optional)</span>
            </Label>
            <Textarea
              id={`${id}-reason`}
              value={reason}
              onChange={(e) => setReason(e.target.value.slice(0, MAX_REASON))}
              rows={3}
              className="mt-1.5"
              placeholder="For example: the owner posted that they got it back."
            />
            <p className="mt-1 text-right text-xs text-ink-faint">
              {reason.length}/{MAX_REASON}
            </p>
            <input
              type="text"
              name="website"
              tabIndex={-1}
              autoComplete="off"
              value={honeypot}
              onChange={(e) => setHoneypot(e.target.value)}
              className="absolute -left-[9999px] h-0 w-0 opacity-0"
              aria-hidden="true"
            />
            <DialogFooter className="mt-4">
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={sending}>
                {sending ? "Sending…" : "Send suggestion"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </section>
  );
}
