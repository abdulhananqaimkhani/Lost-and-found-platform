import { ArrowLeft, ExternalLink } from "lucide-react";
import Link from "next/link";
import { formatDate, formatDateTime, formatDistance, formatPercent } from "@/lib/format";
import { isMappable } from "@/lib/geo";
import {
  CATEGORY_LABEL,
  LANGUAGE_LABEL,
  PLATFORM_LABEL,
  PRECISION_DESCRIPTION,
  PRECISION_LABEL,
  STATUS_DESCRIPTION,
} from "@/lib/labels";
import type { MatchSummary, ReportDetail, SourceRef } from "@/lib/types";
import { cn } from "@/lib/utils";
import { LazyMiniMap } from "../map/lazy-maps";
import { CategoryIcon, ConfidenceMeter, PrecisionIcon, StatusBadge, TypeMark } from "../reports/report-bits";
import { SuggestStatus } from "./suggest-status";

const URDU_SCRIPT = /[؀-ۿ]/;

export function ReportDetailView({ report: r, matches }: { report: ReportDetail; matches: MatchSummary[] }) {
  const mapped = r.latitude !== null && r.longitude !== null && isMappable(r.location_precision);
  const urduLocation = r.location_text !== null && URDU_SCRIPT.test(r.location_text);

  return (
    <article className="mx-auto w-full max-w-6xl px-4 pt-5 pb-16 lg:px-6">
      <Link href="/" className="inline-flex items-center gap-1.5 rounded-md text-sm text-ink-muted hover:text-ink">
        <ArrowLeft aria-hidden className="size-4" />
        Back to the map
      </Link>

      {/* Mobile order: summary, map, details. Desktop: summary and details left, sticky map right. */}
      <div className="mt-5 grid gap-x-10 gap-y-7 lg:grid-cols-[1fr_360px]">
        <header className="min-w-0 lg:col-start-1 lg:row-start-1">
          <div className="flex flex-wrap items-center gap-2.5">
            <TypeMark type={r.report_type} className="text-sm" />
            <StatusBadge status={r.status} showActive />
          </div>
          <h1 className="mt-2 text-[30px] leading-[1.15] font-semibold tracking-[-0.02em] text-ink sm:text-[34px]">
            {r.item_name}
          </h1>
          {r.description && <p className="mt-3 max-w-[62ch] text-[17px] leading-relaxed text-ink">{r.description}</p>}
          <p className="mt-3 max-w-[62ch] text-sm text-ink-muted">{STATUS_DESCRIPTION[r.status]}</p>
        </header>

        <aside aria-label="Location" className="lg:sticky lg:top-20 lg:col-start-2 lg:row-span-2 lg:row-start-1 lg:self-start">
          {mapped ? (
            <div className="isolate h-56 overflow-hidden rounded-xl border border-line sm:h-64 lg:h-72">
              <LazyMiniMap
                id={r.id}
                type={r.report_type}
                latitude={r.latitude!}
                longitude={r.longitude!}
                precision={r.location_precision}
                radiusM={r.location_radius_m}
              />
            </div>
          ) : (
            <div className="grid h-32 place-items-center rounded-xl border border-dashed border-line-strong bg-surface px-6 text-center text-sm text-ink-muted lg:h-40">
              Not shown on the map
            </div>
          )}
          <div className="mt-3 flex gap-2 text-sm">
            <PrecisionIcon precision={r.location_precision} className="mt-0.5 text-ink-muted" />
            <p className="text-ink-muted">
              <span className="font-medium text-ink">{PRECISION_LABEL[r.location_precision]}.</span>{" "}
              {PRECISION_DESCRIPTION[r.location_precision]}
            </p>
          </div>
        </aside>

        <div className="min-w-0 lg:col-start-1 lg:row-start-2">
          <dl className="grid grid-cols-1 gap-x-8 border-t border-line sm:grid-cols-2">
            <Fact label="Category">
              <span className="inline-flex items-center gap-2">
                <CategoryIcon category={r.item_category} className="text-ink-muted" />
                {CATEGORY_LABEL[r.item_category]}
              </span>
            </Fact>
            <Fact label="When it happened">
              {r.incident_date ? (
                <>
                  {formatDate(r.incident_date)}
                  {r.date_precision === "APPROXIMATE" && (
                    <span className="ml-1.5 text-sm text-ink-muted">(approximate, worked out from the post)</span>
                  )}
                </>
              ) : (
                <span className="text-ink-muted">Not stated in the post</span>
              )}
            </Fact>
            <Fact label="Location in the post">
              {r.location_text ? (
                <span lang={urduLocation ? "ur" : undefined} dir={urduLocation ? "rtl" : undefined}>
                  {r.location_text}
                </span>
              ) : (
                <span className="text-ink-muted">Not stated in the post</span>
              )}
            </Fact>
            <Fact label="Location accuracy">
              <span className="inline-flex items-center gap-1.5">
                <PrecisionIcon precision={r.location_precision} className="text-ink-muted" />
                {PRECISION_LABEL[r.location_precision]}
              </span>
            </Fact>
            <Fact label="First posted">{formatDateTime(r.reported_at)}</Fact>
            <Fact label="Collected by Lost & Found Finder">{formatDateTime(r.collected_at)}</Fact>
            <Fact label="Language of the post">{LANGUAGE_LABEL[r.language]}</Fact>
            <Fact label="AI extraction confidence">
              <ConfidenceMeter value={r.confidence_score} />
              {r.needs_review && <span className="ml-2 text-sm text-caution">Some details need review</span>}
            </Fact>
          </dl>

          <section aria-labelledby="sources-title" className="mt-10">
            <h2 id="sources-title" className="text-lg font-semibold text-ink">
              {r.sources.length === 1 ? "Original post" : `Original posts (${r.sources.length})`}
            </h2>
            <p className="mt-1 text-sm text-ink-muted">
              Phone numbers and ID numbers are hidden here. Contact the person through the original post.
            </p>
            <ol className="mt-4 space-y-3">
              {r.sources.map((s, i) => (
                <SourceCard key={s.id} source={s} index={i} total={r.sources.length} />
              ))}
            </ol>
          </section>

          <section aria-labelledby="matches-title" className="mt-10">
            <h2 id="matches-title" className="text-lg font-semibold text-ink">
              Possible matches
            </h2>
            {matches.length === 0 ? (
              <p className="mt-1 text-sm text-ink-muted">
                No {r.report_type === "LOST" ? "found" : "lost"} report looks similar yet. New posts are checked as they
                arrive.
              </p>
            ) : (
              <>
                <p className="mt-1 max-w-[62ch] text-sm text-ink-muted">
                  These {r.report_type === "LOST" ? "found" : "lost"} reports look similar, based on the item, its
                  description, where and when. They are suggestions, not confirmed matches.
                </p>
                <ul className="mt-4 divide-y divide-line rounded-xl border border-line bg-surface">
                  {matches.map((m) => (
                    <MatchRow key={m.report.id} match={m} />
                  ))}
                </ul>
              </>
            )}
          </section>

          <div className="mt-10">
            <SuggestStatus reportId={r.id} initialCounts={r.suggestion_counts} />
          </div>
        </div>
      </div>
    </article>
  );
}

function Fact({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="border-b border-line py-3">
      <dt className="text-[13px] text-ink-muted">{label}</dt>
      <dd className="mt-0.5 text-[15px] text-ink">{children}</dd>
    </div>
  );
}

function SourceCard({ source: s, index, total }: { source: SourceRef; index: number; total: number }) {
  const urdu = URDU_SCRIPT.test(s.excerpt);
  const isDemo = s.platform === "DEMO";
  const isArticle = s.platform === "RSS";
  return (
    <li className="rounded-xl border border-line bg-surface p-4">
      <div className="flex flex-wrap items-baseline justify-between gap-2 text-[13px] text-ink-muted">
        <span>
          <span className="font-medium text-ink">{s.publisher || PLATFORM_LABEL[s.platform]}</span>
          {total > 1 && <span className="ml-2">Source {index + 1} of {total}</span>}
        </span>
        <span>
          {isArticle ? "Published" : "Posted"} {formatDateTime(s.published_at)}
        </span>
      </div>
      {s.publisher_byline && <p className="mt-1 text-[13px] text-ink-muted">By {s.publisher_byline}</p>}
      <blockquote
        lang={urdu ? "ur" : undefined}
        dir={urdu ? "rtl" : undefined}
        className={cn("mt-2.5 text-[15px] leading-relaxed text-ink", urdu && "text-[17px]")}
      >
        {s.excerpt}
      </blockquote>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        {isDemo ? (
          <p className="text-[13px] text-ink-muted">This is a demo post, so there is no original to open.</p>
        ) : (
          <a
            href={s.original_url}
            target="_blank"
            rel="noopener noreferrer nofollow"
            className="inline-flex h-8 items-center gap-1.5 rounded-lg bg-ink px-3 text-[13px] font-medium text-white hover:bg-ink/85"
          >
            {isArticle ? "Open original article" : "Open original post"}
            <ExternalLink aria-hidden className="size-3.5" />
          </a>
        )}
        <span className="text-xs text-ink-faint">Collected {formatDateTime(s.collected_at)}</span>
      </div>
      {isArticle && s.license_url?.startsWith("https://") && (
        <p className="mt-2.5 text-xs text-ink-muted">
          Feed excerpt with formatting and contact details edited.{" "}
          <a href={s.license_url} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2">
            Article license
          </a>
        </p>
      )}
    </li>
  );
}

function MatchRow({ match: m }: { match: MatchSummary }) {
  const reasons: string[] = [];
  if (m.breakdown.category === 1) reasons.push("Same kind of item");
  if (m.distance_km !== null) reasons.push(`${formatDistance(m.distance_km)} apart`);
  if (m.days_apart !== null) reasons.push(m.days_apart === 0 ? "Same day" : `${m.days_apart} ${m.days_apart === 1 ? "day" : "days"} apart`);
  if (m.breakdown.attributes === 1) reasons.push("Same colour");
  return (
    <li>
      <Link href={`/reports/${m.report.id}`} className="flex items-center gap-4 p-4 hover:bg-hover/50">
        <span className="grid size-12 shrink-0 place-items-center rounded-full border border-line text-sm font-semibold text-ink" title="Similarity score">
          {formatPercent(m.score)}
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-2">
            <TypeMark type={m.report.report_type} />
          </span>
          <span className="mt-0.5 block truncate font-medium text-ink">{m.report.item_name}</span>
          <span className="mt-0.5 flex flex-wrap gap-x-3 text-[13px] text-ink-muted">
            {reasons.map((reason) => (
              <span key={reason}>{reason}</span>
            ))}
          </span>
        </span>
      </Link>
    </li>
  );
}
