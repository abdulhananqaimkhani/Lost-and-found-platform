"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/", label: "Map" },
  { href: "/reports", label: "Explore" },
  { href: "/about", label: "How it works" },
] as const;

export function SiteNav() {
  const pathname = usePathname();
  return (
    <nav aria-label="Main" className="flex min-w-0 flex-1 items-center gap-0.5 sm:ml-3">
      {LINKS.map((link) => {
        const active = link.href === "/" ? pathname === "/" : pathname.startsWith(link.href);
        return (
          <Link
            key={link.href}
            href={link.href}
            aria-current={active ? "page" : undefined}
            className={cn(
              "rounded-md px-2 py-1.5 text-sm text-ink-muted transition-colors hover:bg-hover hover:text-ink sm:px-2.5",
              active && "font-medium text-ink",
              link.href === "/about" && "hidden sm:block",
            )}
          >
            {link.label}
          </Link>
        );
      })}
    </nav>
  );
}
