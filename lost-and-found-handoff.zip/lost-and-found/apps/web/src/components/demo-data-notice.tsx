"use client";

import Link from "next/link";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { dataSource } from "@/lib/data";
import { useStats } from "@/lib/queries";

/**
 * Visible whenever demo records are on screen: always in mock mode, and in API mode while the
 * backend still serves the labelled demo dataset (SHOW_DEMO_DATA=true).
 */
export function DemoDataNotice() {
  const isMock = dataSource.kind === "mock";
  const stats = useStats(!isMock);
  if (!isMock && !stats.data?.by_platform.DEMO) return null;
  return (
    <Popover>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="ml-auto shrink-0 rounded-full border border-caution/30 bg-caution-soft px-2.5 py-1 text-xs font-medium text-caution"
          aria-label="Demo data: what this means"
        >
          Demo<span className="hidden sm:inline">&nbsp;data</span>
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 text-sm">
        <p className="font-medium text-ink">{isMock ? "You're viewing demo reports" : "Some reports are demo data"}</p>
        <p className="mt-1.5 text-ink-muted">
          {isMock ? "These posts" : "Reports labelled “Demo data”"} were written by hand to show how the app
          works. They don&apos;t come from real people. Their locations are real Karachi places from OpenStreetMap.
        </p>
        <Link href="/about#demo-data" className="mt-2 inline-block text-sm font-medium text-ink underline underline-offset-4">
          About the demo data
        </Link>
      </PopoverContent>
    </Popover>
  );
}
