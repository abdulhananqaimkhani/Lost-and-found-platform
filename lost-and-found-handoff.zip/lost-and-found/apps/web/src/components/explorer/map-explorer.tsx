"use client";

import { ChevronDown, ChevronUp } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import { useFilters } from "@/hooks/use-filters";
import { useIsDesktop } from "@/hooks/use-media-query";
import { countActiveFilters, serializeFilters } from "@/lib/filters";
import { isMappable, padBBox } from "@/lib/geo";
import { useAreas, useMapReports, useReports } from "@/lib/queries";
import { useSelection } from "@/lib/store/selection";
import type { BBox, MapFeature, ReportSummary } from "@/lib/types";
import { cn } from "@/lib/utils";
import { FilterBar } from "../filters/filter-bar";
import { LazyReportMap } from "../map/lazy-maps";
import type { ReportPoint } from "../map/report-map";
import { ReportList, ReportListSkeleton } from "../reports/report-list";

const PAGE_STEP = 30;

function featureToPoint(f: MapFeature): ReportPoint {
  const [longitude, latitude] = f.geometry.coordinates;
  return { ...f.properties, latitude, longitude };
}

function summaryToPoint(r: ReportSummary): ReportPoint | null {
  if (r.latitude === null || r.longitude === null || !isMappable(r.location_precision)) return null;
  return {
    id: r.id,
    report_type: r.report_type,
    item_name: r.item_name,
    item_category: r.item_category,
    description: r.description,
    location_text: r.location_text,
    location_precision: r.location_precision,
    location_radius_m: r.location_radius_m,
    status: r.status,
    reported_at: r.reported_at,
    primary_platform: r.primary_platform,
    latitude: r.latitude,
    longitude: r.longitude,
  };
}

/** Round to ~100 m so tiny map nudges don't refetch. */
function roundBBox(b: BBox): BBox {
  return b.map((v) => Math.round(v * 1000) / 1000) as BBox;
}

export function MapExplorer() {
  const { filters, setFilters, clearFilters } = useFilters();
  const isDesktop = useIsDesktop();
  const selectedId = useSelection((s) => s.selectedId);
  const clearSelection = useSelection((s) => s.clearSelection);

  const [view, setView] = useState<BBox | null>(null);
  const onViewChange = useCallback((bbox: BBox) => setView(roundBBox(bbox)), []);
  const debouncedView = useDebouncedValue(view, 200);

  const [followMap, setFollowMap] = useState(true);
  const [sheetOpen, setSheetOpen] = useState(false);

  // "Show more" limit, reset whenever the filters change.
  const filterKey = serializeFilters({ ...filters, page: 1 }).toString();
  const [limitState, setLimitState] = useState({ key: filterKey, limit: PAGE_STEP });
  const limit = limitState.key === filterKey ? limitState.limit : PAGE_STEP;

  // A selection from a previous filter set may no longer be relevant.
  useEffect(() => {
    clearSelection();
  }, [filterKey, clearSelection]);
  useEffect(() => () => clearSelection(), [clearSelection]);

  const listFilters = useMemo(() => ({ ...filters, page: 1, sort: "newest" as const }), [filters]);
  const markerQuery = useMapReports(listFilters, debouncedView ? padBBox(debouncedView, 0.5) : null);
  const listQuery = useReports(
    listFilters,
    { bbox: followMap ? debouncedView : null, located: followMap ? true : null, pageSize: limit },
    !followMap || debouncedView !== null,
  );
  const unmappedQuery = useReports(listFilters, { located: false, pageSize: 50 }, followMap);
  const { data: areas } = useAreas();
  const focusArea = useMemo(() => areas?.find((a) => a.key === filters.area) ?? null, [areas, filters.area]);

  const points = useMemo(() => markerQuery.data?.features.map(featureToPoint) ?? [], [markerQuery.data]);
  const listItems = useMemo(() => listQuery.data?.items ?? [], [listQuery.data]);
  const unmapped = useMemo(() => unmappedQuery.data?.items ?? [], [unmappedQuery.data]);

  const selected = useMemo(() => {
    if (!selectedId) return null;
    const fromMarkers = points.find((p) => p.id === selectedId);
    if (fromMarkers) return fromMarkers;
    const fromList = listItems.find((r) => r.id === selectedId);
    return fromList ? summaryToPoint(fromList) : null;
  }, [selectedId, points, listItems]);

  const total = listQuery.data?.total ?? 0;
  const loading = listQuery.isPending && listQuery.fetchStatus !== "idle";
  const countLabel = loading
    ? "Loading reports…"
    : `${total} ${total === 1 ? "report" : "reports"}${followMap ? " in this map area" : " in Karachi"}`;

  const listPanel = (
    <ListPanel
      countLabel={countLabel}
      followMap={followMap}
      onFollowMapChange={setFollowMap}
      loading={loading}
      error={listQuery.error}
      onRetry={() => listQuery.refetch()}
      items={listItems}
      total={total}
      onShowMore={() => setLimitState({ key: filterKey, limit: limit + PAGE_STEP })}
      unmapped={followMap ? unmapped : []}
      hasFilters={countActiveFilters(filters) > 0}
      onClearFilters={clearFilters}
      onSelected={() => !isDesktop && setSheetOpen(false)}
      showCount={isDesktop}
    />
  );

  return (
    <main className="flex h-[calc(100dvh-3.5rem)] min-h-0 flex-col">
      <div className="border-b border-line bg-surface px-3 py-2.5 lg:px-5">
        <h1 className="sr-only">Lost and found reports in Karachi</h1>
        <FilterBar filters={filters} setFilters={setFilters} clearFilters={clearFilters} />
      </div>

      <div className="relative min-h-0 flex-1 lg:grid lg:grid-cols-[minmax(340px,400px)_1fr]">
        {isDesktop && (
          <aside aria-label="Report list" className="flex min-h-0 flex-col border-r border-line bg-surface">
            {listPanel}
          </aside>
        )}

        {/* `isolate` keeps Leaflet's internal z-indexes from covering popovers and dialogs. */}
        <div className="isolate h-full min-h-0">
          <LazyReportMap points={points} selected={selected} focusArea={focusArea} onViewChange={onViewChange} />
        </div>

        {!isDesktop && (
          <section
            aria-label="Report list"
            className={cn(
              "absolute inset-x-0 bottom-0 z-10 flex flex-col rounded-t-2xl border-t border-line bg-surface shadow-[0_-8px_24px_rgb(24_32_44/0.12)] transition-[height] duration-200 ease-out",
              sheetOpen ? "h-[68%]" : "h-14",
            )}
          >
            <button
              type="button"
              onClick={() => setSheetOpen((o) => !o)}
              aria-expanded={sheetOpen}
              className="flex h-14 shrink-0 items-center justify-between px-4 text-sm font-medium text-ink"
            >
              <span aria-live="polite" data-testid="result-count">
                {countLabel}
              </span>
              <span className="flex items-center gap-1 text-ink-muted">
                {sheetOpen ? "Show map" : "Show list"}
                {sheetOpen ? <ChevronDown className="size-4" /> : <ChevronUp className="size-4" />}
              </span>
            </button>
            {sheetOpen && <div className="flex min-h-0 flex-1 flex-col border-t border-line">{listPanel}</div>}
          </section>
        )}
      </div>
    </main>
  );
}

function ListPanel({
  countLabel,
  followMap,
  onFollowMapChange,
  loading,
  error,
  onRetry,
  items,
  total,
  onShowMore,
  unmapped,
  hasFilters,
  onClearFilters,
  onSelected,
  showCount,
}: {
  /** The mobile sheet already shows the count in its handle. */
  showCount: boolean;
  countLabel: string;
  followMap: boolean;
  onFollowMapChange: (v: boolean) => void;
  loading: boolean;
  error: Error | null;
  onRetry: () => void;
  items: ReportSummary[];
  total: number;
  onShowMore: () => void;
  unmapped: ReportSummary[];
  hasFilters: boolean;
  onClearFilters: () => void;
  onSelected: () => void;
}) {
  const [unmappedOpen, setUnmappedOpen] = useState(false);
  return (
    <>
      <div className="flex shrink-0 items-center justify-between gap-3 border-b border-line px-4 py-2.5">
        {showCount ? (
          <p className="text-sm font-medium text-ink" aria-live="polite" data-testid="result-count">
            {countLabel}
          </p>
        ) : (
          <span />
        )}
        <label className="flex cursor-pointer items-center gap-2 text-xs text-ink-muted">
          <Checkbox checked={followMap} onCheckedChange={(v) => onFollowMapChange(v === true)} />
          Match map view
        </label>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
        {error ? (
          <div className="p-5 text-sm">
            <p className="font-medium text-ink">Reports didn&apos;t load</p>
            <p className="mt-1 text-ink-muted">{error.message}</p>
            <Button variant="outline" size="sm" className="mt-3" onClick={onRetry}>
              Try again
            </Button>
          </div>
        ) : loading ? (
          <ReportListSkeleton />
        ) : items.length === 0 ? (
          <div className="p-5 text-sm">
            <p className="font-medium text-ink">No reports {followMap ? "in this part of the map" : "match"}</p>
            <p className="mt-1 text-ink-muted">
              {followMap ? "Zoom out or move the map, or search all of Karachi." : "Try fewer filters."}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              {followMap && (
                <Button variant="outline" size="sm" onClick={() => onFollowMapChange(false)}>
                  Search all of Karachi
                </Button>
              )}
              {hasFilters && (
                <Button variant="ghost" size="sm" onClick={onClearFilters}>
                  Clear filters
                </Button>
              )}
            </div>
          </div>
        ) : (
          <>
            <ReportList items={items} onSelected={onSelected} ariaLabel="Reports" />
            {items.length < total && (
              <div className="p-3">
                <Button variant="outline" className="w-full" onClick={onShowMore}>
                  Show more reports
                </Button>
              </div>
            )}
          </>
        )}

        {unmapped.length > 0 && (
          <div className="border-t border-line">
            <button
              type="button"
              onClick={() => setUnmappedOpen((o) => !o)}
              aria-expanded={unmappedOpen}
              className="flex w-full items-center justify-between px-4 py-3 text-left text-sm text-ink-muted hover:bg-hover/60"
            >
              <span>
                <span className="font-medium text-ink">
                  {unmapped.length} {unmapped.length === 1 ? "report" : "reports"} without a map location
                </span>
                <span className="block text-xs">The post doesn&apos;t say where, or only names the city.</span>
              </span>
              {unmappedOpen ? <ChevronUp className="size-4" /> : <ChevronDown className="size-4" />}
            </button>
            {unmappedOpen && <ReportList items={unmapped} ariaLabel="Reports without a map location" />}
          </div>
        )}
      </div>
    </>
  );
}
