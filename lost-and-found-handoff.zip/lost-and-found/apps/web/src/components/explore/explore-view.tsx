"use client";

import { ChevronLeft, ChevronRight, SlidersHorizontal } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useFilters } from "@/hooks/use-filters";
import { countActiveFilters, type ReportFilters } from "@/lib/filters";
import { formatDistance, formatRelative } from "@/lib/format";
import { CATEGORY_LABEL } from "@/lib/labels";
import { useAreas, useCategories, useReports } from "@/lib/queries";
import { ITEM_CATEGORIES, type ReportSummary } from "@/lib/types";
import { AreaFilter, DateFilter, SearchField, SortControl, StatusFilter, TypeToggle } from "../filters/filter-controls";
import { CategoryIcon, ConfidenceMeter, LocationLine, PlatformLabel, StatusBadge, TypeMark } from "../reports/report-bits";
import { ReportListSkeleton } from "../reports/report-list";

const PAGE_SIZE = 20;

export function ExploreView() {
  const { filters, setFilters, clearFilters } = useFilters();
  const { data, error, isPending, refetch, isFetching } = useReports(filters, { pageSize: PAGE_SIZE });
  const { data: areas } = useAreas();
  const areaLabel = areas?.find((a) => a.key === filters.area)?.label ?? null;
  const active = countActiveFilters(filters);
  const pages = data ? Math.max(1, Math.ceil(data.total / data.page_size)) : 1;

  const filterPanel = <FilterPanel filters={filters} setFilters={setFilters} clearFilters={clearFilters} />;

  return (
    <main className="mx-auto w-full max-w-6xl flex-1 px-4 pt-7 pb-16 lg:px-6">
      <h1 className="text-[28px] leading-tight font-semibold tracking-[-0.015em] text-ink">Explore reports</h1>
      <p className="mt-1 max-w-[60ch] text-ink-muted">
        Every lost and found post collected so far. Search by item, or narrow it down by place and date.
      </p>

      <div className="mt-5 flex gap-2">
        <SearchField value={filters.q} onChange={(q) => setFilters({ q })} className="flex-1 lg:max-w-xl" />
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="outline" className="h-9 border-line-strong bg-surface lg:hidden">
              <SlidersHorizontal aria-hidden />
              Filters{active > 0 ? ` (${active})` : ""}
            </Button>
          </SheetTrigger>
          <SheetContent side="bottom" className="max-h-[85dvh] overflow-y-auto rounded-t-2xl px-5 pb-8">
            <SheetHeader className="px-0">
              <SheetTitle>Filters</SheetTitle>
            </SheetHeader>
            {filterPanel}
          </SheetContent>
        </Sheet>
      </div>

      <div className="mt-6 grid gap-8 lg:grid-cols-[232px_1fr]">
        <aside aria-label="Filters" className="hidden lg:block">
          {filterPanel}
        </aside>

        <section aria-label="Results" className="min-w-0">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-3">
            <p className="text-sm font-medium text-ink" aria-live="polite" data-testid="result-count">
              {isPending ? "Loading reports…" : `${data?.total ?? 0} ${data?.total === 1 ? "report" : "reports"}`}
              {isFetching && !isPending && <span className="ml-2 font-normal text-ink-faint">Updating…</span>}
            </p>
            <SortControl filters={filters} setFilters={setFilters} areaLabel={areaLabel} />
          </div>

          {error ? (
            <div className="py-8 text-sm">
              <p className="font-medium text-ink">Reports didn&apos;t load</p>
              <p className="mt-1 text-ink-muted">{error.message}</p>
              <Button variant="outline" size="sm" className="mt-3" onClick={() => refetch()}>
                Try again
              </Button>
            </div>
          ) : isPending ? (
            <ReportListSkeleton rows={8} />
          ) : data && data.items.length === 0 ? (
            <div className="py-10 text-sm">
              <p className="font-medium text-ink">No reports match these filters</p>
              <p className="mt-1 text-ink-muted">Try a different spelling, a wider date range, or fewer filters.</p>
              {active > 0 && (
                <Button variant="outline" size="sm" className="mt-3" onClick={clearFilters}>
                  Clear filters
                </Button>
              )}
            </div>
          ) : (
            <ul className="divide-y divide-line" aria-label="Reports">
              {data?.items.map((r) => <ResultRow key={r.id} report={r} />)}
            </ul>
          )}

          {data && pages > 1 && (
            <nav aria-label="Pagination" className="mt-6 flex items-center justify-between border-t border-line pt-4">
              <Button
                variant="outline"
                disabled={filters.page <= 1}
                onClick={() => setFilters({ page: filters.page - 1 })}
              >
                <ChevronLeft aria-hidden />
                Previous
              </Button>
              <span className="text-sm text-ink-muted">
                Page {filters.page} of {pages}
              </span>
              <Button
                variant="outline"
                disabled={filters.page >= pages}
                onClick={() => setFilters({ page: filters.page + 1 })}
              >
                Next
                <ChevronRight aria-hidden />
              </Button>
            </nav>
          )}
        </section>
      </div>
    </main>
  );
}

function FilterPanel({
  filters,
  setFilters,
  clearFilters,
}: {
  filters: ReportFilters;
  setFilters: (patch: Partial<ReportFilters>) => void;
  clearFilters: () => void;
}) {
  const { data: counts } = useCategories();
  return (
    <div className="space-y-6">
      <div>
        <p className="mb-1.5 text-sm font-medium text-ink">Type</p>
        <TypeToggle value={filters.type} onChange={(type) => setFilters({ type })} />
      </div>
      <div className="flex flex-col items-start gap-2">
        <p className="text-sm font-medium text-ink">Place and date</p>
        <AreaFilter
          value={filters.area}
          onChange={(area) =>
            // Without an area or a shared location there is no point to measure distance from.
            setFilters(area === null && !filters.near && filters.sort === "distance" ? { area, sort: "newest" } : { area })
          }
        />
        <DateFilter date={filters.date} from={filters.from} to={filters.to} onChange={(patch) => setFilters(patch)} />
      </div>
      <fieldset className="space-y-0.5">
        <legend className="mb-1.5 text-sm font-medium text-ink">Category</legend>
        {ITEM_CATEGORIES.map((c) => (
          <label key={c} className="flex cursor-pointer items-center gap-2.5 py-1 text-sm text-ink">
            <Checkbox
              checked={filters.categories.includes(c)}
              onCheckedChange={(v) =>
                setFilters({
                  categories: v === true ? [...filters.categories, c] : filters.categories.filter((x) => x !== c),
                })
              }
            />
            <span className="flex-1">{CATEGORY_LABEL[c]}</span>
            <span className="text-xs text-ink-faint">{counts?.find((x) => x.category === c)?.count}</span>
          </label>
        ))}
      </fieldset>
      <StatusFilter value={filters.statuses} onChange={(statuses) => setFilters({ statuses })} />
      {countActiveFilters(filters) > 0 && (
        <Button variant="ghost" size="sm" onClick={clearFilters} className="-ml-2 text-ink-muted">
          Clear all filters
        </Button>
      )}
    </div>
  );
}

function ResultRow({ report: r }: { report: ReportSummary }) {
  return (
    <li>
      <Link
        href={`/reports/${r.id}`}
        className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 py-4 transition-colors hover:bg-hover/50 sm:grid-cols-[auto_1fr_auto] sm:px-2"
      >
        <span className="row-span-2 mt-0.5 grid size-10 place-items-center rounded-lg bg-surface text-ink-muted ring-1 ring-line">
          <CategoryIcon category={r.item_category} />
        </span>
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
            <TypeMark type={r.report_type} />
            <span className="text-[13px] text-ink-muted">{CATEGORY_LABEL[r.item_category]}</span>
            <StatusBadge status={r.status} />
          </div>
          <p className="mt-1 text-base leading-snug font-semibold text-ink">{r.item_name}</p>
          {r.description && <p className="mt-0.5 line-clamp-1 text-sm text-ink-muted">{r.description}</p>}
          <div className="mt-1.5 flex min-w-0 flex-wrap items-center gap-x-3 gap-y-1 text-[13px] text-ink-muted">
            <LocationLine locationText={r.location_text} precision={r.location_precision} className="max-w-full" />
            {r.distance_km !== undefined && r.distance_km !== null && (
              <span className="shrink-0">{formatDistance(r.distance_km)} away</span>
            )}
          </div>
        </div>
        <div className="col-start-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-ink-muted sm:col-start-3 sm:row-start-1 sm:flex-col sm:items-end sm:gap-1.5">
          <time dateTime={r.reported_at}>{formatRelative(r.reported_at)}</time>
          <PlatformLabel platform={r.primary_platform} />
          <ConfidenceMeter value={r.confidence_score} />
        </div>
      </Link>
    </li>
  );
}
