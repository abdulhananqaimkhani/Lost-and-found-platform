/** The brand mark is the product's visual language: a hollow ring (lost) meeting a filled dot (found). */
export function BrandMark({ size = 26 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 26 26" aria-hidden="true" className="shrink-0">
      <circle cx="9.5" cy="13" r="6.5" fill="none" stroke="var(--lost)" strokeWidth="3" />
      <circle cx="17.5" cy="13" r="6.5" fill="var(--found)" />
      {/* Lower-right arc of the ring redrawn over the dot, so the two shapes interlock like links. */}
      <circle cx="9.5" cy="13" r="6.5" fill="none" stroke="var(--lost)" strokeWidth="3" strokeDasharray="5.1 35.7" />
    </svg>
  );
}
