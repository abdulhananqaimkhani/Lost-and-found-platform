import Link from "next/link";
import { Suspense } from "react";
import { DemoDataNotice } from "./demo-data-notice";
import { BrandMark } from "./brand-mark";
import { SiteNav } from "./site-nav";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-[1100] border-b border-line bg-surface">
      <div className="flex h-14 min-w-0 items-center gap-2 px-3 sm:gap-4 sm:px-4 lg:px-5">
        <Link href="/" className="flex shrink-0 items-center gap-2 rounded-md sm:gap-2.5" aria-label="Lost & Found Finder, map">
          <BrandMark />
          <span className="text-[15px] font-semibold tracking-[-0.01em] text-ink">
            Lost &amp; Found <span className="hidden font-normal text-ink-muted sm:inline">Finder</span>
          </span>
        </Link>
        <Suspense fallback={<nav className="ml-2 flex-1" />}>
          <SiteNav />
        </Suspense>
        <DemoDataNotice />
      </div>
    </header>
  );
}
