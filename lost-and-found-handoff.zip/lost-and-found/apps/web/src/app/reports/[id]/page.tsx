import { notFound } from "next/navigation";
import { Suspense } from "react";
import { ReportDetailView } from "@/components/report-detail/report-detail-view";
import { dataSource } from "@/lib/data";

function DetailSkeleton() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 pt-5 lg:px-6" role="status" aria-label="Loading report">
      <div className="h-4 w-28 animate-pulse rounded bg-hover" />
      <div className="mt-8 h-8 w-2/3 max-w-md animate-pulse rounded bg-hover" />
      <div className="mt-4 h-4 w-full max-w-xl animate-pulse rounded bg-hover" />
    </div>
  );
}

async function ReportContent({ params }: { params: PageProps<"/reports/[id]">["params"] }) {
  const { id } = await params;
  const report = await dataSource.getReport(id);
  if (!report) notFound();
  const matches = await dataSource.getMatches(id);
  return <ReportDetailView report={report} matches={matches} />;
}

export default function ReportPage({ params }: PageProps<"/reports/[id]">) {
  return (
    <main className="flex-1">
      <Suspense fallback={<DetailSkeleton />}>
        <ReportContent params={params} />
      </Suspense>
    </main>
  );
}
