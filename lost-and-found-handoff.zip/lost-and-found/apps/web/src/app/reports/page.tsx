import type { Metadata } from "next";
import { Suspense } from "react";
import { ExploreView } from "@/components/explore/explore-view";

export const metadata: Metadata = { title: "Explore reports" };

export default function ReportsPage() {
  return (
    <Suspense fallback={<main className="mx-auto w-full max-w-6xl flex-1 px-4 pt-7 lg:px-6" />}>
      <ExploreView />
    </Suspense>
  );
}
