import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto w-full max-w-xl flex-1 px-4 pt-20 pb-16">
      <h1 className="text-2xl font-semibold text-ink">This report isn&apos;t here</h1>
      <p className="mt-2 text-ink-muted">
        It may have been removed because the original post was deleted, or the link is mistyped.
      </p>
      <div className="mt-6 flex gap-3">
        <Link href="/" className="inline-flex h-9 items-center rounded-lg bg-ink px-4 text-sm font-medium text-white hover:bg-ink/85">
          Go to the map
        </Link>
        <Link href="/reports" className="inline-flex h-9 items-center rounded-lg border border-line-strong bg-surface px-4 text-sm font-medium text-ink hover:bg-hover">
          Explore reports
        </Link>
      </div>
    </main>
  );
}
