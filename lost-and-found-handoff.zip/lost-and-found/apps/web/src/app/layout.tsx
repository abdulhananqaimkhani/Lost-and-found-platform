import type { Metadata, Viewport } from "next";
import { Noto_Nastaliq_Urdu, Schibsted_Grotesk } from "next/font/google";
import { SiteHeader } from "@/components/site-header";
import { Providers } from "./providers";
import "./globals.css";

const schibsted = Schibsted_Grotesk({
  variable: "--font-schibsted",
  subsets: ["latin", "latin-ext"],
  display: "swap",
});

// Used only for Urdu-script post text (lang="ur"), so it isn't preloaded on every page.
const nastaliq = Noto_Nastaliq_Urdu({
  variable: "--font-nastaliq",
  subsets: ["arabic"],
  weight: ["400", "600"],
  display: "swap",
  preload: false,
});

export const metadata: Metadata = {
  title: { default: "Lost & Found Finder · Karachi", template: "%s · Lost & Found Finder" },
  description:
    "Lost and found posts from across Karachi, collected from public sources and placed on one map.",
};

export const viewport: Viewport = {
  themeColor: "#ffffff",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={`${schibsted.variable} ${nastaliq.variable} h-full antialiased`}>
      <body className="flex min-h-dvh flex-col">
        <Providers>
          <SiteHeader />
          {children}
        </Providers>
      </body>
    </html>
  );
}
