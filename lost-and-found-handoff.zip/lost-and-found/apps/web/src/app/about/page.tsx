import type { Metadata } from "next";
import Link from "next/link";
import { PRECISION_DESCRIPTION, STATUS_DESCRIPTION, STATUS_LABEL } from "@/lib/labels";
import { REPORT_STATUSES } from "@/lib/types";

export const metadata: Metadata = { title: "How it works" };

const SOURCES: Array<{ name: string; status: string; note: string }> = [
  {
    name: "Global Voices Pakistan",
    status: "Connected",
    note: "The worker checks articles from the publisher’s Pakistan feed for Karachi lost-and-found notices. Listings link back to the article and credit the byline and license.",
  },
  {
    name: "Mastodon",
    status: "Connected",
    note: "Public hashtag timelines through Mastodon's open API. Only posts about lost or found items in Karachi are kept. Very few so far.",
  },
  {
    name: "News RSS feeds (Dawn, Express Tribune, The News, Google News)",
    status: "Not used",
    note: "Their terms allow personal use only or forbid reuse without written permission, so we don't show their content.",
  },
  {
    name: "X (Twitter)",
    status: "Switched off",
    note: "X charges per post read through its official API. The connector is built with a strict spending cap and runs only when an account is funded.",
  },
  {
    name: "Reddit",
    status: "Waiting for approval",
    note: "Reddit reviews every new API application. The connector turns on only if access is granted.",
  },
  {
    name: "Bluesky",
    status: "Optional",
    note: "Search needs a free account with an app password. It's off until one is set up.",
  },
  {
    name: "Facebook groups and Instagram",
    status: "Not supported",
    note: "Meta removed third-party access to group posts in 2024. We don't scrape or log in to get around that.",
  },
];

const PIPELINE = [
  {
    title: "Collect",
    body: "A background worker checks public social posts and news feeds on a schedule. Each listing links to the original source.",
  },
  {
    title: "Filter",
    body: "A quick keyword check in English, Roman Urdu and Urdu (kho gaya, mil gaya, گم ہو گیا) sets aside posts that clearly aren't about lost or found items.",
  },
  {
    title: "Read",
    body: "The worker masks phone numbers, email addresses and CNIC numbers before sending post text to a hosted model that classifies the post and extracts the item, place and date.",
  },
  {
    title: "Check",
    body: "Code then checks the model's answer against the post. A place or date that doesn't appear in the post is thrown away, and missing details stay empty instead of being guessed.",
  },
  {
    title: "Place on the map",
    body: "The place name is looked up in OpenStreetMap. The map shows only as much precision as the post gives.",
  },
];

function PinGlyph({ type }: { type: "LOST" | "FOUND" }) {
  const lost = type === "LOST";
  return (
    <svg width="22" height="28" viewBox="0 0 28 36" aria-hidden>
      <path
        d="M14 34.5S3.5 23.6 3.5 14.6a10.5 10.5 0 0 1 21 0C24.5 23.6 14 34.5 14 34.5Z"
        fill={lost ? "#fff" : "var(--found)"}
        stroke={lost ? "var(--lost)" : "#fff"}
        strokeWidth={lost ? 2.5 : 1.5}
      />
      <circle cx="14" cy="14.5" r="4.4" fill={lost ? "none" : "#fff"} stroke={lost ? "var(--lost)" : "none"} strokeWidth="2.6" />
    </svg>
  );
}

function AreaGlyph({ type }: { type: "LOST" | "FOUND" }) {
  const lost = type === "LOST";
  return (
    <svg width="44" height="28" viewBox="0 0 44 28" aria-hidden>
      <circle cx="22" cy="14" r="12.5" fill={lost ? "var(--lost)" : "var(--found)"} fillOpacity="0.1" stroke={lost ? "var(--lost)" : "var(--found)"} strokeDasharray="3 3" />
      <circle cx="22" cy="14" r={lost ? 5 : 5.5} fill={lost ? "#fff" : "var(--found)"} stroke={lost ? "var(--lost)" : "#fff"} strokeWidth={lost ? 2.5 : 1.5} />
    </svg>
  );
}

export default function AboutPage() {
  return (
    <main className="mx-auto w-full max-w-3xl flex-1 px-4 pt-10 pb-20 lg:px-6">
      <h1 className="text-[32px] leading-tight font-semibold tracking-[-0.02em] text-ink">How Lost &amp; Found Finder works</h1>
      <p className="mt-4 max-w-[64ch] text-[17px] leading-relaxed text-ink">
        When someone in Karachi loses a wallet, they might post about it in one place. The person who found it might post
        somewhere else. This site collects those public posts, works out what was lost or found and where, and puts them on
        one map so the two can find each other.
      </p>
      <p className="mt-3 max-w-[64ch] text-ink-muted">
        We don&apos;t hold the items or verify reports in person. Every listing links back to the original post, and that&apos;s
        where people contact each other.
      </p>

      <section className="mt-12" aria-labelledby="pipeline">
        <h2 id="pipeline" className="text-xl font-semibold text-ink">From a post to a pin</h2>
        <ol className="mt-5 space-y-5">
          {PIPELINE.map((step, i) => (
            <li key={step.title} className="grid grid-cols-[2rem_1fr] gap-3">
              <span className="grid size-7 place-items-center rounded-full border border-line-strong text-sm font-semibold text-ink-muted">
                {i + 1}
              </span>
              <div>
                <h3 className="font-semibold text-ink">{step.title}</h3>
                <p className="mt-0.5 max-w-[62ch] text-ink-muted">{step.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="mt-12" aria-labelledby="sources">
        <h2 id="sources" className="text-xl font-semibold text-ink">Where reports come from</h2>
        <p className="mt-2 max-w-[64ch] text-ink-muted">
          We only use sources that allow it, through official APIs or feeds published for sharing.
        </p>
        <dl className="mt-5 divide-y divide-line border-y border-line">
          {SOURCES.map((s) => (
            <div key={s.name} className="grid gap-1 py-4 sm:grid-cols-[13rem_1fr] sm:gap-6">
              <dt>
                <span className="font-medium text-ink">{s.name}</span>
                <span className="mt-0.5 block text-sm text-ink-muted">{s.status}</span>
              </dt>
              <dd className="text-ink-muted">{s.note}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="mt-12" aria-labelledby="map-legend">
        <h2 id="map-legend" className="text-xl font-semibold text-ink">Reading the map</h2>
        <p className="mt-2 max-w-[64ch] text-ink-muted">
          A hollow marker means the item is still missing. A filled marker means someone has found it. The shape also shows
          how sure we are about the place.
        </p>
        <ul className="mt-5 space-y-4">
          <li className="flex items-center gap-4">
            <span className="flex w-14 shrink-0 justify-center gap-1">
              <PinGlyph type="LOST" />
              <PinGlyph type="FOUND" />
            </span>
            <span>
              <span className="font-medium text-ink">Pin: exact place or street.</span>{" "}
              <span className="text-ink-muted">{PRECISION_DESCRIPTION.POI}</span>
            </span>
          </li>
          <li className="flex items-center gap-4">
            <span className="flex w-14 shrink-0 justify-center">
              <AreaGlyph type="LOST" />
            </span>
            <span>
              <span className="font-medium text-ink">Dot in a dashed circle: approximate area.</span>{" "}
              <span className="text-ink-muted">{PRECISION_DESCRIPTION.NEIGHBOURHOOD}</span>
            </span>
          </li>
          <li className="flex items-center gap-4">
            <span className="w-14 shrink-0 text-center text-sm text-ink-faint">List only</span>
            <span>
              <span className="font-medium text-ink">No marker.</span>{" "}
              <span className="text-ink-muted">
                If a post names only the city, or no place at all, the report appears in the list but not on the map.
              </span>
            </span>
          </li>
        </ul>
      </section>

      <section className="mt-12" aria-labelledby="statuses">
        <h2 id="statuses" className="text-xl font-semibold text-ink">What the labels mean</h2>
        <dl className="mt-5 space-y-3">
          {REPORT_STATUSES.map((s) => (
            <div key={s} className="grid gap-0.5 sm:grid-cols-[10rem_1fr] sm:gap-6">
              <dt className="font-medium text-ink">{STATUS_LABEL[s]}</dt>
              <dd className="text-ink-muted">{STATUS_DESCRIPTION[s]}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="mt-12" aria-labelledby="problems">
        <h2 id="problems" className="text-xl font-semibold text-ink">Reporting a wrong or resolved listing</h2>
        <p className="mt-2 max-w-[64ch] text-ink-muted">
          Open the report and choose <span className="text-ink">Suggest as resolved</span> or{" "}
          <span className="text-ink">Report a problem</span>. You don&apos;t need an account. Because anyone can send a
          suggestion, one suggestion never changes a listing on its own. Suggestions are rate-limited and checked first. A
          listing is marked resolved when the original post confirms it, or after review.
        </p>
      </section>

      <section className="mt-12" aria-labelledby="privacy">
        <h2 id="privacy" className="text-xl font-semibold text-ink">Privacy</h2>
        <p className="mt-2 max-w-[64ch] text-ink-muted">
          We mask recognized CNIC numbers, phone numbers, and email addresses before showing source text. We omit
          social account names and handles. News articles include the public byline for attribution. Text from
          irrelevant posts is removed after a week.
        </p>
      </section>

      <section id="demo-data" className="mt-12 scroll-mt-20 rounded-xl border border-caution/30 bg-caution-soft p-5" aria-labelledby="demo-title">
        <h2 id="demo-title" className="text-lg font-semibold text-ink">About the demo data</h2>
        <p className="mt-2 max-w-[64ch] text-ink">
          Reports labelled “Demo data” are hand-written examples for testing. They show English, Roman Urdu and Urdu posts,
          cross-posted duplicates, approximate locations and possible matches. Their locations come from OpenStreetMap.
        </p>
        <Link href="/" className="mt-3 inline-block text-sm font-medium text-ink underline underline-offset-4">
          Back to the map
        </Link>
      </section>

      <p className="mt-12 text-sm text-ink-faint">
        Map data © OpenStreetMap contributors, available under the Open Database Licence.
      </p>
    </main>
  );
}
