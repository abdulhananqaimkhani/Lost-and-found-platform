import { Suspense } from "react";
import { MapExplorer } from "@/components/explorer/map-explorer";

function ExplorerFallback() {
  return (
    <main className="flex h-[calc(100dvh-3.5rem)] flex-col">
      <div className="h-[57px] border-b border-line bg-surface" />
      <div className="grid flex-1 place-items-center bg-[#e4e8e6] text-sm text-ink-muted" role="status">
        Loading the map…
      </div>
    </main>
  );
}

/** The map explorer reads its filters from the URL, so it renders inside a Suspense boundary. */
export default function HomePage() {
  return (
    <Suspense fallback={<ExplorerFallback />}>
      <MapExplorer />
    </Suspense>
  );
}
