import { expect, test, type Page } from "@playwright/test";

/** Wait until Leaflet has rendered markers or clusters. */
async function waitForMap(page: Page) {
  await expect(page.locator(".lf-marker, .lf-cluster").first()).toBeVisible();
}

const marker = (page: Page, id: string) => page.locator(`.lf-marker:has([data-report-id="${id}"])`);
const listRow = (page: Page, id: string) => page.locator(`aside[aria-label="Report list"] li[data-report-id="${id}"]`);

test.describe("Map explorer: map and list stay in sync", () => {
  test("the map still works after visiting another page and returning", async ({ page }) => {
    const tilePane = page.locator(".leaflet-container:visible .leaflet-tile-pane");
    await page.goto("/");
    await expect(tilePane).toBeAttached();

    for (const route of ["Explore", "How it works"]) {
      await page.getByRole("link", { name: route, exact: true }).click();
      await expect(page).toHaveURL(route === "Explore" ? /\/reports$/ : /\/about$/);
      await page.getByRole("link", { name: "Map", exact: true }).click();
      await expect(tilePane).toBeAttached();
      await expect(page.locator(".leaflet-container:visible .leaflet-control-zoom-in")).toBeVisible();
    }
  });

  test("clicking a list item flies to the report, opens its preview and highlights the row", async ({ page }) => {
    await page.goto("/");
    await waitForMap(page);

    await page.getByRole("button", { name: /Samsung Galaxy A54.*Show on map/ }).click();

    const preview = page.getByTestId("map-preview");
    await expect(preview).toBeVisible();
    await expect(preview).toHaveAttribute("data-report-id", "demo-003");
    await expect(preview.getByRole("link", { name: "View details" })).toHaveAttribute("href", "/reports/demo-003");
    await expect(listRow(page, "demo-003")).toHaveAttribute("data-selected", "true");
    await expect(marker(page, "demo-003").locator('[data-state="selected"]')).toBeVisible();
  });

  test("clicking a marker selects the matching list row", async ({ page }) => {
    // Only two pets, far apart, so both are unclustered markers.
    await page.goto("/?cat=PET");
    await waitForMap(page);
    await expect(marker(page, "demo-015")).toBeVisible();

    await marker(page, "demo-015").click();

    await expect(listRow(page, "demo-015")).toHaveAttribute("data-selected", "true");
    await expect(listRow(page, "demo-007")).not.toHaveAttribute("data-selected", "true");
    await expect(page.getByTestId("map-preview")).toHaveAttribute("data-report-id", "demo-015");
  });

  test("hovering a marker shows a preview on desktop, and the cursor can move into it", async ({ page }) => {
    await page.goto("/?cat=PET");
    await waitForMap(page);

    await marker(page, "demo-007").hover();
    const preview = page.getByTestId("map-preview");
    await expect(preview).toHaveAttribute("data-report-id", "demo-007");

    // Moving onto the card keeps it open, so "View details" is reachable.
    await preview.hover();
    await page.waitForTimeout(400);
    await expect(preview).toBeVisible();
    await preview.getByRole("link", { name: "View details" }).click();
    await expect(page).toHaveURL(/\/reports\/demo-007$/);
  });

  test("closing the preview clears the selection", async ({ page }) => {
    await page.goto("/");
    await waitForMap(page);
    await page.getByRole("button", { name: /Samsung Galaxy A54.*Show on map/ }).click();
    await expect(page.getByTestId("map-preview")).toBeVisible();

    await page.keyboard.press("Escape");

    await expect(page.getByTestId("map-preview")).toHaveCount(0);
    await expect(listRow(page, "demo-003")).not.toHaveAttribute("data-selected", "true");
  });

  test("approximate locations are drawn as an area, never as a pin", async ({ page }) => {
    await page.goto("/");
    await waitForMap(page);
    await page.getByRole("button", { name: /Black leather wallet.*Show on map/ }).click();

    await expect(marker(page, "demo-001").locator('[data-kind="area"]')).toBeVisible();
    await expect(page.locator("path.leaflet-interactive, .leaflet-overlay-pane path").first()).toBeAttached();
  });

  test("reports at the same spot open as a list instead of an unsplittable cluster", async ({ page }) => {
    // demo-002 and demo-028 are both placed at the Gulshan-e-Iqbal area centre.
    await page.goto("/?area=gulshan-e-iqbal&cat=WALLET,DOCUMENT_ID");
    await waitForMap(page);
    await page.locator('.lf-cluster:has([data-cluster-count="2"])').click();
    const stack = page.getByTestId("map-stack");
    await expect(stack).toBeVisible();
    await stack.getByRole("button", { name: /Black wallet/ }).click();
    await expect(page.getByTestId("map-preview")).toHaveAttribute("data-report-id", "demo-002");
    await expect(listRow(page, "demo-002")).toHaveAttribute("data-selected", "true");
  });
});

test.describe("Filters", () => {
  test("type and category filters update the URL, the list and the markers", async ({ page }) => {
    await page.goto("/");
    await waitForMap(page);

    await page.getByRole("radio", { name: "Found only" }).click();
    await expect(page).toHaveURL(/type=FOUND/);
    const rows = page.locator('aside[aria-label="Report list"] ul[aria-label="Reports"] > li');
    await expect(rows.first()).toBeVisible();
    // The previous results stay on screen until the new ones arrive (no flash of empty list),
    // so wait for the update instead of reading the rows immediately. Against the real API it takes a moment.
    await expect
      .poll(async () => (await rows.allInnerTexts()).every((text) => text.includes("Found")))
      .toBe(true);

    await page.getByRole("button", { name: "Category" }).click();
    await page.getByRole("checkbox", { name: "Wallet" }).click();
    await page.keyboard.press("Escape");
    await expect(page).toHaveURL(/cat=WALLET/);
    // Found wallets: demo-002 is mapped; demo-017 has no location, so it is not "in this map area".
    await expect(page.getByTestId("result-count")).toContainText("1 report in this map area");

    await page.getByRole("button", { name: "Clear filters" }).click();
    await expect(page).toHaveURL(/\/$/);
  });

  test("search accepts Roman Urdu words", async ({ page }) => {
    await page.goto("/reports");
    await page.getByRole("searchbox", { name: "Search reports" }).fill("batwa");
    await expect(page).toHaveURL(/q=batwa/);
    await expect(page.getByTestId("result-count")).toHaveText("5 reports");
  });

  test("filters survive a reload because they live in the URL", async ({ page }) => {
    await page.goto("/reports?type=LOST&cat=PHONE");
    await expect(page.getByTestId("result-count")).toHaveText("3 reports");
    await page.reload();
    await expect(page.getByTestId("result-count")).toHaveText("3 reports");
  });
});

test.describe("Report details", () => {
  test("shows sources with hidden personal numbers, matches and the suggestion flow", async ({ page }) => {
    await page.goto("/reports/demo-001");
    await expect(page.getByRole("heading", { level: 1, name: "Black leather wallet" })).toBeVisible();
    await expect(page.getByRole("heading", { name: "Original posts (2)" })).toBeVisible();
    await expect(page.getByText("0300-1234567")).toHaveCount(0);
    await expect(page.getByText("[phone •••]").first()).toBeVisible();
    await expect(page.getByRole("link", { name: /Black wallet/ })).toHaveAttribute("href", "/reports/demo-002");

    await page.getByRole("button", { name: "Suggest as resolved" }).click();
    await page.getByRole("button", { name: "Send suggestion" }).click();
    await expect(page.getByText(/Suggestion recorded/)).toBeVisible();
    await expect(page.getByTestId("suggestion-counts")).toContainText("1 person says the item has been returned");
    // The public status is unchanged.
    await expect(page.getByText("Possible match").first()).toBeVisible();
  });

  test("unknown report ids show a helpful not-found page", async ({ page }) => {
    await page.goto("/reports/does-not-exist");
    await expect(page.getByRole("heading", { name: "This report isn't here" })).toBeVisible();
  });
});

test.describe("Mobile", () => {
  test("@mobile list opens as a sheet; choosing a report shows it on the map", async ({ page }) => {
    await page.goto("/");
    await waitForMap(page);
    const width = await page.evaluate(() => document.documentElement.scrollWidth);
    expect(width).toBeLessThanOrEqual(page.viewportSize()!.width);

    await page.getByRole("button", { name: /Show list/ }).click();
    await page.getByRole("button", { name: /Samsung Galaxy A54.*Show on map/ }).click();

    await expect(page.getByRole("button", { name: /Show list/ })).toBeVisible();
    await expect(page.getByTestId("map-preview")).toHaveAttribute("data-report-id", "demo-003");
  });

  test("@mobile tapping a marker opens its preview", async ({ page }) => {
    await page.goto("/?cat=PET");
    await waitForMap(page);
    await marker(page, "demo-015").tap();
    await expect(page.getByTestId("map-preview")).toHaveAttribute("data-report-id", "demo-015");
  });

  test("@mobile detail page has no horizontal scroll", async ({ page }) => {
    await page.goto("/reports/demo-009");
    await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
    const width = await page.evaluate(() => document.documentElement.scrollWidth);
    expect(width).toBeLessThanOrEqual(page.viewportSize()!.width);
  });
});
