# Data sources: what is connected and why

Checked on **2026-11-23**. Platform terms change, so re-check before relying on this.
The rule for every source: an authorized API, a permitted public feed, or no access at all.
No scraping, no login automation, no working around a platform's restrictions.

| Source | Status | Connector | Why |
|---|---|---|---|
| Mastodon (mastodon.social) | **Connected** | `connectors/mastodon.py` | Open public API, terms allow application access (below) |
| Global Voices Pakistan | **Connected** | `connectors/rss.py` | Publisher-provided RSS and CC BY 3.0 for original text |
| PakFound Karachi | Feed slot added | `connectors/rss.py` | Needs permission for automated access and a feed URL |
| Fooundit Karachi pets | Feed slot added | `connectors/rss.py` | Needs an authorized pet feed and reuse agreement |
| Jang Karachi classifieds | Feed slot added | `connectors/rss.py` | Needs reuse permission and an RSS or Atom feed |
| Dawn RSS | Not used | `connectors/rss.py` (feed listed, `enabled: false`) | Terms: personal, non-commercial use only |
| Express Tribune RSS | Not used | same | Re-use not permitted without written consent |
| The News RSS | Not used | same | No terms published; "All Rights Reserved" |
| Google News RSS search | Not used | same | Feed notice limits use to a personal feed reader; robots.txt disallows `/rss` |
| X API v2 | Built, switched off | `connectors/x_api.py` | Pay-per-use. Runs only with `X_BEARER_TOKEN`, a per-run cap and a monthly budget |
| Reddit Data API | Direct OAuth and Composio supported, switched off | `connectors/reddit.py` | Needs an authorized use and credentials |
| Bluesky | Built, switched off | `connectors/bluesky.py` | Search needs an account app password; the public endpoint returned **403** when tested |
| Facebook groups | **Not implementable** | none | Groups API removed in Graph API v19 (April 2024) |
| Facebook pages / Instagram | Not implemented | none | Need Meta App Review and business verification |

## Evidence

### Global Voices Pakistan

The publisher [invites readers to use its RSS feeds](https://globalvoices.org/feeds/). Its [republishing guidelines](https://globalvoices.org/about/global-voices-attribution-policy/) license original text under CC BY 3.0 unless marked otherwise. The worker reads recent headlines and summaries from the Pakistan feed, keeps dated articles on the publisher's domain with a byline, and tests them for actual lost-property or pet reports. The report shows the publisher, byline, original article link, and license alongside a shortened, redacted excerpt. The connector uses the feed text and omits photos and embeds.

### Mastodon: connected, with conditions
- `GET https://mastodon.social/api/v1/instance/terms_of_service` (effective 2026-08-31) says uploaded content is made available "via one or more APIs for application access", and "Anyone, or any computer, might access your Content via RSS aggregators and readers … or index and store your Content in search engines and databases."
- Authors keep ownership: "Nothing in these terms gives us ownership of your Content."
- Server rule (`/api/v1/instance/rules`): "Content created by others must be attributed".
- `robots.txt` does not disallow `/api/v1/timelines/` for general clients. It bans named AI-training crawlers and states the content must not be used for LLM training.

**Conditions we follow:**
- We read public posts only (`visibility: public`), skip boosts, and make a few requests per hour.
- We keep only posts that mention lost or found items.
- We show a short excerpt and always link to the original post.
- We store no author names or handles.
- Nothing is used to train any model.

### Other news RSS feeds
- **Dawn** (`dawn.com/terms`): "You shall not copy, reproduce, republish, … make available to the public, or otherwise use the content of this website in any way except for your own personal, non-commercial use." Any other use "requires the prior written permission of DAWN".
- **Express Tribune** (`tribune.com.pk/copyrights`): "Re-use of The Express Tribune content is NOT permitted without prior written consent". Its RSS page offers feeds "for its readers".
- **The News** (`thenews.com.pk`): there is no terms-of-use page; the 404s are at `/terms-and-conditions`. The footer says "All Rights Reserved". No licence is stated, so we don't use it.
- **Google News RSS**: the feed's own notice says it "is made available solely for the purpose of rendering Google News results within a personal feed reader for personal, non-commercial use. Any other use of the feed is expressly prohibited." `news.google.com/robots.txt` has `Disallow: /` for all agents, with no `Allow` for `/rss`.

To use any of these, ask the publisher for written permission, then set `enabled: true` in `config/sources.yaml` and record the permission next to the feed.

### PakFound, Fooundit, and Jang

- [PakFound](https://pakfound.com/) lists Karachi belongings. Its [terms](https://pakfound.com/terms) require permission for automated tools.
- [Fooundit's Karachi pet listings](https://fooundit.com/city/karachi/pets) fit the pet category. Its [terms](https://fooundit.com/terms-and-conditions) restrict automated collection.
- [Jang Karachi](https://e.jang.com.pk/karachi/) publishes lost-and-found classifieds in its e-paper. Request reuse permission and an RSS or Atom feed for those notices.

Each entry in `config/sources.yaml` has a publisher page and an empty feed URL. When the publisher supplies an authorized feed, enter its HTTPS URL, record the reuse terms, apply any required attribution fields, and enable that entry. The RSS connector expects a feed rather than a publisher homepage or a PDF.

### Reddit via Composio

[Composio offers managed Reddit OAuth](https://composio.dev/toolkits/reddit), or it can manage credentials for an app you register. Its [authenticated proxy](https://docs.composio.dev/reference/v3/api-reference/tools/postToolsExecuteProxy) lets the worker run a read-only search scoped to `r/karachi`. Reddit's [Responsible Builder Policy](https://support.reddithelp.com/hc/en-us/articles/42728983564564-Responsible-Builder-Policy) still governs this use. Confirm that authorization covers collecting public posts, handling removals, displaying listings off Reddit, and sending masked excerpts to the hosted extraction service.

Set `COMPOSIO_API_KEY` in the project-root `.env` using the key from the project where you connected Reddit. The worker finds the connection automatically when the project has exactly one active private Reddit connection. Set `COMPOSIO_REDDIT_ACCOUNT_ID` if several are available or to use a shared connection. For a shared connection, also set `COMPOSIO_REDDIT_USER_ID` to the authorized Composio user ID.

Set `reddit.approved` to `true` in `config/sources.yaml` once Reddit has approved the app's use. Run `uv run --locked python -m lf_worker collect reddit:search` to verify collection, then restart the worker to enable scheduled collection. Use `transport: direct` and the existing `REDDIT_*` credentials for direct OAuth.

Reddit collection runs at most once per hour across the scheduled worker and manual commands that use the same database. The default covers one search in `r/karachi` per run. An HTTP `429` pauses collection for at least an hour, or longer when Reddit or Composio requests it. The worker makes no automatic retry within the run.

### X and Bluesky
- Each connector follows the platform's official API documentation.
- Each is tested against fixtures shaped like the documented responses (`services/worker/tests/test_connectors.py`), so none of them needs credentials or money to test.
- **X:**
  - hard `max_posts_per_run`;
  - `monthly_budget_usd`, computed from the `collection_runs.cost_units` ledger; the connector refuses to run once the month's budget is spent;
  - `since_id` cursors per query;
  - `-is:retweet`;
  - waits indicated by `x-rate-limit-reset` are honoured.
- **Bluesky:** logs in with an app password, which is Bluesky's mechanism for third-party apps.

## Consequence for the project
The enabled feeds have had low coverage of individual lost-property notices in Karachi. The first Mastodon run collected 22 posts through the keyword gate. None was a Karachi lost-or-found item. The Global Voices feed is general news and contributes a listing only when an article reports a qualifying case.

This is reported honestly rather than filled with invented data. The demo dataset is clearly labelled, and it is the only data shown as examples.

Lawful ways to raise the volume, in order of effort:
1. Ask Dawn, Express Tribune or The News for written permission to use their feeds.
2. Fund the X connector with a small budget. The default cap is $5 a month, about 1,000 posts.
3. Apply for Reddit Data API access for r/karachi. This is non-commercial, academic use.
4. Add a "Submit a public post" form (PROJECT_PLAN.md §18, question 2). It isn't built, because that decision is still open.
