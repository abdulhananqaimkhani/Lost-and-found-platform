# Setting up Lost & Found Finder on Windows 11

The website can run in demo mode without cloud credentials. The default setup uses OpenRouter's free Flint endpoint.

## 1. Install the tools (once)

| Tool | How | Check |
|---|---|---|
| Node.js 20+ | <https://nodejs.org> (developed on Node 24) | `node --version` |
| Docker Desktop | <https://www.docker.com/products/docker-desktop/> | `docker info` |
| uv (Python manager) | `winget install --id=astral-sh.uv -e` | `uv --version` |
| Git | <https://git-scm.com> | `git --version` |

**Limit Docker's memory** before starting Docker Desktop, so it can't take most of the 8 GB. Create `C:\Users\<you>\.wslconfig` containing:

```ini
[wsl2]
memory=2GB
processors=2
swap=2GB
```

Then run `wsl --shutdown` and start Docker Desktop.

## 2. Configure

```powershell
cd "lost and found"
copy .env.example .env
# Edit .env: set POSTGRES_PASSWORD, and the same password inside DATABASE_URL and TEST_DATABASE_URL.
# Set FINGERPRINT_SECRET to a random value:
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

`.env` is git-ignored. Never commit it.

Create a key in [OpenRouter API keys](https://openrouter.ai/settings/keys) and set these entries in the repository-root `.env`.

```dotenv
AI_PROVIDER=openrouter
OPENROUTER_MODEL=recursive/flint-v1.0:free
OPENROUTER_API_KEY=your_key_here
```

OpenRouter's free endpoint is rate-limited. The worker caps the route price at zero and leaves jobs queued if the service is unavailable. Set `AI_PROVIDER=ollama` explicitly to use the Ollama settings instead.

Verify the credentials and model with one synthetic lost-wallet example. This consumes cloud usage and can run before Docker starts.

```powershell
uv run python -m lf_worker check-ai
```

## 3. Start the database and install dependencies

```powershell
docker compose up -d                  # PostGIS on 127.0.0.1:5442 (not reachable from other machines)
uv sync                               # Python 3.12 + all packages into .venv
uv run alembic upgrade head           # create the tables
uv run python -m lf_worker seed-gazetteer   # Karachi places from OpenStreetMap
cd apps/web; npm install; cd ../..
```

The default port 5442 avoids clashing with other PostgreSQL servers. To change it, edit `POSTGRES_PORT` and the two URLs in `.env`.

Use `SHOW_DEMO_DATA=false` in the root `.env` for a real-only run. To remove previously seeded demo records from the configured database, run `uv run python -m lf_worker seed-demo --remove`.

## 4. Run

Use three terminals:

```powershell
# 1. API (http://127.0.0.1:8000/docs)
uv run uvicorn lf_api.main:app --host 127.0.0.1 --port 8000

# 2. Worker: collection schedule + AI queue + daily maintenance
uv run python -m lf_worker run

# 3. Website (http://127.0.0.1:3000)
cd apps/web
$env:NEXT_PUBLIC_DATA_SOURCE = "api"
npm run build
npm run start -- --hostname 127.0.0.1
```

`NEXT_PUBLIC_DATA_SOURCE` is fixed into the build, so set it before running `npm run build`. Without it, the website uses the built-in demo data and needs no backend at all.

## 5. Operator commands

There is no admin website. These commands are the operator's tools:

```powershell
uv run python -m lf_worker status                 # queue, sources, reports, AI health
uv run python -m lf_worker collect all            # collect once now
uv run python -m lf_worker process --limit 10     # run queued AI/geocoding/matching jobs once
uv run python -m lf_worker review-suggestions     # visitor "resolved"/"inaccurate" suggestions
uv run python -m lf_worker review-suggestions --accept 12 --reason "Owner confirmed on the original post"
uv run python -m lf_worker set-status <report-id> RESOLVED --reason "..."
uv run python -m lf_worker maintenance            # stale reports, crashed jobs, purge irrelevant text
```

## 6. Tests

```powershell
uv run pytest                         # backend: API, pipeline, connectors, geocoding (needs the database running)
uv run ruff check services scripts
cd apps/web
npm test                              # frontend unit/component tests
npx playwright install chromium       # first time only
npm run build; npm run test:e2e       # end-to-end, against the demo data
```

None of these call Ollama or any paid service. The AI is mocked in tests. The real model is measured separately with `uv run python scripts/evaluate_model.py`.

## Memory tips for an 8 GB laptop

- Run the AI queue (`process`) before a demo if you want reports ready when the demo starts.
- Close other Docker containers you don't need (`docker ps`).
- Use `npm run start`, not `npm run dev`, for demos.
