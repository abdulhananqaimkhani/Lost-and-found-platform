# How a post becomes a report

The standard setup uses a server-side key to call OpenRouter's free Flint endpoint. The worker can also use Ollama when configured explicitly.

```
collected post
  │ stage 0  dedupe: same platform+id, same canonical URL, or same normalized text → attach, stop
  │ stage 1  keyword prefilter (Python)          → obviously irrelevant: stop, no AI call
  │ stage 2  AI: classify + extract as JSON      → unavailable? extraction waits without using an attempt
  │ stage 3  grounding (Python)                  → remove anything not found in the post
  │          coverage rule                       → not about Karachi: stop
  │          resolution update in same thread?   → mark the original RESOLVED (audited)
  │          near-duplicate of a report?         → attach as another source
  ▼          create report (ACTIVE or UNVERIFIED) → GEOCODE job → MATCH job
```

## Stage 1: keyword prefilter (`ai/prefilter.py`)
- It needs both an **intent** word and an **item** word. Intent words cover English, Roman Urdu and Urdu: lost, kho gaya, گم, found, mila, مل گیا… Item words cover wallet, batwa, موبائل, chabi and so on.
- It subtracts points for phrases that use "lost" or "found" in another sense: "lost the match", "found out", "for sale", "missing persons".
- Spelling variants are collapsed first ("gya" → "gaya", "mobail" → "mobile"), because Roman Urdu has no standard spelling.
- It can be switched off (`PREFILTER_ENABLED=false`). At low volume, recall matters more than saving AI time.

## Stage 2: one AI call (`ai/extraction.py`)
- **JSON validation.** Hosted models receive the JSON schema as part of the prompt. The worker parses the final answer, validates it with Pydantic, and allows one repair attempt.
- **Request settings.** The worker requests temperature 0 and a non-streaming response. OpenRouter routes must have zero pricing and disallow data collection.
- **Prompt:** a system prompt with rules and category definitions, plus 5 few-shot examples in English, Roman Urdu and Urdu. One example is irrelevant and one is a resolution update.
  - The few-shot posts are not in either evaluation set.
  - The prompt prefix is identical across posts.
- **The model is asked to copy, not to infer.** `location_text` and `date_expression` must be verbatim, and fields the post doesn't state must be null. It never outputs coordinates or calendar dates.
- **One call does both classification and extraction.** The earlier local model measurements are in the benchmarks.

## Stage 3: grounding (`ai/grounding.py`)

The model's answer is treated as a claim and checked against the post:

| Field | Check | On failure |
|---|---|---|
| `location_text`, `date_expression`, `colour`, `brand` | Appears in the post: exact, fuzzy (rapidfuzz ≥ 85), or ≥ 80% of its content words present in any order | Removed; report flagged (`*_not_in_post`) |
| `location_text` (missing or removed) | Fallback: a gazetteer place name or alias found word-for-word in the post | Uses the place label; flagged `location_from_gazetteer` |
| `item_name` | Shares a word or a known synonym with the post (batwa ↔ wallet) | Flagged; report becomes UNVERIFIED |
| `city` | Taken only from the post's own words | Otherwise null. Geocoding may later set it, recorded as `INFERRED_FROM_GAZETTEER` |
| date | `ai/dates.py` resolves the copied phrase against the post's publication date in Asia/Karachi. Examples: "kal raat", "parson", "2 din pehle", "15 Nov", "14/11" (day first) | Never a date after the post. Unknown phrases give UNKNOWN |
| `report_type = UNCERTAIN` | Uses the keywords if they point one way only | Otherwise treated as irrelevant |

**Confidence = ½ × the model's self-reported confidence + ½ × the share of deterministic checks passed.** Self-reported confidence from small LLMs is poorly calibrated, so it is never used alone. Below 0.6, or with a grounding failure, the report is **UNVERIFIED** and shows "Needs review".

## Geocoding (`geocoding/geocoder.py`)
1. **Gazetteer:** 52 Karachi places from OpenStreetMap, each checked by hand, with aliases in Roman Urdu and Urdu. The most specific name contained in the phrase wins: "Gulshan Block 10-A" beats "Gulshan".
2. **Cache:** `geocode_cache` stores both hits and "not found".
3. **Nominatim:** limited to Karachi (`viewbox`, `bounded=1`), at most 1 request per second, with an identifying User-Agent.
4. **Precision** comes from the OSM category and type:
   - POI → pin (120 m);
   - street → pin plus ring (400 m);
   - neighbourhood → circle sized from the OSM bounding box (400–2,500 m);
   - city → not mapped.
5. **Ambiguity:** if two equally likely candidates are more than 2 km apart, the report is not mapped and is flagged.

## Matching (`matching.py`, `lf_core/scoring.py`)
- **Candidates:** the opposite type, the same or a related category, within 5 km (or the same city when unmapped), and within ±14 days.
- **Score:** `0.30·category + 0.30·text + 0.20·distance + 0.10·date + 0.10·colour`. The score is multiplied by 0.85 when two stated colours conflict. Colour words are compared across languages: kaala = black = کالا.
- A score of 0.65 or more is stored with its breakdown, and the report becomes "Possible match". It is never shown as confirmed.

## Privacy
- The worker masks recognized CNIC numbers, phone numbers and e-mail addresses before sending the post text to a hosted model. The same types of data are masked before display and kept out of the search index.
- Author names and handles are never stored. The connectors drop them, and the `NormalizedPost` contract rejects them.
- Text of irrelevant or out-of-coverage posts is purged after 7 days (`maintenance`).
