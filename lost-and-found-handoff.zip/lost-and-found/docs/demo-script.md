# Demo script (about 10 minutes)

## The day before

1. Run `docker compose up -d`, then `uv run python -m lf_worker status`. Verify cloud extraction with `uv run python -m lf_worker check-ai`.
2. Run `uv run python -m lf_worker seed-demo` to reset the demo data. This also clears suggestions left over from rehearsals.
3. Run `uv run python -m lf_worker collect all`, then `uv run python -m lf_worker process --limit 50` before the demo.
4. Build the website in API mode: `cd apps/web; $env:NEXT_PUBLIC_DATA_SOURCE="api"; npm run build`.
5. Open the map once with internet access, so the OpenStreetMap tiles are cached by the browser.

## On the day

Use three terminals: the API, `npm run start` and, optionally, the worker. Close other Docker containers to free RAM.

| # | Show | Say |
|---|---|---|
| 1 | Map explorer at `/` | "Every report is a public post. Hollow markers are lost items, filled are found. Exact places get a pin, approximate areas get a dashed circle, and city-only posts aren't on the map at all." |
| 2 | Click a list row, then click a marker | "The list and the map stay in sync both ways." |
| 3 | Cluster in Gulshan → stack list | "Many posts only name a neighbourhood, so they share one point. We show a list instead of faking precision." |
| 4 | Search `batwa` | "Roman Urdu search: *batwa* finds wallets." |
| 5 | Open `demo-001` | "Phone and CNIC numbers are masked. We link to the original post instead of copying contact details." |
| 6 | Possible match section | "The score shows why the two reports look related: category, text, distance, date and colour. It never says 'confirmed'." |
| 7 | "Suggest as resolved" | "Anonymous visitors can only *suggest*. The status changes only when the operator reviews it." Then run `uv run python -m lf_worker review-suggestions` live. |
| 8 | Terminal: `uv run python -m lf_worker status` | "This is the collection log and the queue. Mastodon is the only source we are allowed to use, and here is why." Then show `docs/integrations/README.md`. |
| 9 | Live AI: run `uv run python -m lf_worker check-ai` | "The worker sends one synthetic lost-wallet post to the configured hosted model and validates the result." |
| 10 | `docs/benchmarks/README.md` | "These are the earlier local model results on 120 labelled posts. Cloud accuracy is still to be measured." |

## If something breaks

- **No internet:** the map tiles may be missing, but the list, search and detail pages still work. All data is local.
- **Ollama slow or down:** skip step 9 and show the stored benchmark results instead.
- **API not running:** the website shows "Can't reach the Lost & Found server". Start uvicorn.
