# Viva preparation: likely questions and honest answers

## Data and legality

**Where does the data come from?**
From Mastodon's public API and Global Voices' Pakistan article feed. X, Reddit and Bluesky have optional connectors.

Dawn, Express Tribune, The News and Google News remain disabled. The evidence is recorded in `docs/integrations/README.md`.

**Then the map is empty?**
Live volume of Karachi posts is close to zero. That's a finding about lawful data access, not a bug.

The map shows a clearly labelled demo dataset whose coordinates are real OSM places. Every demo record says "Demo data", and a test fails if a demo record has a non-`.invalid` URL or a coordinate that isn't in the OSM file. Ways to raise the volume lawfully are listed in the integrations document: publisher permission, a funded X budget, Reddit approval, or a submission form.

**Why not scrape Facebook?**
It breaks Meta's terms and the project brief. It would also mean storing personal data without any lawful basis.

## AI

**Why a hosted model?**
The worker uses OpenRouter's free Flint endpoint so the laptop does not have to load model weights. It masks recognized phone numbers, emails and CNIC numbers before sending public post text. The free endpoint has a request quota.

**How accurate is it?**
The recorded AI scores cover local models on a 120-post synthetic development set that was also used to tune the rules. The 40-post held-out AI run and hosted-model accuracy are still pending.

**How do you stop hallucinations?**
The model is never trusted for facts it could invent:
- Locations, dates, colours and brands must be found in the post, or they are removed.
- Coordinates come only from OSM.
- Dates are computed in Python from the copied phrase.
- Removals are logged. The benchmark reports how often grounding removed something, and why: usually translation or rewording rather than pure invention.

**Why is confidence half model, half rules?**
Small LLMs report confidence badly; it isn't calibrated. The deterministic half reflects how many checks the answer passed.

**What happens when Ollama is unavailable?**
Extraction jobs are deferred without using an attempt, and a circuit breaker pauses further calls. Geocoding and matching jobs can continue. The test is `test_when_ollama_is_down_jobs_wait_without_using_attempts`.

## Location

**Why circles instead of pins?**
Many posts only name an area ("Gulshan"). A pin would claim a precision we don't have, so precision is stored and drives the display. The database itself refuses coordinates for city-level reports (a CHECK constraint).

**Isn't Nominatim unreliable for Karachi?**
Partly, and that was measured. Every gazetteer lookup was checked by hand against its OSM name:
- Three matched the wrong thing (a school for "Sea View", a generic "KARACHI" point for North Karachi, one point for the whole of Landhi).
- One road was too long to pin (Shahrah-e-Faisal).
- Two places weren't found at all.

The wrong ones were removed or re-queried. 52 places remain.

At runtime, ambiguous results (two candidates more than 2 km apart) are not mapped. The local gazetteer is tried first.

## Status and abuse

**Anyone can mark a report resolved?**
No. A visitor can only *suggest*. The suggestion is stored with an HMAC fingerprint (no raw IP), with one suggestion per visitor per report per day and five per hour. The status changes only through an operator CLI command, or when a later post in the same thread says the item was returned. Every change goes to the `status_changes` audit table.

**Rate limits can be dodged?**
Behind the Next.js proxy, the forwarded IP header could be spoofed. Suggestions change nothing on their own, so the impact is low. A real deployment would put a reverse proxy in front that overwrites `X-Forwarded-For`. This limitation is documented.

## Engineering

**How do you know demo mode and API mode behave the same?**
A script runs the frontend's own query engine on 20 filter combinations and records the exact query string the browser would send. The backend test suite replays those queries against FastAPI and requires identical IDs in the same order (`test_parity.py`). All 14 Playwright tests also pass against the real API.

**Why PostgreSQL and PostGIS?**
- Spatial indexes (GiST) for map-box and radius queries.
- A generated `tsvector` column for search.
- `FOR UPDATE SKIP LOCKED` for a job queue without extra infrastructure such as Redis or Celery.
- All of it in one dependency.

**What would you do next?**
1. Get lawful data access (see integrations).
2. Grow the held-out set with real annotated posts (`origin: COLLECTED`).
3. Add a community submission form.
4. Possibly add embeddings for matching, but only if a benchmark shows they help. The cat-versus-puppy false positive is the kind of error they could fix.
