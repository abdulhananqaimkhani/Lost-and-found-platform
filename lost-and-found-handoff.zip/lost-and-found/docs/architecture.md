# Architecture (as built)

The full design rationale is in [PROJECT_PLAN.md](../PROJECT_PLAN.md). This page describes what was actually built and where to find it.

```
 Mastodon API ─┐                         ┌──────────────── services/worker (lf_worker) ────────────────┐
 (X, Reddit,   ├─▶ connectors/*.py ──▶ ingest (dedupe) ──▶ processing_jobs (PostgreSQL queue)         │
  Bluesky: off)┘                         │        EXTRACT: prefilter → hosted AI → grounding           │
                                         │        GEOCODE: gazetteer → cache → Nominatim (1 req/s)      │
                                         │        MATCH:   candidates (PostGIS) → score → matches       │
                                         └───────────────────────────┬─────────────────────────────────┘
                                                                     ▼
                                              PostgreSQL 16 + PostGIS (Docker, 127.0.0.1:5442)
                                                                     ▲
                    browser ─▶ Next.js (apps/web) ─ /api/* proxy ─▶ FastAPI (services/api, lf_api)
                                (never talks to Ollama)              (read-only + suggestions)
```

## Packages

| Package | Role | Key files |
|---|---|---|
| `services/core` (`lf_core`) | Shared by API and worker | `models.py` (tables), `text.py` (redaction, search text), `ingest.py` (stage 0 dedupe), `queue.py` (job queue), `status.py` (audited status changes), `scoring.py` (match score), `demo.py` (demo loader) |
| `services/api` (`lf_api`) | Public HTTP API | `routers/public.py`, `queries.py` (search in SQL), `security.py` (fingerprint, rate limit), `routers/internal.py` (token-protected ingest) |
| `services/worker` (`lf_worker`) | Background processing | `connectors/`, `ai/` (Ollama client, prefilter, extraction, grounding, dates, language), `geocoding/`, `matching.py`, `pipeline.py`, `runner.py`, `collector.py`, `app.py` (scheduler), `cli.py` |
| `database/migrations` | Alembic | `0001_initial_schema.py`: hand-written, with CHECK constraints, generated `geography` and `tsvector` columns, GiST/GIN indexes |
| `apps/web` | Next.js frontend | `src/lib/data/` (mock and API data sources behind one interface) |

## Guarantees and where they are enforced

| Guarantee | Enforced in | Tested in |
|---|---|---|
| Cloud credentials go only to the selected provider's HTTPS endpoint | The AI clients restrict destinations and disable redirects | `test_ai_client.py` |
| Jobs wait when Ollama access is interrupted | `pipeline.py` raises `AIUnavailable`, then `runner.py` defers without using an attempt; circuit breaker | `test_pipeline.py::test_when_ollama_is_down…` |
| The model never invents locations, dates or coordinates | `ai/grounding.py` (verbatim check), `ai/dates.py` (Python date maths), `geocoding/` (OSM only) | `test_ai_rules.py`, `test_geocoding.py` |
| No exact pin for an approximate place | DB CHECK `ck_reports_coords`; `ChainGeocoder` | `test_geocoding.py` |
| A visitor can't change a report's status | `status.py` actor table; suggestions stored separately | `test_api.py::TestSuggestions` |
| Every status change is audited | `status.change_status` writes `status_changes` | `test_pipeline.py` |
| Phone and CNIC numbers are never shown or searchable | `text.redact_text`, `build_search_text` | `test_text.py`, `test_api.py` |
| No raw IPs stored | `security.Fingerprinter` (HMAC with a daily component) | `test_api.py` |
| Internal endpoints closed by default | `routers/internal.py` returns 404 without `SERVICE_TOKEN` | `test_api.py::TestInternal` |
| Demo and API mode behave the same | `test_parity.py` replays 20 frontend query cases against the API | `test_parity.py` |

## Deviations from the Phase 0 plan

| Plan | Built | Reason |
|---|---|---|
| `duplicate_groups` table | Near-duplicates are attached to the existing report as another source | Simpler, and the visitor sees one listing with "posted in N places" |
| LLM outputs `language`, `missing_fields` | Computed in Python | Faster (fewer output tokens) and deterministic |
| `PERSON` category | Posts about missing or found people are classified as out of scope | Personal data about (often) children; not this app's purpose |
| `pg_trgm` typo search | Not used for search yet; prefix search with Roman Urdu synonyms | Kept identical to the demo-mode search |
| `slowapi` rate limiting | Small in-memory limiter plus a database count for suggestions | No extra dependency; the suggestion limit survives restarts |
| Embeddings for matching | Not implemented; `rapidfuzz` token-set similarity | No evidence it would help at this data volume. Would cost RAM and time |
| `HttpGateway` (remote worker) | Not built; `/internal/ingest` exists | Stretch goal |
| Geographic scope implicit | Explicit coverage rule: a post must be about Karachi | The first live run collected real lost-and-found posts from other countries |
